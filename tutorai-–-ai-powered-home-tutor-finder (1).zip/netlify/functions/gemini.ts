import { GoogleGenAI, Type } from '@google/genai';

export const handler = async (event: any) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ fallback: true, message: 'GEMINI_API_KEY not configured on server. Fallback active.' })
    };
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: { 'User-Agent': 'aistudio-build' }
      }
    });

    const path = event.path || '';
    const body = JSON.parse(event.body || '{}');

    // Route based on path or body.action
    if (path.includes('chat') || body.action === 'chat') {
      const { message, history, tutorContext } = body;
      const formattedHistory = Array.isArray(history)
        ? history.slice(-6).map((h: any) => `${h.sender === 'user' ? 'Parent' : 'TutorAI'}: ${h.text}`).join('\n')
        : '';
      const tutorSummary = Array.isArray(tutorContext)
        ? tutorContext.map((t: any) => `• ${t.name}: ${t.qualification}, Subjects: [${t.subjects.join(', ')}], Area: ${t.locality}, Mode: ${t.teachingMode}, Fee: ₹${t.monthlyFee}/month, Exp: ${t.experienceYears} yrs`).join('\n')
        : '';

      const prompt = `You are TutorChat, AI advisor for TutorAI. Help parents find tutors from the following list:\n${tutorSummary}\n\nChat history:\n${formattedHistory}\n\nParent: "${message}"\n\nProvide helpful, structured recommendations with bullet points.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ reply: response.text, fallback: false })
      };
    }

    if (path.includes('match') || body.action === 'match') {
      const { criteria, tutors } = body;
      const tutorSummary = Array.isArray(tutors)
        ? tutors.map((t: any) => `ID: ${t.id} | Name: ${t.name} | Subjects: ${t.subjects.join(', ')} | Locality: ${t.locality} | Mode: ${t.teachingMode} | Monthly Fee: ₹${t.monthlyFee} | Exp: ${t.experienceYears} yrs`).join('\n')
        : '';

      const prompt = `Match top 3 tutors for parent criteria:\nClass: ${criteria?.studentClass}, Subject: ${criteria?.subject}, Budget: ₹${criteria?.budget}, Locality: ${criteria?.locality}, Mode: ${criteria?.teachingMode}\n\nTutors:\n${tutorSummary}\n\nReturn JSON array of 3 objects with tutorId, tutorName, matchScore, reasons, feeFit, experienceFit, modeFit.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                tutorId: { type: Type.STRING },
                tutorName: { type: Type.STRING },
                matchScore: { type: Type.NUMBER },
                reasons: { type: Type.ARRAY, items: { type: Type.STRING } },
                feeFit: { type: Type.STRING },
                experienceFit: { type: Type.STRING },
                modeFit: { type: Type.STRING }
              },
              required: ['tutorId', 'matchScore', 'reasons', 'feeFit', 'experienceFit', 'modeFit']
            }
          }
        }
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ results: JSON.parse(response.text ?? '[]'), fallback: false })
      };
    }

    if (path.includes('study-plan') || body.action === 'study-plan') {
      const { studentClass, subjects, examDate, dailyHours, weakTopics, learningGoals } = body;
      const prompt = `Create a realistic study timetable for ${studentClass}, subjects: ${subjects?.join(', ')}, exam date: ${examDate}, daily hours: ${dailyHours}, weak topics: ${weakTopics}, goals: ${learningGoals}. Return JSON with overview, dailySchedule, weeklyGoals, revisionStrategy, pomodoroAdvice, examTips.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              overview: { type: Type.STRING },
              dailySchedule: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    timeSlot: { type: Type.STRING },
                    activity: { type: Type.STRING },
                    subject: { type: Type.STRING },
                    focus: { type: Type.STRING }
                  },
                  required: ['timeSlot', 'activity', 'subject', 'focus']
                }
              },
              weeklyGoals: { type: Type.ARRAY, items: { type: Type.STRING } },
              revisionStrategy: { type: Type.ARRAY, items: { type: Type.STRING } },
              pomodoroAdvice: { type: Type.STRING },
              examTips: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['overview', 'dailySchedule', 'weeklyGoals', 'revisionStrategy', 'pomodoroAdvice', 'examTips']
          }
        }
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ ...JSON.parse(response.text ?? '{}'), fallback: false })
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ status: 'healthy', service: 'TutorAI Gemini Netlify Gateway' })
    };
  } catch (error: any) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ fallback: true, error: error?.message || 'Gemini error' })
    };
  }
};
