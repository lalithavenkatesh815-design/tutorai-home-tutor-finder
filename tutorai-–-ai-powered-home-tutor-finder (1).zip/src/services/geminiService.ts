import { DEMO_TUTORS } from '../data/tutors';
import { SmartMatchCriteria, MatchResult, StudyPlanRequest, StudyPlanResponse } from '../types/tutor';
import { fallbackChatReply, fallbackSmartMatcher, fallbackStudyPlanner } from './aiFallbackEngine';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: Date;
  source?: 'gemini' | 'rule-fallback';
}

export async function askTutorChat(message: string, history: { sender: string; text: string }[]): Promise<{ reply: string; source: 'gemini' | 'rule-fallback' }> {
  try {
    const res = await fetch('/api/gemini/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message,
        history,
        tutorContext: DEMO_TUTORS.map(t => ({
          name: t.name,
          qualification: t.qualification,
          subjects: t.subjects,
          classes: t.classes,
          locality: t.locality,
          city: t.city,
          teachingMode: t.teachingMode,
          monthlyFee: t.monthlyFee,
          experienceYears: t.experienceYears,
          availability: t.availability
        }))
      })
    });

    if (res.ok) {
      const data = await res.json();
      if (data && data.reply && !data.fallback) {
        return { reply: data.reply, source: 'gemini' };
      }
    }
  } catch {
    // Network or server unavailable - fallback gracefully
  }

  // Graceful rule-based fallback
  const fallbackText = fallbackChatReply(message, DEMO_TUTORS);
  return { reply: fallbackText, source: 'rule-fallback' };
}

export async function matchTutorsWithAI(criteria: SmartMatchCriteria): Promise<{ results: MatchResult[]; source: 'gemini' | 'rule-fallback' }> {
  try {
    const res = await fetch('/api/gemini/match', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        criteria,
        tutors: DEMO_TUTORS
      })
    });

    if (res.ok) {
      const data = await res.json();
      if (data && Array.isArray(data.results) && data.results.length > 0 && !data.fallback) {
        // Re-hydrate tutor references with full local objects to ensure all UI features work
        const hydrated: MatchResult[] = data.results.map((r: any) => {
          const tutorObj = DEMO_TUTORS.find(t => t.id === r.tutorId || t.name === r.tutorName) || DEMO_TUTORS[0];
          return {
            tutor: tutorObj,
            matchScore: r.matchScore || 90,
            reasons: r.reasons || ['Strong subject match', 'Within budget'],
            feeFit: r.feeFit || 'Optimal',
            experienceFit: r.experienceFit || `${tutorObj.experienceYears} years experience`,
            modeFit: r.modeFit || tutorObj.teachingMode
          };
        });
        return { results: hydrated, source: 'gemini' };
      }
    }
  } catch {
    // Graceful fallback
  }

  const results = fallbackSmartMatcher(criteria, DEMO_TUTORS);
  return { results, source: 'rule-fallback' };
}

export async function generateStudyPlanWithAI(request: StudyPlanRequest): Promise<StudyPlanResponse> {
  try {
    const res = await fetch('/api/gemini/study-plan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request)
    });

    if (res.ok) {
      const data = await res.json();
      if (data && data.dailySchedule && !data.fallback) {
        return { ...data, source: 'gemini' };
      }
    }
  } catch {
    // Graceful fallback
  }

  return fallbackStudyPlanner(request);
}
