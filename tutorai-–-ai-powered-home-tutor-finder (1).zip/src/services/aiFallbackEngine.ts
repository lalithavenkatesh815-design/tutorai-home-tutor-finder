import { DEMO_TUTORS } from '../data/tutors';
import { SmartMatchCriteria, MatchResult, StudyPlanRequest, StudyPlanResponse, Tutor } from '../types/tutor';

/**
 * Intelligent Rule-Based Fallback Engine
 * Ensures TutorAI functions completely even if the Gemini API or network is unavailable.
 */

export function fallbackChatReply(userMessage: string, tutorList: Tutor[] = DEMO_TUTORS): string {
  const query = userMessage.toLowerCase().trim();

  // 1. Budget queries (e.g. "budget is ₹3000", "under 4000", "cheap tutors")
  const budgetMatch = query.match(/(?:budget|under|below|around|within|less than|max)\s*(?:is|of|rs\.?|inr|₹)?\s*(\d{3,5})/i);
  if (budgetMatch || query.includes('budget') || query.includes('affordable') || query.includes('fees') || query.includes('fee')) {
    let max = budgetMatch ? parseInt(budgetMatch[1], 10) : 4000;
    if (isNaN(max) || max < 1000) max = 4000;
    const affordable = tutorList.filter(t => t.monthlyFee <= max).sort((a, b) => a.monthlyFee - b.monthlyFee);
    if (affordable.length > 0) {
      const topTutors = affordable.slice(0, 3).map(t => `• **${t.name}** (₹${t.monthlyFee}/month, ${t.locality}): ${t.subjects.slice(0, 2).join(', ')} for ${t.classes.slice(0, 2).join(', ')} (${t.teachingMode})`).join('\n');
      return `Here are the top tutors within or around your budget of **₹${max.toLocaleString('en-IN')}/month**:\n\n${topTutors}\n\n💡 *Tip: You can use our Smart Fee Calculator to see hourly session breakdowns and customize your weekly schedule.*`;
    }
  }

  // 2. Class 10 / Class 12 / Specific Class
  const classMatch = query.match(/class\s*(\d{1,2})/i);
  if (classMatch) {
    const clsNum = classMatch[1];
    const targetClass = `Class ${clsNum}`;
    const matching = tutorList.filter(t => t.classes.some(c => c.toLowerCase().includes(targetClass.toLowerCase())));
    if (matching.length > 0) {
      const summary = matching.slice(0, 3).map(t => `• **${t.name}** (${t.locality}) – ${t.subjects.slice(0, 3).join(', ')} | Exp: ${t.experienceYears} yrs | ₹${t.monthlyFee}/mo`).join('\n');
      return `For **${targetClass}**, we have ${matching.length} specialized tutors ready to help:\n\n${summary}\n\nWould you like me to filter for home visits or online sessions for ${targetClass}?`;
    }
  }

  // 3. Subject queries (Maths, Physics, Chemistry, Biology, English, Coding, Economics)
  const subjectsMap: { [key: string]: string } = {
    math: 'Mathematics',
    maths: 'Mathematics',
    mathematics: 'Mathematics',
    physics: 'Physics',
    chem: 'Chemistry',
    chemistry: 'Chemistry',
    bio: 'Biology',
    biology: 'Biology',
    english: 'English',
    coding: 'Computer Science',
    python: 'Python',
    computer: 'Computer Science',
    economics: 'Economics',
    accounts: 'Accountancy',
    accountancy: 'Accountancy',
    hindi: 'Hindi',
    french: 'French',
    vedic: 'Vedic Math'
  };

  for (const [key, formalSubject] of Object.entries(subjectsMap)) {
    if (query.includes(key)) {
      const matching = tutorList.filter(t => t.subjects.some(s => s.toLowerCase().includes(key)));
      if (matching.length > 0) {
        const listStr = matching.slice(0, 3).map(t => `• **${t.name}** (${t.qualification}) – ${t.locality} | ₹${t.monthlyFee}/month | ${t.teachingMode}`).join('\n');
        return `We have dedicated tutors for **${formalSubject}**:\n\n${listStr}\n\nWould you like to compare their teaching methodologies or schedule a demo enquiry?`;
      }
    }
  }

  // 4. Most experienced tutor
  if (query.includes('experience') || query.includes('most experienced') || query.includes('senior')) {
    const sorted = [...tutorList].sort((a, b) => b.experienceYears - a.experienceYears);
    const top = sorted[0];
    const second = sorted[1];
    return `Our most experienced educator is **${top.name}** with **${top.experienceYears} years** of teaching (${top.subjects.join(', ')}, ${top.locality}).\n\nClosely followed by **${second.name}** with **${second.experienceYears} years** (${second.subjects.join(', ')}).\n\nBoth bring extensive board examination coaching background!`;
  }

  // 5. Questions to ask a home tutor before hiring
  if (query.includes('check') || query.includes('question') || query.includes('before choosing') || query.includes('hire') || query.includes('interview')) {
    return `Here are the **top 6 essential questions to ask a home tutor** before finalizing:\n\n1. **Diagnostic Assessment:** "Will you conduct an initial diagnostic test to map my child's strengths and weak spots?"\n2. **Curriculum & Board Alignment:** "How closely do your lesson plans follow the specific CBSE/ICSE/State Board syllabus?"\n3. **Doubt Resolution & Tests:** "What is your weekly assessment schedule, and how do you handle doubts outside class hours?"\n4. **Student Engagement:** "What teaching aids or real-world problem sets do you use to keep lessons engaging?"\n5. **Parent Feedback Loop:** "How often will you update us on progress, test scores, and homework consistency?"\n6. **Cancellation & Rescheduling:** "What is your policy if the student falls sick or needs to reschedule a session?"\n\n*All TutorAI profiles display verified qualifications and structured teaching methodologies to help you decide.*`;
  }

  // 6. Routine / Study Plan guidance
  if (query.includes('study routine') || query.includes('timetable') || query.includes('schedule') || query.includes('plan')) {
    return `Here is an optimal **3-Phase Daily Home Study Blueprint**:\n\n• **Phase 1: High Cognitive Focus (5:00 PM – 6:15 PM)**\n  Start with analytical subjects like Mathematics or Physics when energy is high. Solve numericals.\n• **Phase 2: Active Recall & Reading (6:30 PM – 7:45 PM)**\n  Study conceptual topics in Biology, History, or Literature. Use flashcards and mind-maps.\n• **Phase 3: Review & Doubt Tagging (8:00 PM – 8:45 PM)**\n  Review school homework, write down 3 doubts to ask your home tutor, and complete quick formula recall.\n\n👉 *You can generate a customized, printable plan in our **AI Study Planner** tab!*`;
  }

  // 7. Compare tutors query
  if (query.includes('compare')) {
    return `You can compare up to **3 tutors side-by-side** using our **Compare Tutors** tab! It compares monthly fees, session rates, years of experience, teaching modes, and weekly time slots side-by-side. Simply click the "Compare" button on any tutor card to add them.`;
  }

  // Default helpful response
  return `I am **TutorChat**, your AI learning advisor. I can help you with:\n\n• Finding tutors by subject (Maths, Science, English, Coding, Commerce)\n• Searching by locality (Koramangala, Indiranagar, HSR, Anna Nagar, Bandra, etc.)\n• Recommending tutors within your monthly budget (₹2,500 – ₹7,000)\n• Suggesting essential questions to ask a tutor before hiring\n• Creating custom study plans for upcoming exams\n\nWhat grade is your child in, and which subject are you looking for?`;
}

/**
 * Intelligent Rule-Based Smart Matcher
 */
export function fallbackSmartMatcher(criteria: SmartMatchCriteria, tutorList: Tutor[] = DEMO_TUTORS): MatchResult[] {
  const scored = tutorList.map(tutor => {
    let score = 50; // base score
    const reasons: string[] = [];

    // Subject match
    const cleanSub = criteria.subject.toLowerCase();
    const subMatch = tutor.subjects.some(s => s.toLowerCase().includes(cleanSub) || cleanSub.includes(s.toLowerCase()));
    if (subMatch) {
      score += 25;
      reasons.push(`Direct subject expertise in ${tutor.subjects.find(s => s.toLowerCase().includes(cleanSub) || cleanSub.includes(s.toLowerCase())) || criteria.subject}`);
    } else {
      reasons.push(`Provides broad academic coaching across related disciplines`);
    }

    // Class match
    const cleanClass = criteria.studentClass.toLowerCase();
    const classMatch = tutor.classes.some(c => c.toLowerCase().includes(cleanClass) || cleanClass.includes(c.toLowerCase()));
    if (classMatch) {
      score += 15;
      reasons.push(`Specialized curriculum experience for ${criteria.studentClass}`);
    }

    // Locality / Area match
    const cleanLoc = criteria.locality.toLowerCase();
    if (cleanLoc && (tutor.locality.toLowerCase().includes(cleanLoc) || tutor.city.toLowerCase().includes(cleanLoc))) {
      score += 15;
      reasons.push(`Conveniently located near ${tutor.locality}`);
    } else if (tutor.teachingMode !== 'Home Visit Only') {
      score += 5;
      reasons.push(`Available via ${tutor.teachingMode} regardless of distance`);
    }

    // Budget match
    if (criteria.budget > 0) {
      if (tutor.monthlyFee <= criteria.budget) {
        score += 10;
        reasons.push(`Within specified budget (₹${tutor.monthlyFee}/month vs ₹${criteria.budget} max)`);
      } else if (tutor.monthlyFee <= criteria.budget * 1.15) {
        reasons.push(`Slightly above budget (₹${tutor.monthlyFee}) but offers high experience`);
      }
    }

    // Teaching mode match
    if (criteria.teachingMode && criteria.teachingMode !== 'Any Mode') {
      if (tutor.teachingMode.toLowerCase().includes(criteria.teachingMode.toLowerCase()) || tutor.teachingMode.includes('Hybrid')) {
        score += 10;
        reasons.push(`Supports your preferred format: ${tutor.teachingMode}`);
      }
    }

    // Experience boost
    if (tutor.experienceYears >= 10) {
      score += 5;
      reasons.push(`Senior mentor with ${tutor.experienceYears} years of teaching track record`);
    }

    const finalScore = Math.min(99, Math.max(45, score));

    return {
      tutor,
      matchScore: finalScore,
      reasons: reasons.slice(0, 4),
      feeFit: tutor.monthlyFee <= criteria.budget ? 'Within Budget' : 'Moderate Adjustment',
      experienceFit: `${tutor.experienceYears} years proven track record`,
      modeFit: tutor.teachingMode
    };
  });

  return scored.sort((a, b) => b.matchScore - a.matchScore).slice(0, 3);
}

/**
 * Intelligent Rule-Based Study Planner
 */
export function fallbackStudyPlanner(req: StudyPlanRequest): StudyPlanResponse {
  const subjects = req.subjects.length > 0 ? req.subjects : ['Core Subject 1', 'Core Subject 2'];
  const dailyHours = req.dailyHours || 3;
  const examDateStr = req.examDate ? new Date(req.examDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Upcoming Examinations';

  const slotMinutes = Math.floor((dailyHours * 60) / (subjects.length + 1));

  const dailySchedule = [
    {
      timeSlot: '05:00 PM – 05:45 PM',
      activity: 'Concept Deep-Dive & Theory Revision',
      subject: subjects[0] || 'Primary Subject',
      focus: req.weakTopics ? `Focus on weak topics: ${req.weakTopics}` : 'NCERT / Textbook line-by-line reading and definition notes'
    },
    {
      timeSlot: '05:45 PM – 06:00 PM',
      activity: 'Active Refreshment & Hydration Break',
      subject: 'Rest',
      focus: 'Walk around, avoid smartphone screens, drink water'
    },
    {
      timeSlot: '06:00 PM – 07:00 PM',
      activity: 'Problem Solving & Numerical Drills',
      subject: subjects[1] || subjects[0] || 'Analytical Subject',
      focus: 'Timed practice with textbook exemplar and past 5-year question papers'
    },
    {
      timeSlot: '07:15 PM – 08:00 PM',
      activity: 'Active Recall, Flashcards & Home Tutor Doubt Logging',
      subject: subjects.length > 2 ? subjects[2] : subjects[0],
      focus: 'Formulate 3 clear questions to discuss with your home tutor during the next session'
    }
  ];

  return {
    overview: `Personalized ${dailyHours}-hour daily roadmap for ${req.studentClass || 'High School'} preparing for ${examDateStr}. Designed to maximize conceptual retention and overcome doubts in ${req.weakTopics || 'key topics'}.`,
    dailySchedule,
    weeklyGoals: [
      `Complete 1 full chapter syllabus + exemplar exercises in ${subjects[0]}`,
      `Solve 25 board exam format questions under 45-minute timed conditions`,
      `Conduct a 1-on-1 review of flagged doubts with your home tutor`,
      `Review weekly summary notes every Sunday morning`
    ],
    revisionStrategy: [
      'Use 25-minute Pomodoro study sprints with 5-minute cognitive rests.',
      'Maintain a dedicated "Mistake Notebook" where all calculation and conceptual errors are recorded and reviewed weekly.',
      'Teach back each solved concept in your own words to your parent or study buddy (Feynman Technique).'
    ],
    pomodoroAdvice: `For your ${dailyHours}-hour schedule: Complete 4 Pomodoro blocks (25 mins study + 5 mins rest), followed by one 20-minute long relaxation break. Avoid phone notifications during sprints.`,
    examTips: [
      'Prioritize high-weightage chapters first according to board marking schemes.',
      'Practice drawing diagrams and labeling them with a pencil within 3 minutes.',
      'Never leave step-marking questions blank; write down given values and applicable formulas.'
    ],
    source: 'rule-fallback'
  };
}
