import React, { useState } from 'react';
import { Info, X } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { DirectoryPage } from './pages/DirectoryPage';
import { TutorModal } from './components/TutorModal';
import { TutorChatWidget } from './components/TutorChatWidget';
import { CompareDrawer } from './components/CompareDrawer';
import { FeeCalculator } from './components/FeeCalculator';
import { MapExplorer } from './components/MapExplorer';
import { SmartMatchModal } from './components/SmartMatchModal';
import { StudyPlannerModal } from './components/StudyPlannerModal';
import { ContactModal } from './components/ContactModal';
import { BecomeTutorModal } from './components/BecomeTutorModal';
import { PaymentDemoModal } from './components/PaymentDemoModal';
import { FavouritesModal } from './components/FavouritesModal';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Tutor, SearchFilters } from './types/tutor';
import { DEMO_TUTORS } from './data/tutors';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  
  // LocalStorage persistence for non-sensitive favourites and comparison
  const [favorites, setFavorites] = useLocalStorage<Tutor[]>('tutorai_favorites', []);
  const [comparedTutors, setComparedTutors] = useLocalStorage<Tutor[]>('tutorai_compared', [DEMO_TUTORS[0], DEMO_TUTORS[1]]);

  // Modal states
  const [selectedProfileTutor, setSelectedProfileTutor] = useState<Tutor | null>(null);
  const [selectedContactTutor, setSelectedContactTutor] = useState<Tutor | null>(null);
  const [selectedPaymentTutor, setSelectedPaymentTutor] = useState<Tutor | null>(null);
  const [preSelectedMapTutor, setPreSelectedMapTutor] = useState<Tutor | null>(null);

  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [isSmartMatchOpen, setIsSmartMatchOpen] = useState(false);
  const [isStudyPlannerOpen, setIsStudyPlannerOpen] = useState(false);
  const [isBecomeTutorOpen, setIsBecomeTutorOpen] = useState(false);

  // Directory search filters state passed from Hero or Calculator
  const [directoryFilters, setDirectoryFilters] = useState<Partial<SearchFilters>>({});

  // Favourites toggle
  const handleToggleFavorite = (tutor: Tutor) => {
    setFavorites((prev) => {
      const exists = prev.some((t) => t.id === tutor.id);
      if (exists) {
        return prev.filter((t) => t.id !== tutor.id);
      } else {
        return [...prev, tutor];
      }
    });
  };

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Compare toggle (max 3 tutors)
  const handleToggleCompare = (tutor: Tutor) => {
    setComparedTutors((prev) => {
      const exists = prev.some((t) => t.id === tutor.id);
      if (exists) {
        return prev.filter((t) => t.id !== tutor.id);
      } else {
        if (prev.length >= 3) {
          setToastMessage('You can compare a maximum of 3 tutors simultaneously. Please remove one tutor to add another.');
          setTimeout(() => setToastMessage(null), 4500);
          return prev;
        }
        return [...prev, tutor];
      }
    });
  };

  const handleRemoveCompare = (tutorId: string) => {
    setComparedTutors((prev) => prev.filter((t) => t.id !== tutorId));
  };

  const handleClearCompare = () => {
    setComparedTutors([]);
    setIsCompareOpen(false);
  };

  // Navigate to Directory with preset filters
  const handleHeroSearch = (params: { query: string; subject: string; locality: string; studentClass: string; category?: string }) => {
    setDirectoryFilters({
      query: params.query,
      subject: params.subject,
      locality: params.locality,
      studentClass: params.studentClass,
      category: params.category || ''
    });
    setActiveTab('directory');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFindTutorsInBudget = (maxBudget: number) => {
    setDirectoryFilters({
      maxFee: maxBudget
    });
    setActiveTab('directory');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Open map for specific tutor
  const handleExploreTutorOnMap = (tutor: Tutor) => {
    setPreSelectedMapTutor(tutor);
    setActiveTab('map');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6EF] text-[#242B27] selection:bg-[#174C3C] selection:text-[#F8F6EF]">
      
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'smart-match') {
            setIsSmartMatchOpen(true);
          } else if (tab === 'study-planner') {
            setIsStudyPlannerOpen(true);
          } else if (tab === 'become-tutor') {
            setIsBecomeTutorOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        favoritesCount={favorites.length}
        compareCount={comparedTutors.length}
        onOpenFavorites={() => setIsFavoritesOpen(true)}
        onOpenCompare={() => setIsCompareOpen(true)}
        onOpenChat={() => setIsChatOpen(true)}
      />

      {/* In-app Toast Banner (avoiding window.alert in sandboxed iframe) */}
      {toastMessage && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-[#174C3C] text-white px-5 py-3 rounded-2xl shadow-xl border border-[#E6BD68]/40 flex items-center space-x-2.5 text-xs font-bold animate-fade-in max-w-md">
          <Info className="w-4 h-4 text-[#E6BD68] flex-shrink-0" />
          <span className="flex-1">{toastMessage}</span>
          <button 
            onClick={() => setToastMessage(null)} 
            className="p-1 text-[#A8B9A0] hover:text-white rounded-lg cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main View Area */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <HomePage
            onSearch={handleHeroSearch}
            onOpenSmartMatch={() => setIsSmartMatchOpen(true)}
            onOpenStudyPlanner={() => setIsStudyPlannerOpen(true)}
            onOpenCalculator={() => setActiveTab('calculator')}
            onOpenChat={() => setIsChatOpen(true)}
            onViewTutorProfile={(tutor) => setSelectedProfileTutor(tutor)}
            onContactTutor={(tutor) => setSelectedContactTutor(tutor)}
            favorites={favorites}
            comparedTutors={comparedTutors}
            onToggleFavorite={handleToggleFavorite}
            onToggleCompare={handleToggleCompare}
          />
        )}

        {activeTab === 'directory' && (
          <DirectoryPage
            initialFilters={directoryFilters}
            onViewProfile={(tutor) => setSelectedProfileTutor(tutor)}
            onContact={(tutor) => setSelectedContactTutor(tutor)}
            favorites={favorites}
            comparedTutors={comparedTutors}
            onToggleFavorite={handleToggleFavorite}
            onToggleCompare={handleToggleCompare}
          />
        )}

        {activeTab === 'calculator' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <FeeCalculator onFindTutorsInBudget={handleFindTutorsInBudget} />
          </div>
        )}

        {activeTab === 'map' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <MapExplorer
              preSelectedTutor={preSelectedMapTutor}
              onSelectTutor={(tutor) => setSelectedProfileTutor(tutor)}
              onContactTutor={(tutor) => setSelectedContactTutor(tutor)}
            />
          </div>
        )}
      </main>

      {/* Sticky Bottom Comparison Drawer */}
      <CompareDrawer
        comparedTutors={comparedTutors}
        onRemove={handleRemoveCompare}
        onClear={handleClearCompare}
        onContact={(tutor) => setSelectedContactTutor(tutor)}
        isOpen={isCompareOpen}
        onClose={() => setIsCompareOpen(false)}
        onOpen={() => setIsCompareOpen(true)}
      />

      {/* Floating TutorChat AI Widget */}
      <TutorChatWidget
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        onOpen={() => setIsChatOpen(true)}
        onNavigateToTab={(tab) => setActiveTab(tab)}
      />

      {/* Profile Details Modal */}
      <TutorModal
        tutor={selectedProfileTutor}
        onClose={() => setSelectedProfileTutor(null)}
        isFavorite={selectedProfileTutor ? favorites.some((f) => f.id === selectedProfileTutor.id) : false}
        isCompared={selectedProfileTutor ? comparedTutors.some((c) => c.id === selectedProfileTutor.id) : false}
        onToggleFavorite={handleToggleFavorite}
        onToggleCompare={handleToggleCompare}
        onContact={(tutor) => setSelectedContactTutor(tutor)}
        onExploreMap={handleExploreTutorOnMap}
        onDemoPayment={(tutor) => setSelectedPaymentTutor(tutor)}
      />

      {/* Contact Enquiry Modal */}
      <ContactModal
        tutor={selectedContactTutor}
        isOpen={Boolean(selectedContactTutor)}
        onClose={() => setSelectedContactTutor(null)}
      />

      {/* AI Smart Match Modal */}
      <SmartMatchModal
        isOpen={isSmartMatchOpen}
        onClose={() => setIsSmartMatchOpen(false)}
        onViewTutor={(tutor) => setSelectedProfileTutor(tutor)}
        onContactTutor={(tutor) => setSelectedContactTutor(tutor)}
      />

      {/* AI Study Planner Modal */}
      <StudyPlannerModal
        isOpen={isStudyPlannerOpen}
        onClose={() => setIsStudyPlannerOpen(false)}
      />

      {/* Become a Tutor Modal */}
      <BecomeTutorModal
        isOpen={isBecomeTutorOpen}
        onClose={() => setIsBecomeTutorOpen(false)}
      />

      {/* Demo Payment Modal */}
      <PaymentDemoModal
        tutor={selectedPaymentTutor}
        isOpen={Boolean(selectedPaymentTutor)}
        onClose={() => setSelectedPaymentTutor(null)}
      />

      {/* Favourites Modal */}
      <FavouritesModal
        isOpen={isFavoritesOpen}
        onClose={() => setIsFavoritesOpen(false)}
        favorites={favorites}
        onRemoveFavorite={handleToggleFavorite}
        onClearFavorites={() => setFavorites([])}
        onViewProfile={(tutor) => setSelectedProfileTutor(tutor)}
        onContact={(tutor) => setSelectedContactTutor(tutor)}
      />

      {/* Footer */}
      <Footer
        onNavigate={(tab) => {
          if (tab === 'smart-match') setIsSmartMatchOpen(true);
          else if (tab === 'study-planner') setIsStudyPlannerOpen(true);
          else if (tab === 'calculator') setActiveTab('calculator');
          else if (tab === 'map') setActiveTab('map');
          else setActiveTab('directory');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenChat={() => setIsChatOpen(true)}
        onBecomeTutor={() => setIsBecomeTutorOpen(true)}
      />

    </div>
  );
}
