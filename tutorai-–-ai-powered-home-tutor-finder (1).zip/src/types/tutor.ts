export type TeachingMode = 'Home Visit Only' | 'Online Only' | 'Hybrid (Home + Online)';

export type TutorCategory = 
  | 'Mathematics'
  | 'Science'
  | 'English and Languages'
  | 'Computer Science and Programming'
  | 'Social Science'
  | 'Physics and Chemistry specialists'
  | 'Commerce and Accounts'
  | 'Music, Art and Other Skills';

export interface Tutor {
  id: string;
  name: string;
  qualification: string;
  category: TutorCategory;
  subjects: string[];
  classes: string[];
  curriculum: string[];
  experienceYears: number;
  locality: string;
  city: string;
  coordinates: [number, number]; // [latitude, longitude]
  teachingMode: TeachingMode;
  monthlyFee: number; // in INR
  sessionFee: number; // approx per session in INR
  availability: string;
  availableDays: string[];
  availableTimeSlots: string[];
  rating: number;
  reviewCount: number;
  languages: string[];
  bio: string;
  methodology: string;
  avatar: string;
  featured?: boolean;
}

export interface SearchFilters {
  query: string;
  category: string;
  subject: string;
  locality: string;
  studentClass: string;
  teachingMode: string;
  maxFee: number;
  minExperience: number;
  sortBy: 'relevance' | 'fee-asc' | 'fee-desc' | 'exp-desc' | 'rating-desc' | 'name-asc';
}

export interface SmartMatchCriteria {
  studentClass: string;
  subject: string;
  locality: string;
  budget: number;
  teachingMode: string;
  learningGoals: string;
  schedulePreference: string;
}

export interface MatchResult {
  tutor: Tutor;
  matchScore: number; // 0-100
  reasons: string[];
  feeFit: string;
  experienceFit: string;
  modeFit: string;
}

export interface StudyPlanRequest {
  studentClass: string;
  subjects: string[];
  examDate: string;
  dailyHours: number;
  weakTopics: string;
  learningGoals: string;
}

export interface StudyPlanResponse {
  overview: string;
  dailySchedule: { timeSlot: string; activity: string; subject: string; focus: string }[];
  weeklyGoals: string[];
  revisionStrategy: string[];
  pomodoroAdvice: string;
  examTips: string[];
  source: 'gemini' | 'rule-fallback';
}
