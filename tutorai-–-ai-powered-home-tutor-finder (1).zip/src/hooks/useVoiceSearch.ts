import { useState, useEffect, useCallback, useRef } from 'react';

// Declare SpeechRecognition interface for TypeScript
interface IWindow extends Window {
  SpeechRecognition?: any;
  webkitSpeechRecognition?: any;
}

export function useVoiceSearch(onResultCallback?: (text: string) => void) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const win = window as unknown as IWindow;
      const SpeechRecognitionClass = win.SpeechRecognition || win.webkitSpeechRecognition;
      if (SpeechRecognitionClass) {
        setIsSupported(true);
        try {
          const recognition = new SpeechRecognitionClass();
          recognition.continuous = false;
          recognition.interimResults = true;
          recognition.lang = 'en-IN'; // Indian English default, also captures Hindi terms like "Class dusvin", "Maths"

          recognition.onstart = () => {
            setIsListening(true);
            setError(null);
          };

          recognition.onresult = (event: any) => {
            let current = '';
            for (let i = event.resultIndex; i < event.results.length; i++) {
              current += event.results[i][0].transcript;
            }
            setTranscript(current);
            if (onResultCallback && event.results[event.results.length - 1].isFinal) {
              onResultCallback(current);
            }
          };

          recognition.onerror = (event: any) => {
            if (event.error === 'not-allowed') {
              setError('Microphone permission denied. Please allow microphone access to use voice search.');
            } else if (event.error === 'no-speech') {
              setError('No speech detected. Please try speaking again.');
            } else {
              setError(`Voice recognition error: ${event.error}`);
            }
            setIsListening(false);
          };

          recognition.onend = () => {
            setIsListening(false);
          };

          recognitionRef.current = recognition;
        } catch (e: any) {
          console.warn('Speech recognition setup failed:', e);
          setIsSupported(false);
        }
      } else {
        setIsSupported(false);
      }
    }
  }, [onResultCallback]);

  const startListening = useCallback(() => {
    setError(null);
    if (!isSupported || !recognitionRef.current) {
      setError('Voice recognition is not supported in this browser. Please type your search.');
      return;
    }
    try {
      setTranscript('');
      recognitionRef.current.start();
    } catch {
      // If already started, stop and restart
      try {
        recognitionRef.current.stop();
        setTimeout(() => recognitionRef.current?.start(), 150);
      } catch (err) {
        setError('Could not start microphone.');
      }
    }
  }, [isSupported]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // ignore
      }
    }
    setIsListening(false);
  }, []);

  const resetTranscript = useCallback(() => {
    setTranscript('');
    setError(null);
  }, []);

  return {
    isListening,
    transcript,
    error,
    isSupported,
    startListening,
    stopListening,
    resetTranscript
  };
}
