import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  Mic, 
  MicOff, 
  SlidersHorizontal, 
  RotateCcw, 
  Star, 
  GraduationCap, 
  MapPin, 
  Filter, 
  ShieldAlert, 
  Layers, 
  Heart, 
  Send,
  Eye,
  CheckCircle2,
  Sparkles,
  ChevronDown
} from 'lucide-react';
import { DEMO_TUTORS, ALL_SUBJECTS, ALL_CLASSES, ALL_LOCALITIES, TUTOR_CATEGORIES } from '../data/tutors';
import { Tutor, SearchFilters } from '../types/tutor';
import { TutorCard } from '../components/TutorCard';
import { useVoiceSearch } from '../hooks/useVoiceSearch';

interface DirectoryPageProps {
  initialFilters?: Partial<SearchFilters>;
  onViewProfile: (tutor: Tutor) => void;
  onContact: (tutor: Tutor) => void;
  favorites: Tutor[];
  comparedTutors: Tutor[];
  onToggleFavorite: (tutor: Tutor) => void;
  onToggleCompare: (tutor: Tutor) => void;
}

const PAGE_SIZE = 12;

export const DirectoryPage: React.FC<DirectoryPageProps> = ({
  initialFilters,
  onViewProfile,
  onContact,
  favorites,
  comparedTutors,
  onToggleFavorite,
  onToggleCompare,
}) => {
  const [filters, setFilters] = useState<SearchFilters>({
    query: initialFilters?.query || '',
    category: initialFilters?.category || '',
    subject: initialFilters?.subject || '',
    locality: initialFilters?.locality || '',
    studentClass: initialFilters?.studentClass || '',
    teachingMode: initialFilters?.teachingMode || '',
    maxFee: initialFilters?.maxFee || 8000,
    minExperience: initialFilters?.minExperience || 0,
    sortBy: initialFilters?.sortBy || 'relevance'
  });

  // Track page / visible item count for pagination
  const [visibleCount, setVisibleCount] = useState<number>(PAGE_SIZE);

  // Sync initial filters when props change
  useEffect(() => {
    if (initialFilters) {
      setFilters(prev => ({
        ...prev,
        ...initialFilters
      }));
      setVisibleCount(PAGE_SIZE);
    }
  }, [initialFilters]);

  // Reset pagination when any filter changes
  const handleFilterChange = (updates: Partial<SearchFilters>) => {
    setFilters(prev => ({ ...prev, ...updates }));
    setVisibleCount(PAGE_SIZE);
  };

  // Voice Search Hook
  const { isListening, error: voiceError, startListening, stopListening } = useVoiceSearch((spokenText) => {
    handleFilterChange({ query: spokenText });
  });

  const handleResetFilters = () => {
    setFilters({
      query: '',
      category: '',
      subject: '',
      locality: '',
      studentClass: '',
      teachingMode: '',
      maxFee: 8000,
      minExperience: 0,
      sortBy: 'relevance'
    });
    setVisibleCount(PAGE_SIZE);
  };

  // Filter & Sort Logic across 40 tutors
  const filteredTutors = useMemo(() => {
    return DEMO_TUTORS.filter((tutor) => {
      // 1. Category Tab Filter
      if (filters.category && filters.category !== 'All') {
        if (tutor.category !== filters.category) {
          return false;
        }
      }

      // 2. Text Query
      if (filters.query.trim()) {
        const q = filters.query.toLowerCase().trim();
        const matchesName = tutor.name.toLowerCase().includes(q);
        const matchesQual = tutor.qualification.toLowerCase().includes(q);
        const matchesLoc = tutor.locality.toLowerCase().includes(q) || tutor.city.toLowerCase().includes(q);
        const matchesSub = tutor.subjects.some(s => s.toLowerCase().includes(q));
        const matchesClass = tutor.classes.some(c => c.toLowerCase().includes(q));
        const matchesBio = tutor.bio.toLowerCase().includes(q);
        const matchesCategory = tutor.category.toLowerCase().includes(q);

        if (!matchesName && !matchesQual && !matchesLoc && !matchesSub && !matchesClass && !matchesBio && !matchesCategory) {
          return false;
        }
      }

      // 3. Subject Filter
      if (filters.subject) {
        const hasSub = tutor.subjects.some(s => s.toLowerCase().includes(filters.subject.toLowerCase()));
        if (!hasSub) return false;
      }

      // 4. Locality Filter
      if (filters.locality) {
        const matchesLoc = tutor.locality.toLowerCase().includes(filters.locality.toLowerCase()) || 
                           tutor.city.toLowerCase().includes(filters.locality.toLowerCase());
        if (!matchesLoc) return false;
      }

      // 5. Class Filter
      if (filters.studentClass) {
        const matchesClass = tutor.classes.some(c => c.toLowerCase().includes(filters.studentClass.toLowerCase()));
        if (!matchesClass) return false;
      }

      // 6. Teaching Mode
      if (filters.teachingMode && filters.teachingMode !== 'All Modes') {
        if (!tutor.teachingMode.includes(filters.teachingMode) && !tutor.teachingMode.includes('Hybrid')) {
          return false;
        }
      }

      // 7. Max Fee
      if (tutor.monthlyFee > filters.maxFee) {
        return false;
      }

      // 8. Minimum Experience
      if (tutor.experienceYears < filters.minExperience) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'fee-asc') return a.monthlyFee - b.monthlyFee;
      if (filters.sortBy === 'fee-desc') return b.monthlyFee - a.monthlyFee;
      if (filters.sortBy === 'exp-desc') return b.experienceYears - a.experienceYears;
      if (filters.sortBy === 'rating-desc') return b.rating - a.rating;
      if (filters.sortBy === 'name-asc') return a.name.localeCompare(b.name);
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });
  }, [filters]);

  const displayedTutors = useMemo(() => {
    return filteredTutors.slice(0, visibleCount);
  }, [filteredTutors, visibleCount]);

  const hasMoreTutors = visibleCount < filteredTutors.length;

  const handleLoadMore = () => {
    setVisibleCount(prev => Math.min(prev + 8, filteredTutors.length));
  };

  const activeFiltersCount = [
    Boolean(filters.query),
    Boolean(filters.category && filters.category !== 'All'),
    Boolean(filters.subject),
    Boolean(filters.locality),
    Boolean(filters.studentClass),
    Boolean(filters.teachingMode && filters.teachingMode !== 'All Modes'),
    filters.maxFee < 8000,
    filters.minExperience > 0
  ].filter(Boolean).length;

  const popularSuggestions = [
    'Class 10 CBSE Maths',
    'Vijayapura',
    'Dharwad',
    'NEET Physics',
    'Python Coding',
    'Spoken English',
    'Vocal Music'
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 bg-[#F8F6EF]">
      
      {/* Directory Title Banner (Editorial Header) */}
      <div className="bg-[#174C3C] rounded-3xl p-6 sm:p-8 text-[#F8F6EF] flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl border border-[#12382c]">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#FFFFFF]/10 text-[#E6BD68] border border-[#FFFFFF]/15 text-xs font-bold mb-2">
            <GraduationCap className="w-4 h-4 text-[#E6BD68]" />
            <span>Curated Directory — 40 Demonstration Profiles</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-serif font-bold text-[#F8F6EF]">
            Find Your Trusted Home Tutor
          </h1>
          <p className="text-xs sm:text-sm text-[#A8B9A0] mt-1 max-w-2xl leading-relaxed">
            Browse our 40 verified demonstration educators spanning 8 core academic disciplines, boards, and metro areas. Compare profiles, inspect weekly availability matrices, and send direct demo enquiries.
          </p>
        </div>

        <div className="bg-[#FFFFFF]/10 border border-[#FFFFFF]/15 rounded-2xl p-4 text-xs text-[#F8F6EF] max-w-xs shadow-inner">
          <div className="flex items-center space-x-1.5 font-bold mb-1 text-[#E6BD68]">
            <ShieldAlert className="w-4 h-4 text-[#D87952]" />
            <span>Academic Demonstration</span>
          </div>
          <p className="text-[11px] text-[#A8B9A0] leading-relaxed">
            All tutor cards represent simulated profiles for demonstration purposes. Zero login or password creation required.
          </p>
        </div>
      </div>

      {/* CATEGORY TABS BAR */}
      <div className="overflow-x-auto pb-2 scrollbar-none">
        <div className="flex items-center space-x-2 min-w-max">
          <button
            type="button"
            onClick={() => handleFilterChange({ category: '' })}
            className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
              !filters.category
                ? 'bg-[#174C3C] text-[#F8F6EF] shadow-sm'
                : 'bg-[#FFFFFF] text-[#242B27] border border-[#E5E0D0] hover:border-[#174C3C]'
            }`}
          >
            All Categories ({DEMO_TUTORS.length})
          </button>

          {TUTOR_CATEGORIES.map(cat => {
            const isSelected = filters.category === cat.name;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleFilterChange({ category: cat.name })}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                  isSelected
                    ? 'bg-[#174C3C] text-[#F8F6EF] shadow-sm'
                    : 'bg-[#FFFFFF] text-[#242B27] border border-[#E5E0D0] hover:border-[#174C3C]'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.name}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? 'bg-[#FFFFFF]/20 text-[#F8F6EF]' : 'bg-[#174C3C]/10 text-[#174C3C]'}`}>
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Container: Filter Sidebar (Left 4 cols) + Search & Cards (Right 8 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* FILTERS SIDEBAR */}
        <aside className="lg:col-span-4 bg-[#FFFFFF] rounded-3xl p-6 border border-[#E5E0D0] shadow-sm space-y-6 sticky top-28">
          <div className="flex items-center justify-between pb-4 border-b border-[#E5E0D0]">
            <div className="flex items-center space-x-2">
              <SlidersHorizontal className="w-4 h-4 text-[#174C3C]" />
              <h3 className="font-serif font-bold text-[#242B27] text-sm">Refine Directory</h3>
              {activeFiltersCount > 0 && (
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-[#D87952] text-[#FFFFFF]">
                  {activeFiltersCount}
                </span>
              )}
            </div>

            {activeFiltersCount > 0 && (
              <button
                onClick={handleResetFilters}
                className="text-xs text-[#D87952] hover:text-[#c46944] font-bold flex items-center space-x-1 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>

          {/* Student Class / Grade */}
          <div>
            <label className="text-xs font-bold text-[#242B27] block mb-1.5">Student Class / Grade</label>
            <select
              value={filters.studentClass}
              onChange={(e) => handleFilterChange({ studentClass: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] text-xs sm:text-sm text-[#242B27] bg-[#FDFCF7] focus:outline-none focus:border-[#174C3C]"
            >
              <option value="">All Classes & Levels</option>
              {ALL_CLASSES.map(cls => (
                <option key={cls} value={cls}>{cls}</option>
              ))}
            </select>
          </div>

          {/* Subject Filter */}
          <div>
            <label className="text-xs font-bold text-[#242B27] block mb-1.5">Subject Stream</label>
            <select
              value={filters.subject}
              onChange={(e) => handleFilterChange({ subject: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] text-xs sm:text-sm text-[#242B27] bg-[#FDFCF7] focus:outline-none focus:border-[#174C3C]"
            >
              <option value="">All Subjects</option>
              {ALL_SUBJECTS.map(sub => (
                <option key={sub} value={sub}>{sub}</option>
              ))}
            </select>
          </div>

          {/* Locality Filter */}
          <div>
            <label className="text-xs font-bold text-[#242B27] block mb-1.5">Locality / City</label>
            <select
              value={filters.locality}
              onChange={(e) => handleFilterChange({ locality: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] text-xs sm:text-sm text-[#242B27] bg-[#FDFCF7] focus:outline-none focus:border-[#174C3C]"
            >
              <option value="">All Teaching Localities</option>
              {ALL_LOCALITIES.map(loc => (
                <option key={loc} value={loc.split(' (')[0]}>{loc}</option>
              ))}
            </select>
          </div>

          {/* Teaching Mode */}
          <div>
            <label className="text-xs font-bold text-[#242B27] block mb-1.5">Teaching Mode</label>
            <div className="grid grid-cols-2 gap-2">
              {['All Modes', 'Home Visit Only', 'Online Only', 'Hybrid'].map(mode => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => handleFilterChange({ teachingMode: mode === 'All Modes' ? '' : mode })}
                  className={`py-2 px-2 rounded-xl text-xs font-semibold text-center transition-all cursor-pointer ${
                    (filters.teachingMode === mode || (!filters.teachingMode && mode === 'All Modes'))
                      ? 'bg-[#174C3C] text-[#F8F6EF] shadow-sm'
                      : 'bg-[#F8F6EF] text-[#242B27] border border-[#E5E0D0] hover:bg-[#FFFFFF]'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          {/* Max Monthly Fee Slider */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-bold text-[#242B27]">Max Monthly Fee (INR)</label>
              <span className="text-xs font-bold font-mono text-[#174C3C] bg-[#174C3C]/10 px-2 py-0.5 rounded-md">
                ₹{filters.maxFee.toLocaleString('en-IN')}/mo
              </span>
            </div>
            <input
              type="range"
              min="1500"
              max="8000"
              step="500"
              value={filters.maxFee}
              onChange={(e) => handleFilterChange({ maxFee: parseInt(e.target.value, 10) })}
              className="w-full h-2 bg-[#E5E0D0] rounded-lg appearance-none cursor-pointer accent-[#174C3C]"
            />
            <div className="flex justify-between text-[10px] text-[#737D74] mt-1 font-mono">
              <span>₹1,500</span>
              <span>₹4,500</span>
              <span>₹8,000</span>
            </div>
          </div>

          {/* Minimum Experience */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-bold text-[#242B27]">Minimum Experience</label>
              <span className="text-xs font-bold text-[#242B27]">
                {filters.minExperience === 0 ? 'Any Experience' : `${filters.minExperience}+ Years`}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="15"
              step="1"
              value={filters.minExperience}
              onChange={(e) => handleFilterChange({ minExperience: parseInt(e.target.value, 10) })}
              className="w-full h-2 bg-[#E5E0D0] rounded-lg appearance-none cursor-pointer accent-[#174C3C]"
            />
            <div className="flex justify-between text-[10px] text-[#737D74] mt-1 font-mono">
              <span>0 Yrs</span>
              <span>7 Yrs</span>
              <span>15+ Yrs</span>
            </div>
          </div>

        </aside>

        {/* SEARCH & RESULTS (Right 8 cols) */}
        <main className="lg:col-span-8 space-y-6">
          
          {/* Top Search Bar & Sort Controls */}
          <div className="bg-[#FFFFFF] rounded-2xl p-4 border border-[#E5E0D0] shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
            
            {/* Search Input with Voice Icon */}
            <div className="relative w-full sm:w-auto flex-1 flex items-center">
              <Search className="w-4 h-4 text-[#737D74] absolute left-3.5 pointer-events-none" />
              <input
                type="text"
                value={filters.query}
                onChange={(e) => handleFilterChange({ query: e.target.value })}
                placeholder="Search tutor name, qualification, subject, locality..."
                className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-[#E5E0D0] text-xs sm:text-sm text-[#242B27] bg-[#FDFCF7] focus:outline-none focus:border-[#174C3C]"
              />
              <button
                type="button"
                onClick={isListening ? stopListening : startListening}
                title={isListening ? "Listening..." : "Voice search"}
                className={`absolute right-2.5 p-1 rounded-lg transition-all cursor-pointer ${
                  isListening
                    ? 'bg-[#D87952] text-white animate-pulse'
                    : 'text-[#737D74] hover:text-[#174C3C]'
                }`}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center space-x-2 w-full sm:w-auto justify-between sm:justify-start">
              <span className="text-xs font-bold text-[#737D74] whitespace-nowrap">Sort by:</span>
              <select
                value={filters.sortBy}
                onChange={(e) => handleFilterChange({ sortBy: e.target.value as any })}
                className="px-3 py-2 rounded-xl border border-[#E5E0D0] text-xs sm:text-sm font-medium text-[#242B27] bg-[#FDFCF7] focus:outline-none focus:border-[#174C3C]"
              >
                <option value="relevance">Relevance / Featured</option>
                <option value="fee-asc">Lowest Fee First (₹)</option>
                <option value="fee-desc">Highest Fee First (₹)</option>
                <option value="exp-desc">Most Experienced</option>
                <option value="rating-desc">Highest Rated</option>
                <option value="name-asc">Name (A-Z)</option>
              </select>
            </div>

          </div>

          {/* Quick Search Suggestions */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs text-[#737D74] scrollbar-none">
            <span className="font-bold text-[11px] uppercase tracking-wider text-[#737D74] whitespace-nowrap">
              Suggestions:
            </span>
            {popularSuggestions.map((sug) => (
              <button
                key={sug}
                type="button"
                onClick={() => handleFilterChange({ query: sug })}
                className="px-2.5 py-1 rounded-lg bg-[#FFFFFF] border border-[#E5E0D0] hover:border-[#174C3C] text-[11px] text-[#242B27] whitespace-nowrap cursor-pointer transition-colors"
              >
                {sug}
              </button>
            ))}
          </div>

          {/* Voice Listening Banner */}
          {isListening && (
            <div className="p-3 bg-[#D87952]/10 border border-[#D87952]/30 rounded-xl flex items-center justify-between text-xs text-[#D87952] animate-pulse">
              <div className="flex items-center space-x-2">
                <Mic className="w-4 h-4 text-[#D87952] animate-bounce" />
                <span>Listening for search query... (e.g. "Maths tutor in Vijayapura")</span>
              </div>
              <button
                onClick={stopListening}
                className="font-bold underline cursor-pointer"
              >
                Stop Mic
              </button>
            </div>
          )}

          {/* Result Count and Active Tags */}
          <div className="flex items-center justify-between text-xs text-[#737D74] px-1">
            <span className="font-bold text-[#242B27]">
              Showing {displayedTutors.length} of {filteredTutors.length} Matching Tutors ({DEMO_TUTORS.length} Total Profiles)
            </span>
            {activeFiltersCount > 0 && (
              <span className="text-[#D87952] font-semibold">
                {activeFiltersCount} active {activeFiltersCount === 1 ? 'filter' : 'filters'}
              </span>
            )}
          </div>

          {/* Tutor Cards Grid */}
          {displayedTutors.length > 0 ? (
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {displayedTutors.map((tutor) => (
                  <TutorCard
                    key={tutor.id}
                    tutor={tutor}
                    isFavorite={favorites.some(f => f.id === tutor.id)}
                    isCompared={comparedTutors.some(c => c.id === tutor.id)}
                    onToggleFavorite={onToggleFavorite}
                    onToggleCompare={onToggleCompare}
                    onViewProfile={onViewProfile}
                    onContact={onContact}
                  />
                ))}
              </div>

              {/* Load More Button / Pagination */}
              {hasMoreTutors && (
                <div className="text-center pt-4 pb-6">
                  <button
                    type="button"
                    onClick={handleLoadMore}
                    className="inline-flex items-center space-x-2 px-8 py-3.5 rounded-2xl bg-[#174C3C] hover:bg-[#12382c] text-[#F8F6EF] font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
                  >
                    <span>Load More Tutors ({filteredTutors.length - visibleCount} remaining)</span>
                    <ChevronDown className="w-4 h-4 text-[#E6BD68]" />
                  </button>
                  <p className="text-[11px] text-[#737D74] mt-2">
                    Viewing {displayedTutors.length} of {filteredTutors.length} profiles
                  </p>
                </div>
              )}
            </div>
          ) : (
            /* Empty State */
            <div className="bg-[#FFFFFF] rounded-3xl p-12 text-center border border-[#E5E0D0] shadow-sm space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-[#174C3C]/10 text-[#174C3C] mx-auto flex items-center justify-center">
                <Search className="w-8 h-8 text-[#174C3C]" />
              </div>
              <h3 className="text-lg font-serif font-bold text-[#242B27]">No Matching Educators Found</h3>
              <p className="text-xs text-[#737D74] max-w-sm mx-auto leading-relaxed">
                No demonstration educators matched your current filter criteria. Try expanding your monthly fee range or selecting "All Categories".
              </p>
              <button
                onClick={handleResetFilters}
                className="inline-flex items-center space-x-1.5 px-5 py-2.5 rounded-xl bg-[#174C3C] hover:bg-[#12382c] text-[#F8F6EF] text-xs font-bold shadow transition-all cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset All Filters</span>
              </button>
            </div>
          )}

        </main>

      </div>

    </div>
  );
};
