import React, { useState } from 'react';
import { 
  Search, 
  Mic, 
  MicOff, 
  Sparkles, 
  GraduationCap, 
  MapPin, 
  ShieldCheck, 
  Clock, 
  Users, 
  CheckCircle2, 
  ArrowRight, 
  Award, 
  BookOpen, 
  Calculator, 
  Layers,
  Heart,
  Star,
  Quote,
  Compass,
  Check
} from 'lucide-react';
import { ALL_CLASSES, ALL_SUBJECTS, ALL_LOCALITIES, DEMO_TUTORS, TUTOR_CATEGORIES } from '../data/tutors';
import { Tutor, TutorCategory } from '../types/tutor';
import { TutorCard } from '../components/TutorCard';
import { useVoiceSearch } from '../hooks/useVoiceSearch';

interface HomePageProps {
  onSearch: (params: { query: string; subject: string; locality: string; studentClass: string; category?: string }) => void;
  onOpenSmartMatch: () => void;
  onOpenStudyPlanner: () => void;
  onOpenCalculator: () => void;
  onOpenChat: () => void;
  onViewTutorProfile: (tutor: Tutor) => void;
  onContactTutor: (tutor: Tutor) => void;
  favorites: Tutor[];
  comparedTutors: Tutor[];
  onToggleFavorite: (tutor: Tutor) => void;
  onToggleCompare: (tutor: Tutor) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onSearch,
  onOpenSmartMatch,
  onOpenStudyPlanner,
  onOpenCalculator,
  onOpenChat,
  onViewTutorProfile,
  onContactTutor,
  favorites,
  comparedTutors,
  onToggleFavorite,
  onToggleCompare,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedLocality, setSelectedLocality] = useState('');
  const [selectedClass, setSelectedClass] = useState('');

  // Voice Search Hook
  const { isListening, error: voiceError, startListening, stopListening } = useVoiceSearch((spokenText) => {
    setSearchQuery(spokenText);
  });

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({
      query: searchQuery,
      subject: selectedSubject,
      locality: selectedLocality,
      studentClass: selectedClass,
    });
  };

  const handleCategoryClick = (categoryName: string) => {
    onSearch({
      query: '',
      subject: '',
      locality: '',
      studentClass: '',
      category: categoryName
    });
  };

  const featuredTutors = DEMO_TUTORS.filter(t => t.featured).slice(0, 3);

  return (
    <div className="space-y-16 sm:space-y-24 pb-20 bg-[#F8F6EF]">
      
      {/* HERO SECTION — EDITORIAL ELEGANCE */}
      <section className="relative overflow-hidden pt-10 sm:pt-16 pb-16 sm:pb-24 border-b border-[#E5E0D0] bg-[#F8F6EF]">
        
        {/* Soft Background Accents */}
        <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-[#A8B9A0]/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-[400px] h-[400px] bg-[#E6BD68]/15 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="text-center max-w-4xl mx-auto space-y-5">
            
            {/* Elegant Tag */}
            <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-[#174C3C]/10 border border-[#174C3C]/20 text-[#174C3C] text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-[#D87952]" />
              <span>Find Your Perfect Tutor. Learn Smarter With AI.</span>
            </div>

            {/* Editorial Heading */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif font-black tracking-tight text-[#242B27] leading-[1.15]">
              Every Child Learns Differently. <br />
              <span className="text-[#174C3C] italic font-serif">
                Find the Tutor Who Understands.
              </span>
            </h1>

            {/* Subheading */}
            <p className="text-sm sm:text-lg text-[#737D74] max-w-2xl mx-auto font-normal leading-relaxed">
              Discover experienced home tutors across Karnataka and metro cities, explore personalised learning options, and send direct enquiries with zero middlemen fees.
            </p>
          </div>

          {/* Interactive Search Console — Warm White Card */}
          <div className="mt-10 max-w-5xl mx-auto bg-[#FFFFFF] rounded-3xl p-5 sm:p-7 shadow-xl border border-[#E5E0D0] text-[#242B27]">
            <form onSubmit={handleHeroSearch} className="space-y-4">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                
                {/* Search Text Input with Voice Search Icon */}
                <div className="relative">
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#737D74] block mb-1">
                    Subject or Keyword
                  </label>
                  <div className="relative flex items-center">
                    <Search className="w-4 h-4 text-[#737D74] absolute left-3.5 pointer-events-none" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="e.g. Maths, Physics, Coding..."
                      className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-[#E5E0D0] text-xs sm:text-sm text-[#242B27] bg-[#FDFCF7] focus:outline-none focus:border-[#174C3C] focus:ring-1 focus:ring-[#174C3C]"
                    />
                    
                    {/* Voice Search Button */}
                    <button
                      type="button"
                      onClick={isListening ? stopListening : startListening}
                      title={isListening ? "Stop listening" : "Search with your voice"}
                      className={`absolute right-2 p-1.5 rounded-lg transition-all cursor-pointer ${
                        isListening
                          ? 'bg-[#D87952] text-white animate-pulse'
                          : 'text-[#737D74] hover:text-[#174C3C] hover:bg-[#F8F6EF]'
                      }`}
                    >
                      {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Subject Selector */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#737D74] block mb-1">
                    Subject Stream
                  </label>
                  <select
                    value={selectedSubject}
                    onChange={(e) => setSelectedSubject(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E0D0] text-xs sm:text-sm text-[#242B27] bg-[#FDFCF7] focus:outline-none focus:border-[#174C3C]"
                  >
                    <option value="">All Subjects</option>
                    {ALL_SUBJECTS.map((sub) => (
                      <option key={sub} value={sub}>{sub}</option>
                    ))}
                  </select>
                </div>

                {/* Locality Selector */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#737D74] block mb-1">
                    Locality / City
                  </label>
                  <select
                    value={selectedLocality}
                    onChange={(e) => setSelectedLocality(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E0D0] text-xs sm:text-sm text-[#242B27] bg-[#FDFCF7] focus:outline-none focus:border-[#174C3C]"
                  >
                    <option value="">All Localities</option>
                    {ALL_LOCALITIES.map((loc) => (
                      <option key={loc} value={loc.split(' (')[0]}>{loc}</option>
                    ))}
                  </select>
                </div>

                {/* Class Selector */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#737D74] block mb-1">
                    Student Grade
                  </label>
                  <select
                    value={selectedClass}
                    onChange={(e) => setSelectedClass(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E0D0] text-xs sm:text-sm text-[#242B27] bg-[#FDFCF7] focus:outline-none focus:border-[#174C3C]"
                  >
                    <option value="">All Grades</option>
                    {ALL_CLASSES.map((cls) => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

              </div>

              {/* Voice recognition status banner */}
              {isListening && (
                <div className="p-3 bg-[#D87952]/10 border border-[#D87952]/30 rounded-xl flex items-center justify-between text-xs text-[#D87952] animate-pulse">
                  <div className="flex items-center space-x-2">
                    <Mic className="w-4 h-4 text-[#D87952] animate-bounce" />
                    <span>Listening... Speak tutor subject or locality (e.g., "Maths tutor in Vijayapura")</span>
                  </div>
                  <button
                    type="button"
                    onClick={stopListening}
                    className="text-xs font-bold underline"
                  >
                    Done Speaking
                  </button>
                </div>
              )}

              {voiceError && (
                <div className="p-2.5 bg-[#E6BD68]/20 border border-[#E6BD68]/50 rounded-xl text-xs text-[#242B27]">
                  {voiceError}
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-between pt-3 border-t border-[#E5E0D0] gap-3">
                <div className="flex items-center space-x-2 text-xs text-[#737D74]">
                  <ShieldCheck className="w-4 h-4 text-[#174C3C]" />
                  <span>Free demo enquiry • Zero signup wall • 40+ curated demonstration profiles</span>
                </div>

                <div className="flex items-center space-x-3 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={onOpenChat}
                    className="flex-1 sm:flex-initial inline-flex items-center justify-center space-x-1.5 px-4 py-2.5 rounded-xl bg-[#174C3C]/10 hover:bg-[#174C3C]/15 text-[#174C3C] font-bold text-xs transition-colors cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-[#D87952]" />
                    <span>Ask TutorChat</span>
                  </button>
                  <button
                    type="submit"
                    className="flex-1 sm:flex-initial inline-flex items-center justify-center space-x-2 px-6 py-2.5 rounded-xl bg-[#174C3C] hover:bg-[#12382c] text-[#F8F6EF] font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
                  >
                    <span>Find Tutors</span>
                    <ArrowRight className="w-4 h-4 text-[#E6BD68]" />
                  </button>
                </div>
              </div>

            </form>
          </div>

          {/* Popular Category Chips */}
          <div className="mt-8 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#737D74] mr-3 inline-block mb-2">
              Popular Categories:
            </span>
            <div className="inline-flex flex-wrap justify-center gap-2">
              {TUTOR_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleCategoryClick(cat.name)}
                  className="px-3.5 py-1.5 rounded-full bg-[#FFFFFF] border border-[#E5E0D0] hover:border-[#174C3C] text-xs font-medium text-[#242B27] hover:text-[#174C3C] hover:bg-[#FDFCF7] transition-all cursor-pointer shadow-2xs"
                >
                  {cat.name} ({cat.count})
                </button>
              ))}
            </div>
          </div>

          {/* Quick AI Action Cards Bar */}
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-4xl mx-auto">
            <div 
              onClick={onOpenSmartMatch}
              className="p-4 rounded-2xl bg-[#FFFFFF] hover:bg-[#FDFCF7] border border-[#E5E0D0] shadow-sm cursor-pointer transition-all hover:border-[#174C3C]/40 hover:-translate-y-0.5 flex items-center space-x-3.5"
            >
              <div className="w-11 h-11 rounded-xl bg-[#174C3C]/10 text-[#174C3C] flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-5 h-5 text-[#D87952]" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-sm text-[#242B27]">AI Smart Match</h4>
                <p className="text-[11px] text-[#737D74]">Answer 6 questions for a custom fit</p>
              </div>
            </div>

            <div 
              onClick={onOpenStudyPlanner}
              className="p-4 rounded-2xl bg-[#FFFFFF] hover:bg-[#FDFCF7] border border-[#E5E0D0] shadow-sm cursor-pointer transition-all hover:border-[#174C3C]/40 hover:-translate-y-0.5 flex items-center space-x-3.5"
            >
              <div className="w-11 h-11 rounded-xl bg-[#174C3C]/10 text-[#174C3C] flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-5 h-5 text-[#174C3C]" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-sm text-[#242B27]">AI Study Routine</h4>
                <p className="text-[11px] text-[#737D74]">Daily study timetables with revision slots</p>
              </div>
            </div>

            <div 
              onClick={onOpenCalculator}
              className="p-4 rounded-2xl bg-[#FFFFFF] hover:bg-[#FDFCF7] border border-[#E5E0D0] shadow-sm cursor-pointer transition-all hover:border-[#174C3C]/40 hover:-translate-y-0.5 flex items-center space-x-3.5"
            >
              <div className="w-11 h-11 rounded-xl bg-[#174C3C]/10 text-[#174C3C] flex items-center justify-center flex-shrink-0">
                <Calculator className="w-5 h-5 text-[#E6BD68]" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-sm text-[#242B27]">Tuition Fee Calculator</h4>
                <p className="text-[11px] text-[#737D74]">Transparent weekly & monthly rate estimates</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* EXPLORE BY 8 ACADEMIC CATEGORIES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-3">
          <div>
            <div className="inline-flex items-center space-x-1.5 text-xs font-bold text-[#174C3C] bg-[#174C3C]/10 px-3 py-1 rounded-full mb-1.5">
              <Compass className="w-3.5 h-3.5 text-[#D87952]" />
              <span>Specialised Disciplines</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#242B27]">
              Browse 40 Tutors by Academic Category
            </h2>
            <p className="text-xs sm:text-sm text-[#737D74] mt-1">
              Curated educators categorized across school curricula, competitive examinations, and skill mastery.
            </p>
          </div>

          <button
            onClick={() => onSearch({ query: '', subject: '', locality: '', studentClass: '' })}
            className="inline-flex items-center space-x-1.5 text-xs font-bold text-[#174C3C] hover:text-[#12382c] bg-[#FFFFFF] border border-[#E5E0D0] hover:border-[#174C3C] px-4 py-2.5 rounded-xl transition-colors cursor-pointer self-start sm:self-auto shadow-2xs"
          >
            <span>View All Categories</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {TUTOR_CATEGORIES.map((cat) => (
            <div
              key={cat.id}
              onClick={() => handleCategoryClick(cat.name)}
              className="p-5 rounded-3xl bg-[#FFFFFF] border border-[#E5E0D0] hover:border-[#174C3C] shadow-sm hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl">{cat.icon}</span>
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#174C3C]/10 text-[#174C3C]">
                    {cat.count} Tutors
                  </span>
                </div>
                <h3 className="font-serif font-bold text-base text-[#242B27] group-hover:text-[#174C3C] transition-colors">
                  {cat.name}
                </h3>
                <p className="text-xs text-[#737D74] mt-1 leading-relaxed">
                  {cat.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#E5E0D0]/60 flex items-center justify-between text-xs font-bold text-[#174C3C] group-hover:text-[#D87952] transition-colors">
                <span>Explore Profiles</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PLATFORM METRICS CARDS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-6">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#737D74] bg-[#FFFFFF] px-3.5 py-1 rounded-full border border-[#E5E0D0]">
            Demonstration Figures — Sample Platform Metrics
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          <div className="p-6 rounded-3xl bg-[#FFFFFF] border border-[#E5E0D0] shadow-sm text-center">
            <span className="text-3xl sm:text-4xl font-serif font-bold text-[#174C3C] block mb-1">
              {DEMO_TUTORS.length}
            </span>
            <span className="text-xs font-bold text-[#242B27] block">Demonstration Profiles</span>
            <span className="text-[11px] text-[#737D74] mt-0.5 block">Across 8 Academic Categories</span>
          </div>

          <div className="p-6 rounded-3xl bg-[#FFFFFF] border border-[#E5E0D0] shadow-sm text-center">
            <span className="text-3xl sm:text-4xl font-serif font-bold text-[#D87952] block mb-1">
              {ALL_SUBJECTS.length}+
            </span>
            <span className="text-xs font-bold text-[#242B27] block">Subjects Listed</span>
            <span className="text-[11px] text-[#737D74] mt-0.5 block">CBSE, ICSE, PUC, NEET, JEE</span>
          </div>

          <div className="p-6 rounded-3xl bg-[#FFFFFF] border border-[#E5E0D0] shadow-sm text-center">
            <span className="text-3xl sm:text-4xl font-serif font-bold text-[#174C3C] block mb-1">
              {ALL_LOCALITIES.length}
            </span>
            <span className="text-xs font-bold text-[#242B27] block">Teaching Localities</span>
            <span className="text-[11px] text-[#737D74] mt-0.5 block">Vijayapura, Dharwad, Bengaluru</span>
          </div>

          <div className="p-6 rounded-3xl bg-[#FFFFFF] border border-[#E5E0D0] shadow-sm text-center">
            <span className="text-3xl sm:text-4xl font-serif font-bold text-[#E6BD68] block mb-1">
              ₹0
            </span>
            <span className="text-xs font-bold text-[#242B27] block">Platform Middleman Fee</span>
            <span className="text-[11px] text-[#737D74] mt-0.5 block">Direct Parent-Tutor Connect</span>
          </div>
        </div>
      </section>

      {/* FEATURED TUTORS SPOTLIGHT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center space-x-1.5 text-xs font-bold text-[#174C3C] bg-[#174C3C]/10 px-3 py-1 rounded-full mb-1.5">
              <Award className="w-3.5 h-3.5 text-[#E6BD68]" />
              <span>Demonstration Spotlight</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#242B27]">Featured Home Educators</h2>
            <p className="text-xs sm:text-sm text-[#737D74] mt-1">
              Top-rated educators across Mathematics, Physics, Coding, and Languages with verified teaching approaches.
            </p>
          </div>

          <button
            onClick={() => onSearch({ query: '', subject: '', locality: '', studentClass: '' })}
            className="inline-flex items-center space-x-1.5 text-xs font-bold text-[#174C3C] hover:text-[#12382c] bg-[#FFFFFF] border border-[#E5E0D0] hover:border-[#174C3C] px-4 py-2.5 rounded-xl transition-colors self-start sm:self-auto cursor-pointer shadow-2xs"
          >
            <span>View All {DEMO_TUTORS.length} Tutors</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredTutors.map((tutor) => (
            <TutorCard
              key={tutor.id}
              tutor={tutor}
              isFavorite={favorites.some(f => f.id === tutor.id)}
              isCompared={comparedTutors.some(c => c.id === tutor.id)}
              onToggleFavorite={onToggleFavorite}
              onToggleCompare={onToggleCompare}
              onViewProfile={onViewTutorProfile}
              onContact={onContactTutor}
            />
          ))}
        </div>
      </section>

      {/* HOW IT WORKS IN 3 STEPS (EDITORIAL DESIGN) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-[#174C3C] text-[#F8F6EF] shadow-xl border border-[#12382c]">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#E6BD68] bg-[#FFFFFF]/10 border border-[#FFFFFF]/15 px-3 py-1 rounded-full">
              Zero Hassle Discovery
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8F6EF] mt-3">
              How TutorAI Works in 3 Simple Steps
            </h2>
            <p className="text-xs sm:text-sm text-[#A8B9A0] mt-2">
              No registration forms, no locked passwords, and no subscription packages. Find your tutor in minutes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#FFFFFF]/5 p-6 rounded-2xl border border-[#FFFFFF]/10 relative">
              <div className="w-10 h-10 rounded-xl bg-[#E6BD68] text-[#174C3C] font-black text-sm flex items-center justify-center mb-4 shadow">
                1
              </div>
              <h3 className="font-serif font-bold text-base text-[#F8F6EF]">Filter by Locality & Subject</h3>
              <p className="text-xs text-[#A8B9A0] mt-2 leading-relaxed">
                Filter by class, subject, monthly fee in INR, and neighborhood. Use voice search or explore nearby tutor hubs on OpenStreetMap.
              </p>
            </div>

            <div className="bg-[#FFFFFF]/5 p-6 rounded-2xl border border-[#FFFFFF]/10 relative">
              <div className="w-10 h-10 rounded-xl bg-[#D87952] text-[#FFFFFF] font-black text-sm flex items-center justify-center mb-4 shadow">
                2
              </div>
              <h3 className="font-serif font-bold text-base text-[#F8F6EF]">AI Smart Match & Compare</h3>
              <p className="text-xs text-[#A8B9A0] mt-2 leading-relaxed">
                Let Gemini diagnose student strengths, or compare up to 3 tutors side-by-side on fees, methodology, experience, and weekly availability.
              </p>
            </div>

            <div className="bg-[#FFFFFF]/5 p-6 rounded-2xl border border-[#FFFFFF]/10 relative">
              <div className="w-10 h-10 rounded-xl bg-[#A8B9A0] text-[#174C3C] font-black text-sm flex items-center justify-center mb-4 shadow">
                3
              </div>
              <h3 className="font-serif font-bold text-base text-[#F8F6EF]">Send Free Demo Enquiry</h3>
              <p className="text-xs text-[#A8B9A0] mt-2 leading-relaxed">
                Submit schedule preferences directly. Coordinate a risk-free 1-on-1 diagnostic home session before committing to monthly tuition.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE TUTORAI & AI ADVANTAGES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Why Parents Trust TutorAI */}
          <div className="p-8 rounded-3xl bg-[#FFFFFF] border border-[#E5E0D0] shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold text-[#D87952] uppercase tracking-wider block mb-2">
                Why Parents Trust Us
              </span>
              <h3 className="text-2xl font-serif font-bold text-[#242B27] mb-5">
                Dedicated to Transparent Home Tutoring
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3.5">
                  <div className="w-8 h-8 rounded-xl bg-[#174C3C]/10 text-[#174C3C] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-[#242B27]">Direct Parent-Tutor Communication</h4>
                    <p className="text-xs text-[#737D74] mt-0.5">No agency commissions or middlemen inflating home tuition prices.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3.5">
                  <div className="w-8 h-8 rounded-xl bg-[#174C3C]/10 text-[#174C3C] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-[#242B27]">Curriculum-Specific Expertise</h4>
                    <p className="text-xs text-[#737D74] mt-0.5">Educators trained in CBSE, ICSE, Karnataka State Board, PUC, and Olympiad standards.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3.5">
                  <div className="w-8 h-8 rounded-xl bg-[#174C3C]/10 text-[#174C3C] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-[#242B27]">Flexible Home Visit & Hybrid Modes</h4>
                    <p className="text-xs text-[#737D74] mt-0.5">Choose between in-person home visits or digital pen-tablet 1-on-1 sessions.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[#E5E0D0]">
              <button
                onClick={() => onSearch({ query: '', subject: '', locality: '', studentClass: '' })}
                className="w-full py-3.5 rounded-xl bg-[#174C3C] hover:bg-[#12382c] text-[#F8F6EF] font-bold text-xs flex items-center justify-center space-x-2 transition-colors cursor-pointer"
              >
                <span>Browse Local Home Tutors</span>
                <ArrowRight className="w-4 h-4 text-[#E6BD68]" />
              </button>
            </div>
          </div>

          {/* AI-Powered Learning Benefits */}
          <div className="p-8 rounded-3xl bg-[#174C3C] text-[#F8F6EF] shadow-xl border border-[#12382c] flex flex-col justify-between">
            <div>
              <div className="inline-flex items-center space-x-1.5 text-xs font-bold text-[#E6BD68] bg-[#FFFFFF]/10 px-3 py-1 rounded-full mb-3">
                <Sparkles className="w-3.5 h-3.5 text-[#E6BD68]" />
                <span>AI Superpowers</span>
              </div>
              <h3 className="text-2xl font-serif font-bold text-[#F8F6EF] mb-5">
                Learn Smarter With TutorAI
              </h3>

              <div className="space-y-4">
                <div className="flex items-start space-x-3.5">
                  <div className="w-8 h-8 rounded-xl bg-[#FFFFFF]/10 text-[#E6BD68] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-[#F8F6EF]">TutorChat 24/7 Educational Advisor</h4>
                    <p className="text-xs text-[#A8B9A0] mt-0.5">Get advice on fee ranges, demo class interview questions, and concept revision techniques.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3.5">
                  <div className="w-8 h-8 rounded-xl bg-[#FFFFFF]/10 text-[#E6BD68] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-[#F8F6EF]">Automated AI Study Timetable</h4>
                    <p className="text-xs text-[#A8B9A0] mt-0.5">Generates balanced daily study routines with Pomodoro intervals and weekend mock tests.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3.5">
                  <div className="w-8 h-8 rounded-xl bg-[#FFFFFF]/10 text-[#E6BD68] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Calculator className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-[#F8F6EF]">Transparent Fee Budget Calculator</h4>
                    <p className="text-xs text-[#A8B9A0] mt-0.5">Calculates tuition estimates based on weekly sessions and multi-child sibling discounts.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[#FFFFFF]/15">
              <button
                onClick={onOpenChat}
                className="w-full py-3.5 rounded-xl bg-[#D87952] hover:bg-[#c46944] text-[#FFFFFF] font-bold text-xs flex items-center justify-center space-x-2 shadow-md transition-all cursor-pointer"
              >
                <span>Launch TutorChat AI Assistant</span>
                <Sparkles className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* SAMPLE TESTIMONIALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#D87952] bg-[#D87952]/10 px-3 py-1 rounded-full border border-[#D87952]/20">
            Sample Demonstrative Testimonials
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#242B27] mt-3">
            What Parents & Students Say
          </h2>
          <p className="text-xs sm:text-sm text-[#737D74] mt-1">
            Simulated feedback representing typical learning transformations achieved with personalized home tutoring.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-7 rounded-3xl bg-[#FFFFFF] border border-[#E5E0D0] shadow-sm flex flex-col justify-between">
            <div>
              <Quote className="w-7 h-7 text-[#D87952] mb-3 opacity-60" />
              <p className="text-xs text-[#242B27] leading-relaxed italic">
                "Finding Dr. Raghavendra Rao for Class 10 CBSE Maths changed everything for my daughter in Vijayapura. The weekly diagnostic problem sets built her confidence ahead of board exams."
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-[#E5E0D0] flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-[#174C3C]/10 text-[#174C3C] font-black text-xs flex items-center justify-center font-serif">
                SM
              </div>
              <div>
                <h4 className="font-bold text-xs text-[#242B27]">Sunita Murthy (Sample Parent)</h4>
                <p className="text-[10px] text-[#737D74]">Vijayapura • Class 10 Parent</p>
              </div>
            </div>
          </div>

          <div className="p-7 rounded-3xl bg-[#FFFFFF] border border-[#E5E0D0] shadow-sm flex flex-col justify-between">
            <div>
              <Quote className="w-7 h-7 text-[#174C3C] mb-3 opacity-60" />
              <p className="text-xs text-[#242B27] leading-relaxed italic">
                "Anand Kulkarni made Class 12 Physics intuitive rather than rote memorization. The side-by-side comparison drawer made choosing between three senior tutors effortless."
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-[#E5E0D0] flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-[#174C3C]/10 text-[#174C3C] font-black text-xs flex items-center justify-center font-serif">
                VK
              </div>
              <div>
                <h4 className="font-bold text-xs text-[#242B27]">Vijay Kumar (Sample Parent)</h4>
                <p className="text-[10px] text-[#737D74]">Dharwad • Class 12 Parent</p>
              </div>
            </div>
          </div>

          <div className="p-7 rounded-3xl bg-[#FFFFFF] border border-[#E5E0D0] shadow-sm flex flex-col justify-between">
            <div>
              <Quote className="w-7 h-7 text-[#E6BD68] mb-3 opacity-80" />
              <p className="text-xs text-[#242B27] leading-relaxed italic">
                "TutorChat helped me prepare the exact questions to ask during the demo class. The study planner timetable has kept our evening revision disciplined."
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-[#E5E0D0] flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-[#174C3C]/10 text-[#174C3C] font-black text-xs flex items-center justify-center font-serif">
                AR
              </div>
              <div>
                <h4 className="font-bold text-xs text-[#242B27]">Ananya Roy (Sample Parent)</h4>
                <p className="text-[10px] text-[#737D74]">Bengaluru • Class 8 Parent</p>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
