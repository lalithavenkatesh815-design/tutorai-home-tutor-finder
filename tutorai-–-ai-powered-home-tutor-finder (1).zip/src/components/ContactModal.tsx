import React, { useState } from 'react';
import { 
  X, 
  Send, 
  CheckCircle2, 
  ShieldAlert
} from 'lucide-react';
import { Tutor } from '../types/tutor';
import { ALL_CLASSES, ALL_SUBJECTS } from '../data/tutors';

interface ContactModalProps {
  tutor: Tutor | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({
  tutor,
  isOpen,
  onClose,
}) => {
  const [formData, setFormData] = useState({
    parentName: '',
    email: '',
    phone: '',
    studentClass: tutor?.classes[0] || 'Class 10',
    subject: tutor?.subjects[0] || 'Mathematics',
    locality: tutor?.locality || 'Koramangala, Bengaluru',
    mode: tutor?.teachingMode || 'Hybrid (Home + Online)',
    preferredDays: ['Mon', 'Wed', 'Fri'],
    timeSlot: 'Evening (4 PM - 8 PM)',
    notes: 'Looking for 3 days a week home tutoring with focus on upcoming unit tests and homework doubt clarification.'
  });

  const [submitted, setSubmitted] = useState(false);
  const [refId, setRefId] = useState('');

  if (!isOpen) return null;

  const handleDayToggle = (day: string) => {
    if (formData.preferredDays.includes(day)) {
      if (formData.preferredDays.length > 1) {
        setFormData({ ...formData, preferredDays: formData.preferredDays.filter(d => d !== day) });
      }
    } else {
      setFormData({ ...formData, preferredDays: [...formData.preferredDays, day] });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const generatedRef = `ENQ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    setRefId(generatedRef);

    try {
      const netlifyBody = new URLSearchParams({
        'form-name': 'tutor-enquiry',
        'tutorName': tutor?.name || 'General Inquiry',
        'parentName': formData.parentName,
        'email': formData.email,
        'phone': formData.phone,
        'studentClass': formData.studentClass,
        'subject': formData.subject,
        'locality': formData.locality,
        'mode': formData.mode,
        'schedulePreference': `${formData.preferredDays.join(', ')} (${formData.timeSlot})`,
        'notes': formData.notes
      }).toString();

      await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: netlifyBody
      });
    } catch {
      // Local demo mode
    }

    setSubmitted(true);
  };

  const handleResetAndClose = () => {
    setSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242B27]/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-[#E8E4D5] overflow-hidden my-6 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header - Forest Green */}
        <div className="bg-[#174C3C] p-6 text-[#F8F6EF] flex items-center justify-between border-b border-[#0F3328]">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center text-[#E6BD68]">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-serif font-black text-white">Send Home Tutor Contact Enquiry</h2>
              <p className="text-xs text-[#A8B9A0]">
                {tutor ? `Enquiry for ${tutor.name} (${tutor.locality}, ${tutor.city})` : 'General Home Tutor Requirement'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#A8B9A0] hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body or Success Confirmation */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 bg-white">
          
          {submitted ? (
            /* Submission Confirmation Screen */
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#E8EFE5] text-[#174C3C] mx-auto flex items-center justify-center shadow-xs animate-scale">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#E8EFE5] text-[#174C3C] border border-[#A8B9A0]/50 inline-block mb-2">
                  Enquiry Submitted Successfully
                </span>
                <h3 className="text-2xl font-serif font-black text-[#242B27]">Enquiry Logged for {tutor?.name || 'Tutor'}</h3>
                <p className="text-xs text-[#737D74] font-mono mt-1">Reference ID: <strong className="text-[#174C3C]">{refId}</strong></p>
              </div>

              <div className="max-w-md mx-auto p-4 bg-[#F8F6EF] rounded-2xl border border-[#E8E4D5] text-left text-xs space-y-2 text-[#242B27]">
                <div className="flex justify-between">
                  <span className="text-[#737D74]">Parent Name:</span>
                  <span className="font-bold">{formData.parentName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#737D74]">Class & Subject:</span>
                  <span className="font-bold">{formData.studentClass} • {formData.subject}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#737D74]">Teaching Mode:</span>
                  <span className="font-bold">{formData.mode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#737D74]">Preferred Days & Slot:</span>
                  <span className="font-bold">{formData.preferredDays.join(', ')} ({formData.timeSlot})</span>
                </div>
              </div>

              {/* Status Note */}
              <div className="p-3.5 bg-[#FAF5E8] rounded-xl border border-[#EADFC7] text-xs text-[#7A5813] text-left flex items-start space-x-2 max-w-md mx-auto">
                <ShieldAlert className="w-4 h-4 text-[#D87952] flex-shrink-0 mt-0.5" />
                <span>
                  <strong>Academic Project Status:</strong> This enquiry has been logged in demonstration mode. In a live system, the tutor is notified via SMS/WhatsApp to arrange an initial 1-on-1 demo session.
                </span>
              </div>

              <button
                onClick={handleResetAndClose}
                className="mt-4 px-6 py-2.5 rounded-xl bg-[#174C3C] hover:bg-[#0F3328] text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
              >
                Done / Back to Directory
              </button>
            </div>
          ) : (
            /* Enquiry Form */
            <form onSubmit={handleSubmit} className="space-y-5" data-netlify="true" name="tutor-enquiry">
              <input type="hidden" name="form-name" value="tutor-enquiry" />

              {/* Tutor banner info */}
              {tutor && (
                <div className="p-3.5 bg-[#F8F6EF] rounded-2xl border border-[#E8E4D5] flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-3">
                    <img
                      src={tutor.avatar}
                      alt={tutor.name}
                      className="w-10 h-10 rounded-xl object-cover border border-[#E8E4D5]"
                    />
                    <div>
                      <p className="font-serif font-bold text-[#242B27]">{tutor.name}</p>
                      <p className="text-[#737D74] text-[11px]">{tutor.locality}, {tutor.city} • ₹{tutor.monthlyFee}/month</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#E8EFE5] text-[#174C3C]">
                    {tutor.teachingMode}
                  </span>
                </div>
              )}

              {/* Parent Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Parent / Guardian Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.parentName}
                    onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                    placeholder="e.g. Ramesh Kulkarni"
                    className="w-full px-3 py-2 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="e.g. ramesh@example.com"
                    className="w-full px-3 py-2 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Phone / WhatsApp Number *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="e.g. +91 98765 43210"
                    className="w-full px-3 py-2 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  />
                </div>
              </div>

              {/* Student Class & Subject */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Student Class</label>
                  <select
                    value={formData.studentClass}
                    onChange={(e) => setFormData({ ...formData, studentClass: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  >
                    {ALL_CLASSES.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Required Subject</label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  >
                    {ALL_SUBJECTS.map(sub => (
                      <option key={sub} value={sub}>{sub}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Teaching Mode</label>
                  <select
                    value={formData.mode}
                    onChange={(e) => setFormData({ ...formData, mode: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  >
                    <option value="Home Visit Only">Home Visit (Tutor comes home)</option>
                    <option value="Online Only">Online 1-on-1</option>
                    <option value="Hybrid (Home + Online)">Hybrid (Flexible)</option>
                  </select>
                </div>
              </div>

              {/* Preferred Days Checkboxes */}
              <div>
                <label className="text-xs font-bold text-[#242B27] block mb-1.5">
                  Preferred Days of the Week
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => {
                    const isSelected = formData.preferredDays.includes(day);
                    return (
                      <button
                        type="button"
                        key={day}
                        onClick={() => handleDayToggle(day)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#174C3C] text-[#F8F6EF] shadow-xs'
                            : 'bg-[#F8F6EF] text-[#242B27] hover:bg-[#EDE9DC] border border-[#E8E4D5]'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Preferred Time Slot */}
              <div>
                <label className="text-xs font-bold text-[#242B27] block mb-1">
                  Preferred Time Slot
                </label>
                <select
                  value={formData.timeSlot}
                  onChange={(e) => setFormData({ ...formData, timeSlot: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                >
                  <option value="Morning (9 AM - 12 PM)">Morning (9:00 AM – 12:00 PM)</option>
                  <option value="Afternoon (2 PM - 5 PM)">Afternoon (2:00 PM – 5:00 PM)</option>
                  <option value="Evening (4 PM - 8 PM)">Evening (4:00 PM – 8:00 PM)</option>
                  <option value="Weekend Mornings">Weekend Mornings (Sat / Sun)</option>
                </select>
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs font-bold text-[#242B27] block mb-1">
                  Specific Learning Requirements or Weak Topics
                </label>
                <textarea
                  rows={3}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                />
              </div>

              {/* Disclaimer */}
              <p className="text-[11px] text-[#737D74]">
                🔒 We protect parent privacy. Contact details are shared with the selected tutor solely for scheduling the initial free demo session. No login or password required.
              </p>

              {/* Submit Button */}
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-7 py-3 rounded-xl bg-[#174C3C] hover:bg-[#0F3328] text-white font-bold text-xs sm:text-sm shadow-xs transition-all cursor-pointer"
                >
                  <Send className="w-4 h-4 text-[#E6BD68]" />
                  <span>Submit Home Tutor Enquiry</span>
                </button>
              </div>

            </form>
          )}

        </div>

      </div>
    </div>
  );
};
