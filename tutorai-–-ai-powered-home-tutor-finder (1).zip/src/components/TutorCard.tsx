import React from 'react';
import { 
  Star, 
  MapPin, 
  Briefcase, 
  Clock, 
  Heart, 
  Layers, 
  Send, 
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { Tutor } from '../types/tutor';

interface TutorCardProps {
  tutor: Tutor;
  isFavorite: boolean;
  isCompared: boolean;
  onToggleFavorite: (tutor: Tutor) => void;
  onToggleCompare: (tutor: Tutor) => void;
  onViewProfile: (tutor: Tutor) => void;
  onContact: (tutor: Tutor) => void;
}

export const TutorCard: React.FC<TutorCardProps> = ({
  tutor,
  isFavorite,
  isCompared,
  onToggleFavorite,
  onToggleCompare,
  onViewProfile,
  onContact,
}) => {
  return (
    <div className="group bg-white rounded-3xl border border-[#E8E4D5] hover:border-[#174C3C]/40 shadow-[0_4px_20px_rgba(23,76,60,0.04)] hover:shadow-[0_12px_32px_rgba(23,76,60,0.1)] transition-all duration-300 flex flex-col justify-between overflow-hidden relative">
      
      {/* Top Demonstration Notice Banner */}
      <div className="bg-[#FAF5E8] border-b border-[#EADFC7] px-4 py-1.5 flex items-center justify-between text-[11px] text-[#7A5813] font-medium">
        <span className="flex items-center space-x-1.5 truncate">
          <ShieldAlert className="w-3.5 h-3.5 text-[#D87952] flex-shrink-0" />
          <span className="truncate">Demonstration Profile – Not Independently Verified</span>
        </span>
        <span className="text-[10px] bg-[#EFE5CD] text-[#5C420D] font-bold px-1.5 py-0.2 rounded">
          Sample
        </span>
      </div>

      <div className="p-5 sm:p-6 flex-1 flex flex-col">
        
        {/* Header: Photo, Name, Rating, Favourites & Compare */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start space-x-3.5">
            <div className="relative">
              <img
                src={tutor.avatar}
                alt={tutor.name}
                loading="lazy"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(tutor.name)}&background=174C3C&color=F8F6EF&size=128`;
                }}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-[#E8EFE5] shadow-xs group-hover:scale-103 transition-transform"
              />
              <span className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-white ${
                tutor.teachingMode.includes('Home') ? 'bg-[#174C3C]' : 'bg-[#D87952]'
              }`} title={tutor.teachingMode} />
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <h3 
                  onClick={() => onViewProfile(tutor)}
                  className="font-serif font-bold text-[#242B27] text-lg hover:text-[#174C3C] cursor-pointer transition-colors"
                >
                  {tutor.name}
                </h3>
              </div>
              <p className="text-xs text-[#737D74] font-medium line-clamp-1 mt-0.5">{tutor.qualification}</p>
              
              <div className="flex items-center space-x-2.5 mt-1.5 text-xs">
                <span className="flex items-center text-[#242B27] font-bold space-x-1">
                  <Star className="w-3.5 h-3.5 fill-[#E6BD68] text-[#E6BD68]" />
                  <span>{tutor.rating}</span>
                  <span className="text-[#737D74] font-normal text-[11px]">({tutor.reviewCount})</span>
                </span>
                <span className="text-[#A8B9A0]">•</span>
                <span className="flex items-center text-[#242B27] font-semibold space-x-1 text-[11px]">
                  <Briefcase className="w-3.5 h-3.5 text-[#174C3C]" />
                  <span>{tutor.experienceYears} yrs exp</span>
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions (Favorite & Compare) */}
          <div className="flex items-center space-x-1 flex-shrink-0">
            <button
              onClick={() => onToggleFavorite(tutor)}
              aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
              title={isFavorite ? 'Remove from favorites' : 'Save to favorites'}
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                isFavorite 
                  ? 'bg-[#FAECE5] text-[#D87952]' 
                  : 'bg-[#F8F6EF] text-[#737D74] hover:text-[#D87952] hover:bg-[#F0EBE0]'
              }`}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-[#D87952]' : ''}`} />
            </button>
            <button
              onClick={() => onToggleCompare(tutor)}
              aria-label={isCompared ? 'Remove from comparison' : 'Compare tutor'}
              title={isCompared ? 'Remove from comparison' : 'Add to compare'}
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                isCompared 
                  ? 'bg-[#174C3C] text-white shadow-xs' 
                  : 'bg-[#F8F6EF] text-[#737D74] hover:text-[#174C3C] hover:bg-[#F0EBE0]'
              }`}
            >
              <Layers className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Subjects taught pills */}
        <div className="mt-3.5 flex flex-wrap gap-1.5">
          {tutor.subjects.slice(0, 3).map((sub, i) => (
            <span
              key={i}
              className="text-[11px] font-semibold px-2.5 py-0.5 rounded-lg bg-[#E8EFE5] text-[#174C3C] border border-[#A8B9A0]/30"
            >
              {sub}
            </span>
          ))}
          {tutor.subjects.length > 3 && (
            <span className="text-[11px] font-medium px-2 py-0.5 rounded-lg bg-[#F8F6EF] text-[#737D74]">
              +{tutor.subjects.length - 3}
            </span>
          )}
        </div>

        {/* Short Bio */}
        <p className="mt-3 text-xs text-[#737D74] line-clamp-2 leading-relaxed">
          {tutor.bio}
        </p>

        {/* Meta Info: Locality, Mode, Availability */}
        <div className="mt-4 pt-3 border-t border-[#F2EFE5] space-y-1.5 text-xs text-[#737D74]">
          <div className="flex items-center justify-between">
            <span className="flex items-center text-[#242B27] space-x-1">
              <MapPin className="w-3.5 h-3.5 text-[#D87952] flex-shrink-0" />
              <span className="font-semibold">{tutor.locality}, {tutor.city}</span>
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FAF5E8] text-[#7A5813] border border-[#EADFC7]/80">
              {tutor.teachingMode}
            </span>
          </div>

          <div className="flex items-center space-x-1 text-[#737D74] text-[11px]">
            <Clock className="w-3 h-3 text-[#A8B9A0] flex-shrink-0" />
            <span className="truncate">{tutor.availability}</span>
          </div>
        </div>

        {/* Fee & Action Footer */}
        <div className="mt-4 pt-3 border-t border-[#F2EFE5] flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#737D74] uppercase tracking-wider font-bold block">Monthly Fee</span>
            <div className="flex items-baseline space-x-1">
              <span className="text-xl font-bold font-serif text-[#174C3C]">₹{tutor.monthlyFee.toLocaleString('en-IN')}</span>
              <span className="text-[11px] text-[#737D74]">/mo</span>
            </div>
            <span className="text-[10px] text-[#737D74]">~₹{tutor.sessionFee}/session</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => onViewProfile(tutor)}
              className="px-3 py-2 rounded-xl text-xs font-bold text-[#242B27] hover:text-[#174C3C] bg-[#F8F6EF] hover:bg-[#EDE9DC] transition-colors cursor-pointer"
            >
              Profile
            </button>
            <button
              onClick={() => onContact(tutor)}
              className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-[#F8F6EF] bg-[#174C3C] hover:bg-[#0F3328] shadow-xs transition-all cursor-pointer"
            >
              <Send className="w-3 h-3" />
              <span>Contact</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
