import React from 'react';
import { 
  X, 
  Star, 
  MapPin, 
  Briefcase, 
  Clock, 
  Heart, 
  Layers, 
  Send, 
  ShieldAlert, 
  BookOpen, 
  Languages, 
  CheckCircle, 
  CreditCard,
  Compass,
  Calendar
} from 'lucide-react';
import { Tutor } from '../types/tutor';

interface TutorModalProps {
  tutor: Tutor | null;
  onClose: () => void;
  isFavorite: boolean;
  isCompared: boolean;
  onToggleFavorite: (tutor: Tutor) => void;
  onToggleCompare: (tutor: Tutor) => void;
  onContact: (tutor: Tutor) => void;
  onExploreMap: (tutor: Tutor) => void;
  onDemoPayment: (tutor: Tutor) => void;
}

export const TutorModal: React.FC<TutorModalProps> = ({
  tutor,
  onClose,
  isFavorite,
  isCompared,
  onToggleFavorite,
  onToggleCompare,
  onContact,
  onExploreMap,
  onDemoPayment,
}) => {
  if (!tutor) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242B27]/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div 
        className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-[#E8E4D5] overflow-hidden my-8 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Demonstration Disclaimer Header */}
        <div className="bg-[#FAF5E8] border-b border-[#EADFC7] text-[#7A5813] px-5 py-2 flex items-center justify-between text-xs font-bold tracking-wide">
          <span className="flex items-center space-x-2">
            <ShieldAlert className="w-4 h-4 text-[#D87952]" />
            <span>Demonstration Profile – Not Independently Verified (Sample Academic Record)</span>
          </span>
          <button 
            onClick={onClose}
            className="text-[#7A5813] hover:text-[#242B27] p-1 rounded-lg hover:bg-[#EFE5CD] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6 bg-white">
          
          {/* Hero Section */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-6 border-b border-[#F2EFE5]">
            <div className="flex items-start sm:items-center space-x-4">
              <img
                src={tutor.avatar}
                alt={tutor.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl object-cover border-2 border-[#E8EFE5] shadow-sm"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(tutor.name)}&background=174C3C&color=F8F6EF&size=128`;
                }}
              />
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-2xl font-serif font-black text-[#242B27]">{tutor.name}</h2>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#E8EFE5] text-[#174C3C] font-bold text-xs border border-[#A8B9A0]/40">
                    {tutor.teachingMode}
                  </span>
                </div>
                <p className="text-sm font-semibold text-[#174C3C] mt-1">{tutor.qualification}</p>
                
                <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-[#737D74]">
                  <span className="flex items-center space-x-1 font-bold text-[#242B27]">
                    <Star className="w-4 h-4 fill-[#E6BD68] text-[#E6BD68]" />
                    <span>{tutor.rating}</span>
                    <span className="text-[#737D74] font-normal">({tutor.reviewCount} parent reviews)</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center space-x-1 font-semibold text-[#242B27]">
                    <Briefcase className="w-4 h-4 text-[#174C3C]" />
                    <span>{tutor.experienceYears} Years Exp</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center space-x-1 font-medium text-[#242B27]">
                    <MapPin className="w-4 h-4 text-[#D87952]" />
                    <span>{tutor.locality}, {tutor.city}</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Actions: Favorite & Compare */}
            <div className="flex items-center space-x-2 self-end sm:self-center">
              <button
                onClick={() => onToggleFavorite(tutor)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                  isFavorite 
                    ? 'bg-[#FAECE5] border-[#D87952]/30 text-[#D87952]' 
                    : 'bg-[#F8F6EF] border-[#E8E4D5] text-[#737D74] hover:text-[#D87952]'
                }`}
                title={isFavorite ? 'Saved to favourites' : 'Save to favourites'}
              >
                <Heart className={`w-5 h-5 ${isFavorite ? 'fill-[#D87952]' : ''}`} />
              </button>
              <button
                onClick={() => onToggleCompare(tutor)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                  isCompared 
                    ? 'bg-[#174C3C] border-[#174C3C] text-white shadow-xs' 
                    : 'bg-[#F8F6EF] border-[#E8E4D5] text-[#737D74] hover:text-[#174C3C]'
                }`}
                title={isCompared ? 'In comparison list' : 'Add to compare'}
              >
                <Layers className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Fee & Affordability Box */}
          <div className="bg-[#F8F6EF] rounded-3xl p-5 border border-[#E8E4D5] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-extrabold tracking-wider text-[#174C3C]">Tuition Fee Structure</span>
              <div className="flex items-baseline space-x-2 mt-0.5">
                <span className="text-3xl font-serif font-black text-[#174C3C]">₹{tutor.monthlyFee.toLocaleString('en-IN')}</span>
                <span className="text-sm font-semibold text-[#737D74]">/ month (standard rate)</span>
              </div>
              <p className="text-xs text-[#737D74] mt-1">
                Estimated at <strong>₹{tutor.sessionFee} per session</strong> (~3 sessions/week). Final fees arranged directly with tutor.
              </p>
            </div>

            <div className="flex items-center space-x-2 w-full sm:w-auto">
              <button
                onClick={() => {
                  onClose();
                  onExploreMap(tutor);
                }}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center space-x-1.5 px-4 py-2.5 rounded-xl bg-white border border-[#E8E4D5] text-[#242B27] hover:text-[#174C3C] font-bold text-xs shadow-xs transition-all cursor-pointer"
              >
                <Compass className="w-4 h-4 text-[#D87952]" />
                <span>Locality Map</span>
              </button>
              <button
                onClick={() => {
                  onClose();
                  onDemoPayment(tutor);
                }}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center space-x-1.5 px-4 py-2.5 rounded-xl bg-[#E8EFE5] hover:bg-[#DDE7DA] text-[#174C3C] font-bold text-xs border border-[#A8B9A0]/60 transition-all cursor-pointer"
                title="View fee breakdown & mock checkout"
              >
                <CreditCard className="w-4 h-4 text-[#174C3C]" />
                <span>Fee Breakdown</span>
              </button>
            </div>
          </div>

          {/* Introduction & Bio */}
          <div>
            <h4 className="text-xs uppercase font-bold tracking-wider text-[#737D74] mb-2">Educator Introduction</h4>
            <p className="text-xs sm:text-sm text-[#242B27] leading-relaxed bg-[#FDFCF7] p-4 rounded-2xl border border-[#E8E4D5]">
              {tutor.bio}
            </p>
          </div>

          {/* Subjects, Curriculum, Classes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#F8F6EF] p-4 rounded-2xl border border-[#E8E4D5]">
              <span className="text-xs font-bold text-[#174C3C] flex items-center space-x-1.5 mb-2.5">
                <BookOpen className="w-4 h-4 text-[#D87952]" />
                <span>Subjects Taught</span>
              </span>
              <div className="flex flex-wrap gap-1.5">
                {tutor.subjects.map((sub, i) => (
                  <span key={i} className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-white text-[#174C3C] border border-[#E8E4D5]">
                    {sub}
                  </span>
                ))}
              </div>
            </div>

            <div className="bg-[#F8F6EF] p-4 rounded-2xl border border-[#E8E4D5]">
              <span className="text-xs font-bold text-[#174C3C] flex items-center space-x-1.5 mb-2.5">
                <CheckCircle className="w-4 h-4 text-[#174C3C]" />
                <span>Classes & Curricula Handled</span>
              </span>
              <div className="flex flex-wrap gap-1.5">
                {tutor.classes.map((cls, i) => (
                  <span key={i} className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-white text-[#242B27] border border-[#E8E4D5]">
                    {cls}
                  </span>
                ))}
                {tutor.curriculum.map((curr, i) => (
                  <span key={`curr-${i}`} className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-[#FAF5E8] text-[#7A5813] border border-[#EADFC7]">
                    {curr}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Teaching Methodology & Languages */}
          <div className="space-y-4">
            <div>
              <h4 className="text-xs uppercase font-bold tracking-wider text-[#737D74] mb-1.5">Teaching Methodology</h4>
              <div className="p-4 rounded-2xl bg-[#FDFCF7] border border-[#E8E4D5] text-xs sm:text-sm text-[#242B27] leading-relaxed">
                {tutor.methodology}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-[#F8F6EF] border border-[#E8E4D5] text-xs">
              <div className="flex items-center space-x-2">
                <Languages className="w-4 h-4 text-[#D87952]" />
                <span className="font-bold text-[#737D74]">Languages Spoken:</span>
                <span className="font-semibold text-[#242B27]">{tutor.languages.join(', ')}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4 text-[#174C3C]" />
                <span className="font-bold text-[#737D74]">Weekly Availability:</span>
                <span className="font-semibold text-[#242B27]">{tutor.availability}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer Actions */}
        <div className="bg-[#F8F6EF] p-4 sm:p-5 border-t border-[#E8E4D5] flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[11px] text-[#737D74] text-center sm:text-left">
            No upfront fees. Parents connect directly with tutors for free demo sessions.
          </p>

          <div className="flex items-center space-x-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl border border-[#E8E4D5] text-[#242B27] font-bold text-xs hover:bg-[#F2EFE5] transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onContact(tutor);
              }}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center space-x-2 px-6 py-2.5 rounded-xl bg-[#174C3C] hover:bg-[#0F3328] text-[#F8F6EF] font-bold text-xs shadow-md shadow-[#174C3C]/15 transition-all cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 text-[#E6BD68]" />
              <span>Send Contact Request</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
