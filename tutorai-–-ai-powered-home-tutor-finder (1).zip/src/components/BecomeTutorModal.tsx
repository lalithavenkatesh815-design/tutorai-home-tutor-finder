import React, { useState } from 'react';
import { X, UserPlus, CheckCircle2, ShieldAlert, GraduationCap, ArrowRight } from 'lucide-react';
import { ALL_LOCALITIES, TUTOR_CATEGORIES } from '../data/tutors';

interface BecomeTutorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BecomeTutorModal: React.FC<BecomeTutorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    qualification: '',
    category: 'Mathematics',
    subjects: 'Mathematics, Science',
    experience: 4,
    preferredAreas: 'Koramangala, Bengaluru',
    feeExpectation: 4500,
    teachingMode: 'Hybrid (Home + Online)',
    bio: 'Experienced educator dedicated to conceptual clarity, personalized pace, and student confidence.'
  });

  const [submitted, setSubmitted] = useState(false);
  const [appRef, setAppRef] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const ref = `TUTOR-APP-${Math.floor(10000 + Math.random() * 90000)}`;
    setAppRef(ref);

    try {
      const netlifyBody = new URLSearchParams({
        'form-name': 'tutor-application',
        ...formData,
        experience: formData.experience.toString(),
        feeExpectation: formData.feeExpectation.toString()
      }).toString();

      await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: netlifyBody
      });
    } catch {
      // Local demo mode fallback
    }

    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242B27]/70 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div 
        className="relative w-full max-w-2xl bg-[#FFFFFF] rounded-3xl shadow-2xl border border-[#E5E0D0] overflow-hidden my-6 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Editorial Header */}
        <div className="bg-[#174C3C] p-6 text-[#F8F6EF] flex items-center justify-between border-b border-[#242B27]/20">
          <div className="flex items-center space-x-3.5">
            <div className="w-11 h-11 rounded-2xl bg-[#E6BD68] text-[#174C3C] flex items-center justify-center font-bold shadow-sm">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-[#FFFFFF]/10 text-[#A8B9A0] text-[10px] font-bold uppercase tracking-wider mb-0.5">
                <span>Educator Onboarding</span>
              </div>
              <h2 className="text-xl font-bold font-serif text-[#F8F6EF]">Join TutorAI as a Home Educator</h2>
              <p className="text-xs text-[#A8B9A0]">Teach motivated students in your locality. Zero commission fees.</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#A8B9A0] hover:text-[#F8F6EF] rounded-xl hover:bg-[#FFFFFF]/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 bg-[#FDFCF7]">
          {submitted ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#174C3C]/10 text-[#174C3C] mx-auto flex items-center justify-center shadow-sm">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h3 className="text-2xl font-bold font-serif text-[#242B27]">Application Received</h3>
              <p className="text-xs text-[#737D74]">
                Reference ID: <strong className="font-mono text-[#174C3C] bg-[#174C3C]/5 px-2 py-0.5 rounded">{appRef}</strong>
              </p>
              
              <div className="p-5 bg-[#FFFFFF] rounded-2xl border border-[#E5E0D0] text-xs text-[#242B27] max-w-md mx-auto text-left space-y-2 shadow-sm">
                <p><strong>Candidate Name:</strong> {formData.name}</p>
                <p><strong>Qualification:</strong> {formData.qualification}</p>
                <p><strong>Category & Subjects:</strong> {formData.category} — {formData.subjects}</p>
                <p><strong>Expected Monthly Fee:</strong> ₹{formData.feeExpectation.toLocaleString('en-IN')}</p>
                <p><strong>Teaching Locality:</strong> {formData.preferredAreas}</p>
              </div>

              <div className="p-3.5 bg-[#E6BD68]/15 rounded-xl border border-[#E6BD68]/40 text-xs text-[#242B27] text-left flex items-start space-x-2.5 max-w-md mx-auto">
                <ShieldAlert className="w-4 h-4 text-[#D87952] flex-shrink-0 mt-0.5" />
                <span className="leading-relaxed">
                  <strong>Academic Demonstration Notice:</strong> In a production environment, our academic team verifies degree transcripts and background credentials prior to profile activation.
                </span>
              </div>

              <button
                onClick={() => {
                  setSubmitted(false);
                  onClose();
                }}
                className="mt-4 px-7 py-3 rounded-xl bg-[#174C3C] text-[#F8F6EF] font-bold text-xs hover:bg-[#12382c] transition-colors"
              >
                Close Application Window
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4" data-netlify="true" name="tutor-application">
              <input type="hidden" name="form-name" value="tutor-application" />

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Dr. Raghavendra Rao"
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C] focus:ring-1 focus:ring-[#174C3C]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="e.g. raghavendra@example.com"
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C] focus:ring-1 focus:ring-[#174C3C]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Mobile / WhatsApp *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="e.g. +91 98450 12345"
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C] focus:ring-1 focus:ring-[#174C3C]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Primary Category *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C]"
                  >
                    {TUTOR_CATEGORIES.map(cat => (
                      <option key={cat.id} value={cat.name}>{cat.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Highest Degree / Qualification *</label>
                  <input
                    type="text"
                    required
                    value={formData.qualification}
                    onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                    placeholder="e.g. M.Sc. Mathematics, B.Ed (Bangalore University)"
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Years of Experience *</label>
                  <input
                    type="number"
                    min="1"
                    max="40"
                    required
                    value={formData.experience}
                    onChange={(e) => setFormData({ ...formData, experience: parseInt(e.target.value, 10) })}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Subjects You Teach *</label>
                  <input
                    type="text"
                    required
                    value={formData.subjects}
                    onChange={(e) => setFormData({ ...formData, subjects: e.target.value })}
                    placeholder="e.g. Pure Mathematics, Statistics"
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Expected Fee (₹/month) *</label>
                  <input
                    type="number"
                    step="500"
                    min="1500"
                    max="15000"
                    required
                    value={formData.feeExpectation}
                    onChange={(e) => setFormData({ ...formData, feeExpectation: parseInt(e.target.value, 10) })}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Preferred Locality / City</label>
                  <input
                    type="text"
                    value={formData.preferredAreas}
                    onChange={(e) => setFormData({ ...formData, preferredAreas: e.target.value })}
                    placeholder="e.g. Vijayapura, Dharwad, Koramangala"
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#242B27] block mb-1">Teaching Mode</label>
                  <select
                    value={formData.teachingMode}
                    onChange={(e) => setFormData({ ...formData, teachingMode: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C]"
                  >
                    <option value="Home Visit Only">Home Visit (At Student's Residence)</option>
                    <option value="Online Only">Online Only (1-on-1 Pen Tablet)</option>
                    <option value="Hybrid (Home + Online)">Hybrid (Home + Online)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-[#242B27] block mb-1">Teaching Philosophy & Methodology</label>
                <textarea
                  rows={3}
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  placeholder="Outline your approach to doubt resolution, student diagnostic pacing, and syllabus mastery..."
                  className="w-full px-3 py-2.5 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-xs sm:text-sm text-[#242B27] focus:outline-none focus:border-[#174C3C]"
                />
              </div>

              <div className="pt-3 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-[#E5E0D0]">
                <p className="text-[11px] text-[#737D74]">
                  No upfront registration charges or deduction on tutor earnings.
                </p>
                <button
                  type="submit"
                  className="w-full sm:w-auto px-7 py-3 rounded-xl bg-[#D87952] hover:bg-[#c46944] text-[#FFFFFF] font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer flex items-center justify-center space-x-2"
                >
                  <span>Submit Tutor Application</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
