import React, { useState } from 'react';
import { 
  CalendarCheck, 
  X, 
  Sparkles, 
  Copy, 
  Printer, 
  Check, 
  Clock, 
  BookOpen, 
  Lightbulb, 
  Target, 
  RotateCcw,
  Bot
} from 'lucide-react';
import { ALL_CLASSES, ALL_SUBJECTS } from '../data/tutors';
import { StudyPlanRequest, StudyPlanResponse } from '../types/tutor';
import { generateStudyPlanWithAI } from '../services/geminiService';

interface StudyPlannerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StudyPlannerModal: React.FC<StudyPlannerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [studentClass, setStudentClass] = useState('Class 10');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(['Mathematics', 'Science (Physics, Chem, Bio)']);
  const [examDate, setExamDate] = useState('2026-12-15');
  const [dailyHours, setDailyHours] = useState<number>(3);
  const [weakTopics, setWeakTopics] = useState('Quadratic equations, Trigonometry derivations, Chemical balancing');
  const [learningGoals, setLearningGoals] = useState('Score 90%+ in board exams and maintain daily homework consistency');

  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<StudyPlanResponse | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const toggleSubject = (sub: string) => {
    if (selectedSubjects.includes(sub)) {
      if (selectedSubjects.length > 1) {
        setSelectedSubjects(selectedSubjects.filter(s => s !== sub));
      }
    } else {
      if (selectedSubjects.length < 5) {
        setSelectedSubjects([...selectedSubjects, sub]);
      }
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const req: StudyPlanRequest = {
        studentClass,
        subjects: selectedSubjects,
        examDate,
        dailyHours,
        weakTopics,
        learningGoals
      };
      const res = await generateStudyPlanWithAI(req);
      setPlan(res);
    } catch {
      // Handled in service
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!plan) return;
    const textToCopy = `TUTORAI PERSONALIZED STUDY BLUEPRINT
========================================
Student: ${studentClass}
Exam Target: ${examDate}
Daily Study Commitment: ${dailyHours} Hours
Subjects: ${selectedSubjects.join(', ')}

OVERVIEW:
${plan.overview}

DAILY TIMETABLE:
${plan.dailySchedule.map(s => `${s.timeSlot} | ${s.subject} (${s.activity})\nFocus: ${s.focus}`).join('\n\n')}

WEEKLY MILESTONES:
${plan.weeklyGoals.map(g => `• ${g}`).join('\n')}

REVISION & POMODORO STRATEGY:
${plan.pomodoroAdvice}

EXAM PREPARATION TIPS:
${plan.examTips.map(t => `• ${t}`).join('\n')}
========================================
Generated via TutorAI Home Tutor Finder`;

    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242B27]/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-[#E8E4D5] overflow-hidden my-6 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header - Forest Green */}
        <div className="bg-[#174C3C] p-6 text-[#F8F6EF] flex items-center justify-between border-b border-[#0F3328]">
          <div className="flex items-center space-x-3.5">
            <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center shadow-xs">
              <CalendarCheck className="w-6 h-6 text-[#E6BD68]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-serif font-black text-white">AI Study Routine & Timetable Planner</h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E6BD68]/20 text-[#E6BD68] border border-[#E6BD68]/30">
                  Smart Scheduler
                </span>
              </div>
              <p className="text-xs text-[#A8B9A0]">Generates structured daily study slots and home tutor revision milestones</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#A8B9A0] hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 bg-white">
          
          {!plan ? (
            /* Input Form */
            <form onSubmit={handleGenerate} className="space-y-6">
              
              <div className="bg-[#F8F6EF] p-4 rounded-2xl border border-[#E8E4D5] flex items-start space-x-3 text-xs text-[#242B27]">
                <Bot className="w-5 h-5 text-[#174C3C] flex-shrink-0 mt-0.5" />
                <span className="leading-relaxed">
                  Our AI engine aligns with Indian board examination cycles (CBSE, ICSE, State Boards). Enter your available study hours and targeted exam date to produce an optimal daily study blueprint.
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                
                {/* Student Class */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                    Class / Grade
                  </label>
                  <select
                    value={studentClass}
                    onChange={(e) => setStudentClass(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  >
                    {ALL_CLASSES.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

                {/* Exam Date */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                    Target Exam Date
                  </label>
                  <input
                    type="date"
                    value={examDate}
                    onChange={(e) => setExamDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  />
                </div>

                {/* Daily Hours Slider */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-[#737D74]">
                      Daily Study Hours
                    </label>
                    <span className="text-xs font-bold text-[#174C3C] bg-[#E8EFE5] px-2 py-0.5 rounded-md border border-[#A8B9A0]/50">
                      {dailyHours} Hours / Day
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="6"
                    step="0.5"
                    value={dailyHours}
                    onChange={(e) => setDailyHours(parseFloat(e.target.value))}
                    className="w-full h-2 bg-[#E8E4D5] rounded-lg appearance-none cursor-pointer accent-[#174C3C]"
                  />
                  <div className="flex justify-between text-[10px] text-[#737D74] mt-1">
                    <span>1 hr (Light)</span>
                    <span>3 hrs (Standard)</span>
                    <span>6 hrs (Intensive)</span>
                  </div>
                </div>

              </div>

              {/* Subject Selection Chips */}
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                  Select Focus Subjects (Max 5)
                </label>
                <div className="flex flex-wrap gap-2">
                  {ALL_SUBJECTS.slice(0, 12).map((sub) => {
                    const isSelected = selectedSubjects.includes(sub);
                    return (
                      <button
                        type="button"
                        key={sub}
                        onClick={() => toggleSubject(sub)}
                        className={`text-xs font-semibold px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#174C3C] text-[#F8F6EF] shadow-xs'
                            : 'bg-[#F8F6EF] text-[#242B27] hover:bg-[#EDE9DC] border border-[#E8E4D5]'
                        }`}
                      >
                        {sub}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Weak Topics */}
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                  Difficult / Weak Topics Needing Extra Attention
                </label>
                <input
                  type="text"
                  value={weakTopics}
                  onChange={(e) => setWeakTopics(e.target.value)}
                  placeholder="e.g. Calculus, Optics, Chemical Reactions, Organic Mechanisms"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                />
              </div>

              {/* Learning Goals */}
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                  Primary Academic Goal
                </label>
                <input
                  type="text"
                  value={learningGoals}
                  onChange={(e) => setLearningGoals(e.target.value)}
                  placeholder="e.g. Score 90%+ in upcoming boards, finish syllabus 2 weeks before exams"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                />
              </div>

              {/* Action */}
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-8 py-3 rounded-2xl bg-[#174C3C] hover:bg-[#0F3328] text-white font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <Sparkles className="w-4 h-4 animate-spin text-[#E6BD68]" />
                      <span>Generating Custom Timetable...</span>
                    </>
                  ) : (
                    <>
                      <span>Generate Study Blueprint</span>
                      <Sparkles className="w-4 h-4 text-[#E6BD68]" />
                    </>
                  )}
                </button>
              </div>

            </form>
          ) : (
            /* Generated Timetable View */
            <div className="space-y-6 print:m-0 print:p-0">
              
              {/* Actions Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-[#F8F6EF] rounded-2xl border border-[#E8E4D5]">
                <div>
                  <h3 className="font-serif font-bold text-[#242B27] text-base">Your Custom Study Plan</h3>
                  <p className="text-xs text-[#737D74]">
                    {studentClass} • {dailyHours} Hours Daily • Target Exam: {examDate}
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleCopy}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-white border border-[#E8E4D5] text-[#242B27] hover:bg-[#FDFCF7] text-xs font-bold transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-[#174C3C]" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy Plan'}</span>
                  </button>
                  <button
                    onClick={() => window.print()}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-white border border-[#E8E4D5] text-[#242B27] hover:bg-[#FDFCF7] text-xs font-bold transition-colors cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print</span>
                  </button>
                  <button
                    onClick={() => setPlan(null)}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-[#174C3C] hover:bg-[#0F3328] text-white text-xs font-bold transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-[#E6BD68]" />
                    <span>New Plan</span>
                  </button>
                </div>
              </div>

              {/* Overview */}
              <div className="p-4 bg-[#E8EFE5] rounded-2xl border border-[#A8B9A0]/50 text-xs sm:text-sm text-[#174C3C] leading-relaxed">
                {plan.overview}
              </div>

              {/* Daily Schedule Slots */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#737D74] mb-3 flex items-center space-x-1.5">
                  <Clock className="w-4 h-4 text-[#174C3C]" />
                  <span>Recommended Daily Time Slots</span>
                </h4>
                <div className="space-y-3">
                  {plan.dailySchedule.map((slot, sIdx) => (
                    <div
                      key={sIdx}
                      className="p-4 rounded-2xl bg-white border border-[#E8E4D5] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="flex items-start space-x-3">
                        <div className="px-2.5 py-1 rounded-xl bg-[#F8F6EF] text-[#174C3C] font-mono font-bold text-xs border border-[#E8E4D5]">
                          {slot.timeSlot}
                        </div>
                        <div>
                          <span className="font-serif font-bold text-[#242B27] text-sm">{slot.activity}</span>
                          <span className="ml-2 text-xs font-semibold px-2 py-0.5 rounded-md bg-[#E8EFE5] text-[#174C3C]">
                            {slot.subject}
                          </span>
                          <p className="text-xs text-[#737D74] mt-1">
                            <strong className="text-[#242B27]">Action:</strong> {slot.focus}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Weekly Goals & Revision Advice */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="p-5 rounded-2xl bg-[#F8F6EF] border border-[#E8E4D5]">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#174C3C] mb-2.5 flex items-center space-x-1.5">
                    <Target className="w-4 h-4 text-[#D87952]" />
                    <span>Weekly Milestones</span>
                  </h4>
                  <ul className="space-y-2 text-xs text-[#242B27]">
                    {plan.weeklyGoals.map((goal, gIdx) => (
                      <li key={gIdx} className="flex items-start space-x-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#174C3C] mt-1.5 flex-shrink-0" />
                        <span>{goal}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-5 rounded-2xl bg-[#F8F6EF] border border-[#E8E4D5]">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#174C3C] mb-2.5 flex items-center space-x-1.5">
                    <Lightbulb className="w-4 h-4 text-[#E6BD68]" />
                    <span>Pomodoro & Focus Tips</span>
                  </h4>
                  <p className="text-xs text-[#737D74] leading-relaxed mb-3">
                    {plan.pomodoroAdvice}
                  </p>
                  <div className="border-t border-[#E8E4D5] pt-2 space-y-1 text-xs text-[#242B27]">
                    {plan.examTips.slice(0, 2).map((tip, tIdx) => (
                      <div key={tIdx} className="flex items-start space-x-1.5">
                        <span className="text-[#174C3C] font-bold">✓</span>
                        <span>{tip}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
