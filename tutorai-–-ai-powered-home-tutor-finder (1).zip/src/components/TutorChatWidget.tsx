import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  X, 
  Send, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Bot, 
  User, 
  Maximize2, 
  Minimize2, 
  Info
} from 'lucide-react';
import { askTutorChat, ChatMessage } from '../services/geminiService';
import { useSpeechSynthesis } from '../hooks/useSpeechSynthesis';

interface TutorChatWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  onOpen: () => void;
  onNavigateToTab?: (tab: string) => void;
}

const SUGGESTED_PROMPTS = [
  "Find me a mathematics tutor under ₹4,000",
  "Which tutor has the most teaching experience?",
  "What questions should I ask before hiring a home tutor?",
  "Recommend a science tutor in Vijayapura or Dharwad",
  "How does hybrid tuition compare to home visits?"
];

export const TutorChatWidget: React.FC<TutorChatWidgetProps> = ({
  isOpen,
  onClose,
  onOpen,
  onNavigateToTab,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'assistant',
      text: "Namaste! I'm **TutorChat**, your personal educational advisor. I can help you find verified home tutors nearby, recommend educators based on your monthly budget, or advise on study routines. How can I assist your child today?",
      timestamp: new Date(),
      source: 'gemini'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { speak, stop, isSpeaking, speakingTextId, isSupported: isTtsSupported } = useSpeechSynthesis();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen, loading]);

  const handleSend = async (textToSend?: string) => {
    const text = textToSend || input;
    if (!text.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const history = messages.map(m => ({ sender: m.sender, text: m.text }));
      const { reply, source } = await askTutorChat(userMsg.text, history);

      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        sender: 'assistant',
        text: reply,
        timestamp: new Date(),
        source
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      const errorMsg: ChatMessage = {
        id: `assistant-err-${Date.now()}`,
        sender: 'assistant',
        text: "I am having temporary trouble connecting to the network, but our full tutor directory and filters are always available in the 'Find Tutors' tab!",
        timestamp: new Date(),
        source: 'rule-fallback'
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    stop();
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        sender: 'assistant',
        text: "Chat cleared! How can I help you find the right home tutor or study plan?",
        timestamp: new Date(),
        source: 'gemini'
      }
    ]);
  };

  const handleToggleTts = (msgId: string, text: string) => {
    if (isSpeaking && speakingTextId === msgId) {
      stop();
    } else {
      speak(text, msgId);
    }
  };

  // Minimized Floating Button in Forest Green & Terracotta
  if (!isOpen) {
    return (
      <aside aria-label="TutorChat AI Assistant" className="fixed bottom-6 right-6 z-40">
        <button
          onClick={onOpen}
          aria-label="Open TutorChat AI"
          className="group flex items-center space-x-2.5 px-4 py-3 bg-[#174C3C] hover:bg-[#0F3328] text-[#F8F6EF] rounded-full shadow-xl shadow-[#174C3C]/25 border border-[#A8B9A0]/40 transition-all transform hover:scale-104 cursor-pointer"
        >
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center relative">
            <Sparkles className="w-4 h-4 text-[#E6BD68]" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#D87952] rounded-full animate-ping" />
          </div>
          <div className="text-left">
            <div className="text-xs font-serif font-black tracking-wide flex items-center space-x-1">
              <span>Ask TutorChat</span>
              <span className="text-[10px] bg-[#E6BD68]/20 text-[#E6BD68] px-1 py-0.2 rounded font-bold">AI</span>
            </div>
            <p className="text-[10px] text-[#A8B9A0] font-medium">Instant Tutor Advice</p>
          </div>
        </button>
      </aside>
    );
  }

  // Expanded Floating Chat Window
  return (
    <aside 
      aria-label="TutorChat AI Assistant"
      className={`fixed z-50 transition-all duration-300 flex flex-col shadow-2xl bg-white border border-[#E8E4D5] overflow-hidden ${
        isExpanded
          ? 'inset-4 sm:inset-10 rounded-3xl'
          : 'bottom-4 right-4 sm:bottom-6 sm:right-6 w-[95vw] sm:w-[420px] h-[580px] max-h-[85vh] rounded-3xl'
      }`}
    >
      {/* Header - Forest Green */}
      <div className="bg-[#174C3C] p-4 text-[#F8F6EF] flex items-center justify-between border-b border-[#0F3328]">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center shadow-xs">
            <Bot className="w-5 h-5 text-[#E6BD68]" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="font-serif font-bold text-sm tracking-wide text-[#F8F6EF]">TutorChat AI</h3>
              <span className="text-[9px] bg-[#E6BD68]/20 text-[#E6BD68] border border-[#E6BD68]/30 font-bold px-1.5 py-0.2 rounded">
                Live Advisor
              </span>
            </div>
            <p className="text-[10px] text-[#A8B9A0] font-medium">Understands fees, subjects & localities</p>
          </div>
        </div>

        <div className="flex items-center space-x-1 text-[#A8B9A0]">
          <button
            onClick={handleClear}
            title="Reset conversation"
            className="p-1.5 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            title={isExpanded ? "Collapse" : "Expand"}
            className="hidden sm:block p-1.5 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => {
              stop();
              onClose();
            }}
            title="Close TutorChat"
            className="p-1.5 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Demonstration Banner */}
      <div className="bg-[#FAF5E8] px-3.5 py-1.5 border-b border-[#EADFC7] flex items-center space-x-1.5 text-[11px] text-[#7A5813]">
        <Info className="w-3.5 h-3.5 flex-shrink-0 text-[#D87952]" />
        <span className="truncate">TutorAI Demo Assistant – Safe server-side processing with rule fallback</span>
      </div>

      {/* Messages Scroll Area - Warm Ivory Background */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#F8F6EF]/70">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start space-x-2.5 ${isUser ? 'flex-row-reverse space-x-reverse' : ''}`}
            >
              <div
                className={`w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 text-xs ${
                  isUser ? 'bg-[#174C3C] text-white' : 'bg-[#E8EFE5] text-[#174C3C]'
                }`}
              >
                {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>

              <div className={`max-w-[85%] flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
                <div
                  className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-xs ${
                    isUser
                      ? 'bg-[#174C3C] text-[#F8F6EF] rounded-tr-none'
                      : 'bg-white text-[#242B27] border border-[#E8E4D5] rounded-tl-none whitespace-pre-line'
                  }`}
                >
                  {/* Clean Markdown parsing for bold text */}
                  {msg.text.split('\n').map((paragraph, pIdx) => (
                    <p key={pIdx} className={pIdx > 0 ? 'mt-2' : ''}>
                      {paragraph.split('**').map((part, idx) => 
                        idx % 2 === 1 ? <strong key={idx} className="font-bold text-[#174C3C]">{part}</strong> : part
                      )}
                    </p>
                  ))}
                </div>

                {/* Sub-bar for assistant: source badge and Voice Read Aloud button */}
                {!isUser && (
                  <div className="flex items-center space-x-2.5 mt-1 px-1">
                    <span className="text-[10px] text-[#737D74]">
                      {msg.source === 'gemini' ? '✨ Gemini 3.8' : '⚙️ Rule Engine'}
                    </span>
                    {isTtsSupported && (
                      <button
                        onClick={() => handleToggleTts(msg.id, msg.text)}
                        className={`text-[10px] font-bold flex items-center space-x-1 px-1.5 py-0.5 rounded transition-colors cursor-pointer ${
                          isSpeaking && speakingTextId === msg.id
                            ? 'bg-[#FAECE5] text-[#D87952]'
                            : 'text-[#737D74] hover:text-[#174C3C]'
                        }`}
                        title={isSpeaking && speakingTextId === msg.id ? "Stop voice" : "Read aloud"}
                      >
                        {isSpeaking && speakingTextId === msg.id ? (
                          <>
                            <VolumeX className="w-3 h-3 text-[#D87952] animate-pulse" />
                            <span>Stop</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3 h-3 text-[#737D74]" />
                            <span>Listen</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex items-start space-x-2.5">
            <div className="w-7 h-7 rounded-xl bg-[#E8EFE5] text-[#174C3C] flex items-center justify-center flex-shrink-0">
              <Bot className="w-3.5 h-3.5 animate-spin text-[#174C3C]" />
            </div>
            <div className="bg-white border border-[#E8E4D5] p-3 rounded-2xl rounded-tl-none shadow-xs flex items-center space-x-2 text-xs text-[#737D74]">
              <span className="w-2 h-2 rounded-full bg-[#174C3C] animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-[#174C3C] animate-bounce [animation-delay:0.2s]" />
              <span className="w-2 h-2 rounded-full bg-[#174C3C] animate-bounce [animation-delay:0.4s]" />
              <span className="ml-1 font-medium">TutorChat is consulting tutor records...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Pills */}
      {messages.length <= 2 && (
        <div className="px-3.5 py-2 bg-white border-t border-[#E8E4D5] flex items-center space-x-2 overflow-x-auto no-scrollbar">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#737D74] flex-shrink-0">Try:</span>
          {SUGGESTED_PROMPTS.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(prompt)}
              className="text-[11px] font-medium whitespace-nowrap px-2.5 py-1 rounded-full bg-[#F8F6EF] hover:bg-[#E8EFE5] text-[#242B27] hover:text-[#174C3C] border border-[#E8E4D5] transition-colors flex-shrink-0 cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>
      )}

      {/* Input Area */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="p-3 bg-white border-t border-[#E8E4D5] flex items-center space-x-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask e.g. 'Math tutor in Dharwad under ₹3000'..."
          disabled={loading}
          className="flex-1 px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7] disabled:bg-[#F2EFE5]"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="p-2.5 rounded-xl bg-[#174C3C] hover:bg-[#0F3328] text-[#F8F6EF] font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-xs cursor-pointer"
        >
          <Send className="w-4 h-4 text-[#E6BD68]" />
        </button>
      </form>
    </aside>
  );
};
