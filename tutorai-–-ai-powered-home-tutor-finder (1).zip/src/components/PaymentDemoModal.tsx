import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  Check, 
  ArrowRight, 
  Receipt, 
  Info,
  Printer,
  Sparkles
} from 'lucide-react';
import { Tutor } from '../types/tutor';

interface PaymentDemoModalProps {
  tutor: Tutor | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PaymentDemoModal: React.FC<PaymentDemoModalProps> = ({
  tutor,
  isOpen,
  onClose,
}) => {
  const [selectedMethod, setSelectedMethod] = useState<'upi' | 'cash' | 'netbanking'>('upi');
  const [demoReceiptGenerated, setDemoReceiptGenerated] = useState(false);
  const [receiptNumber, setReceiptNumber] = useState('');

  if (!isOpen || !tutor) return null;

  const baseMonthly = tutor.monthlyFee;
  const studyKitDemo = 250;
  const totalDemoAmount = baseMonthly + studyKitDemo;

  const handleGenerateDemoReceipt = () => {
    const randomReceipt = `TUTORAI-VCH-${Math.floor(100000 + Math.random() * 900000)}`;
    setReceiptNumber(randomReceipt);
    setDemoReceiptGenerated(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242B27]/70 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div 
        className="relative w-full max-w-xl bg-[#FFFFFF] rounded-3xl shadow-2xl border border-[#E5E0D0] overflow-hidden my-6 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Demonstration Alert Banner */}
        <div className="bg-[#E6BD68] text-[#242B27] px-4 py-2.5 flex items-center justify-between text-xs font-bold tracking-wide border-b border-[#d8ad52]">
          <span className="flex items-center space-x-2">
            <ShieldAlert className="w-4 h-4 text-[#D87952] flex-shrink-0" />
            <span className="uppercase text-[11px] font-black">Demonstration Sandbox — No Actual Payments Processed</span>
          </span>
          <button onClick={onClose} className="p-1 hover:bg-[#d8ad52] rounded text-[#242B27]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-7 overflow-y-auto flex-1 space-y-6 bg-[#FDFCF7]">
          
          {!demoReceiptGenerated ? (
            <>
              {/* Tutor Summary Card */}
              <div className="p-4 rounded-2xl bg-[#FFFFFF] border border-[#E5E0D0] flex items-center space-x-4 shadow-sm">
                <img
                  src={tutor.avatar}
                  alt={tutor.name}
                  className="w-14 h-14 rounded-2xl object-cover border border-[#E5E0D0]"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(tutor.name)}&background=174C3C&color=F8F6EF&size=128`;
                  }}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#174C3C] bg-[#174C3C]/10 px-2 py-0.5 rounded-full">
                      {tutor.category}
                    </span>
                  </div>
                  <h3 className="font-serif font-bold text-[#242B27] text-base truncate mt-0.5">{tutor.name}</h3>
                  <p className="text-xs text-[#737D74]">{tutor.locality}, {tutor.city} • {tutor.teachingMode}</p>
                </div>
              </div>

              {/* Tuition Amount Breakdown */}
              <div className="space-y-2.5 text-xs">
                <span className="font-bold uppercase tracking-wider text-[#737D74] text-[11px] block">
                  Tuition Fee Structure Breakdown
                </span>

                <div className="p-5 rounded-2xl bg-[#FFFFFF] border border-[#E5E0D0] space-y-2.5 shadow-sm">
                  <div className="flex justify-between text-[#242B27]">
                    <span>Monthly Tuition (~12 Sessions):</span>
                    <span className="font-bold text-[#242B27]">₹{baseMonthly.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-[#242B27]">
                    <span>Diagnostic Concept Kit (Demo):</span>
                    <span className="font-bold text-[#242B27]">₹{studyKitDemo}</span>
                  </div>
                  <div className="flex justify-between text-[#174C3C] font-semibold">
                    <span>Platform Matching & Direct Contact:</span>
                    <span className="bg-[#174C3C]/10 px-2 py-0.5 rounded text-[11px]">₹0 Free</span>
                  </div>
                  
                  <div className="pt-3 border-t border-[#E5E0D0] flex justify-between items-baseline text-[#242B27]">
                    <span className="font-serif font-bold text-sm">Estimated Total:</span>
                    <span className="text-2xl font-black font-serif text-[#174C3C]">₹{totalDemoAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              {/* Simulated Payment Modes */}
              <div>
                <span className="font-bold uppercase tracking-wider text-[#737D74] text-[11px] block mb-2">
                  Preferred Payment Channel (Simulation)
                </span>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('upi')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      selectedMethod === 'upi'
                        ? 'border-[#174C3C] bg-[#174C3C]/5 shadow-sm'
                        : 'border-[#E5E0D0] bg-[#FFFFFF] hover:bg-[#F8F6EF]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-[#242B27]">UPI / QR</span>
                      {selectedMethod === 'upi' && <Check className="w-4 h-4 text-[#174C3C]" />}
                    </div>
                    <p className="text-[10px] text-[#737D74]">GPay, PhonePe, Paytm</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedMethod('cash')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      selectedMethod === 'cash'
                        ? 'border-[#174C3C] bg-[#174C3C]/5 shadow-sm'
                        : 'border-[#E5E0D0] bg-[#FFFFFF] hover:bg-[#F8F6EF]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-[#242B27]">Pay at Home</span>
                      {selectedMethod === 'cash' && <Check className="w-4 h-4 text-[#174C3C]" />}
                    </div>
                    <p className="text-[10px] text-[#737D74]">Direct cash to Tutor</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedMethod('netbanking')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      selectedMethod === 'netbanking'
                        ? 'border-[#174C3C] bg-[#174C3C]/5 shadow-sm'
                        : 'border-[#E5E0D0] bg-[#FFFFFF] hover:bg-[#F8F6EF]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-[#242B27]">NetBanking</span>
                      {selectedMethod === 'netbanking' && <Check className="w-4 h-4 text-[#174C3C]" />}
                    </div>
                    <p className="text-[10px] text-[#737D74]">IMPS / NEFT transfer</p>
                  </button>
                </div>
              </div>

              {/* Safety notice */}
              <div className="p-3.5 bg-[#FFFFFF] border border-[#E5E0D0] rounded-xl text-[#737D74] text-[11px] leading-relaxed flex items-start space-x-2.5">
                <Info className="w-4 h-4 text-[#174C3C] flex-shrink-0 mt-0.5" />
                <span>
                  TutorAI does not store card numbers, UPI PINs, or banking credentials. Parents pay fees directly to the tutor after the first introductory session.
                </span>
              </div>

              {/* Action Button */}
              <button
                onClick={handleGenerateDemoReceipt}
                className="w-full py-3.5 rounded-xl bg-[#D87952] hover:bg-[#c46944] text-[#FFFFFF] font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 shadow-md transition-all cursor-pointer"
              >
                <span>Generate Demo Booking Voucher</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </>
          ) : (
            /* Mock Receipt View */
            <div className="space-y-4">
              <div className="relative p-7 rounded-3xl bg-[#174C3C] text-[#F8F6EF] border border-[#242B27] shadow-xl overflow-hidden">
                
                {/* Watermark */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5 select-none">
                  <span className="text-4xl font-black rotate-[-25deg] uppercase tracking-widest text-[#F8F6EF]">
                    DEMO VOUCHER — NOT REAL TENDER
                  </span>
                </div>

                <div className="flex items-start justify-between border-b border-[#FFFFFF]/15 pb-4">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#E6BD68]">TutorAI Educational Voucher</span>
                    <h4 className="text-xl font-bold font-serif text-[#F8F6EF]">Tuition Booking Preview</h4>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-[#FFFFFF]/10 flex items-center justify-center">
                    <Receipt className="w-5 h-5 text-[#E6BD68]" />
                  </div>
                </div>

                <div className="mt-5 space-y-2.5 text-xs">
                  <div className="flex justify-between text-[#A8B9A0]">
                    <span>Voucher No:</span>
                    <span className="font-mono text-[#F8F6EF] font-bold">{receiptNumber}</span>
                  </div>
                  <div className="flex justify-between text-[#A8B9A0]">
                    <span>Educator:</span>
                    <span className="text-[#F8F6EF] font-bold">{tutor.name}</span>
                  </div>
                  <div className="flex justify-between text-[#A8B9A0]">
                    <span>Subject & Locality:</span>
                    <span className="text-[#F8F6EF]">{tutor.subjects.slice(0, 2).join(', ')} • {tutor.locality}</span>
                  </div>
                  <div className="flex justify-between text-[#A8B9A0]">
                    <span>Payment Channel:</span>
                    <span className="text-[#F8F6EF] capitalize">{selectedMethod} (Demo Option)</span>
                  </div>
                  <div className="pt-3 border-t border-[#FFFFFF]/15 flex justify-between text-base font-bold text-[#E6BD68]">
                    <span>Estimated Monthly Fee:</span>
                    <span>₹{totalDemoAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-[#FFFFFF]/15 text-[10px] text-[#A8B9A0]">
                  Status: <strong className="text-[#E6BD68]">Simulated Demo Voucher (No financial transaction performed)</strong>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <button
                  onClick={() => window.print()}
                  className="flex-1 py-3 rounded-xl border border-[#E5E0D0] bg-[#FFFFFF] text-[#242B27] font-bold text-xs flex items-center justify-center space-x-1.5 hover:bg-[#F8F6EF] transition-colors"
                >
                  <Printer className="w-3.5 h-3.5 text-[#174C3C]" />
                  <span>Print Voucher</span>
                </button>
                <button
                  onClick={() => setDemoReceiptGenerated(false)}
                  className="flex-1 py-3 rounded-xl bg-[#174C3C] text-[#F8F6EF] font-bold text-xs hover:bg-[#12382c] transition-colors"
                >
                  Back to Summary
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
