import React, { useState } from 'react';
import { 
  GraduationCap, 
  Sparkles, 
  Heart, 
  Layers, 
  Calculator, 
  MapPin, 
  CalendarCheck, 
  UserPlus, 
  Menu, 
  X,
  MessageSquare
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  favoritesCount: number;
  compareCount: number;
  onOpenFavorites: () => void;
  onOpenCompare: () => void;
  onOpenChat: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  favoritesCount,
  compareCount,
  onOpenFavorites,
  onOpenCompare,
  onOpenChat,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'directory', label: 'Find Tutors', icon: GraduationCap },
    { id: 'smart-match', label: 'Smart Match', icon: Sparkles, badge: 'AI' },
    { id: 'study-planner', label: 'Study Planner', icon: CalendarCheck, badge: 'AI' },
    { id: 'calculator', label: 'Fee Calculator', icon: Calculator },
    { id: 'map', label: 'Map Explorer', icon: MapPin },
    { id: 'become-tutor', label: 'Become a Tutor', icon: UserPlus },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FDFCF7]/95 backdrop-blur-md border-b border-[#E8E4D5] text-[#242B27] transition-all shadow-[0_2px_12px_rgba(23,76,60,0.04)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Logo - Deep Forest Green & Terracotta */}
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center space-x-3 cursor-pointer group select-none"
          >
            <div className="w-11 h-11 rounded-2xl bg-[#174C3C] flex items-center justify-center text-[#F8F6EF] shadow-md shadow-[#174C3C]/15 group-hover:scale-105 transition-transform">
              <GraduationCap className="w-6 h-6 text-[#E6BD68]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-serif font-black tracking-tight text-[#174C3C]">
                  Tutor<span className="text-[#D87952]">AI</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-[#E8EFE5] text-[#174C3C] border border-[#A8B9A0]/50">
                  Home Tutor Finder
                </span>
              </div>
              <p className="text-[11px] text-[#737D74] font-medium hidden sm:block">Find Your Perfect Tutor. Learn Smarter With AI.</p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-1.5">
            <button
              onClick={() => handleNavClick('home')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'home'
                  ? 'text-[#174C3C] bg-[#E8EFE5] shadow-xs'
                  : 'text-[#242B27] hover:text-[#174C3C] hover:bg-[#F2EFE5]'
              }`}
            >
              Home
            </button>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all relative ${
                    isActive
                      ? 'text-[#174C3C] bg-[#E8EFE5] shadow-xs'
                      : 'text-[#242B27] hover:text-[#174C3C] hover:bg-[#F2EFE5]'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#174C3C]' : 'text-[#737D74]'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-[#D87952]/15 text-[#D87952] border border-[#D87952]/30">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            
            {/* AI Assistant Quick Pill */}
            <button
              onClick={onOpenChat}
              className="hidden md:flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-[#E8EFE5] hover:bg-[#DDE7DA] border border-[#A8B9A0]/60 text-[#174C3C] text-xs font-bold transition-all hover:scale-102 cursor-pointer shadow-xs"
              title="Open TutorChat AI"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D87952] animate-pulse" />
              <span>TutorChat</span>
            </button>

            {/* Favourites button */}
            <button
              onClick={onOpenFavorites}
              aria-label="Favorites"
              className="relative p-2.5 rounded-xl bg-white hover:bg-[#F2EFE5] text-[#242B27] hover:text-[#D87952] border border-[#E8E4D5] transition-colors cursor-pointer shadow-xs"
              title="Saved Tutors"
            >
              <Heart className={`w-4 h-4 ${favoritesCount > 0 ? 'fill-[#D87952] text-[#D87952]' : ''}`} />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#D87952] text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Compare Drawer Trigger */}
            <button
              onClick={onOpenCompare}
              aria-label="Compare Tutors"
              className="relative p-2.5 rounded-xl bg-white hover:bg-[#F2EFE5] text-[#242B27] hover:text-[#174C3C] border border-[#E8E4D5] transition-colors cursor-pointer shadow-xs"
              title="Compare Tutors"
            >
              <Layers className="w-4 h-4" />
              {compareCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#174C3C] text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow">
                  {compareCount}
                </span>
              )}
            </button>

            {/* Find My Tutor CTA */}
            <button
              onClick={() => handleNavClick('directory')}
              className="hidden sm:inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-[#174C3C] hover:bg-[#0F3328] text-[#F8F6EF] font-bold text-xs shadow-md shadow-[#174C3C]/15 transition-all transform hover:-translate-y-0.5 cursor-pointer"
            >
              <span>Find My Tutor</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-[#242B27] hover:bg-[#F2EFE5]"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FDFCF7] border-b border-[#E8E4D5] px-4 pt-3 pb-6 space-y-2 shadow-xl animate-fade-in">
          <button
            onClick={() => handleNavClick('home')}
            className={`w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-bold text-left ${
              activeTab === 'home' ? 'bg-[#174C3C] text-white' : 'text-[#242B27] hover:bg-[#F2EFE5]'
            }`}
          >
            Home
          </button>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-bold text-left ${
                  isActive ? 'bg-[#174C3C] text-white' : 'text-[#242B27] hover:bg-[#F2EFE5]'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#E6BD68]' : 'text-[#737D74]'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#D87952]/20 text-[#D87952]">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
          
          <div className="pt-3 border-t border-[#E8E4D5] flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenChat();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center space-x-2 py-2.5 rounded-xl bg-[#E8EFE5] border border-[#A8B9A0] text-[#174C3C] font-bold text-xs"
            >
              <MessageSquare className="w-4 h-4 text-[#D87952]" />
              <span>Ask TutorChat AI</span>
            </button>
            <button
              onClick={() => handleNavClick('directory')}
              className="w-full py-2.5 rounded-xl bg-[#174C3C] text-[#F8F6EF] font-bold text-xs shadow-md"
            >
              Find My Tutor Now
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
