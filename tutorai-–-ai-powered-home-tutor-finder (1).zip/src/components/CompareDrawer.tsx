import React from 'react';
import { 
  X, 
  Layers, 
  Star, 
  MapPin, 
  Briefcase, 
  Clock, 
  Send, 
  Check, 
  Award, 
  Trash2,
  Maximize2
} from 'lucide-react';
import { Tutor } from '../types/tutor';

interface CompareDrawerProps {
  comparedTutors: Tutor[];
  onRemove: (tutorId: string) => void;
  onClear: () => void;
  onContact: (tutor: Tutor) => void;
  isOpen: boolean;
  onClose: () => void;
  onOpen: () => void;
}

export const CompareDrawer: React.FC<CompareDrawerProps> = ({
  comparedTutors,
  onRemove,
  onClear,
  onContact,
  isOpen,
  onClose,
  onOpen,
}) => {
  if (comparedTutors.length === 0) return null;

  // Find highlights
  const minFee = Math.min(...comparedTutors.map(t => t.monthlyFee));
  const maxExp = Math.max(...comparedTutors.map(t => t.experienceYears));

  return (
    <>
      {/* Sticky Bottom Summary Bar when 1+ tutors are in comparison */}
      {!isOpen && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-[#174C3C] text-[#F8F6EF] px-5 py-3 rounded-2xl shadow-xl shadow-[#174C3C]/25 border border-[#A8B9A0]/50 flex items-center space-x-4 animate-slide-up backdrop-blur-md">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#E6BD68] text-[#174C3C] flex items-center justify-center font-bold text-xs shadow-xs">
              {comparedTutors.length}/3
            </div>
            <div>
              <p className="text-xs font-serif font-bold text-white">Comparing Tutors</p>
              <p className="text-[10px] text-[#A8B9A0]">
                {comparedTutors.map(t => t.name.split(' ')[0]).join(', ')}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onOpen}
              className="px-3.5 py-1.5 bg-[#D87952] hover:bg-[#BD603B] text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center space-x-1 cursor-pointer"
            >
              <span>View Table</span>
              <Maximize2 className="w-3.5 h-3.5 ml-1" />
            </button>
            <button
              onClick={onClear}
              title="Clear all"
              className="p-1.5 text-[#A8B9A0] hover:text-[#FAECE5] rounded-lg hover:bg-white/10 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Full Modal Comparison View */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242B27]/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
          <div 
            className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl border border-[#E8E4D5] overflow-hidden my-6 max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="bg-[#174C3C] p-5 text-[#F8F6EF] flex items-center justify-between border-b border-[#0F3328]">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center text-[#E6BD68]">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-serif font-black text-white">Side-by-Side Tutor Comparison</h3>
                  <p className="text-xs text-[#A8B9A0]">Comparing {comparedTutors.length} of max 3 demonstration profiles</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <button
                  onClick={onClear}
                  className="text-xs text-[#E6BD68] hover:text-white font-bold px-2 py-1 rounded hover:bg-white/10 flex items-center space-x-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear All</span>
                </button>
                <button
                  onClick={onClose}
                  className="p-2 text-[#A8B9A0] hover:text-white rounded-xl hover:bg-white/10 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Comparison Table Content */}
            <div className="overflow-x-auto p-6 flex-1 bg-white">
              <table className="w-full border-collapse text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-[#E8E4D5]">
                    <th className="p-3 font-bold text-[#737D74] uppercase text-[11px] w-40">Features</th>
                    {comparedTutors.map((tutor) => (
                      <th key={tutor.id} className="p-3 w-64 align-top">
                        <div className="bg-[#F8F6EF] p-4 rounded-2xl border border-[#E8E4D5] relative">
                          <button
                            onClick={() => onRemove(tutor.id)}
                            className="absolute top-2 right-2 p-1 text-[#737D74] hover:text-[#D87952] hover:bg-white rounded-lg cursor-pointer"
                            title="Remove from comparison"
                          >
                            <X className="w-4 h-4" />
                          </button>
                          
                          <img
                            src={tutor.avatar}
                            alt={tutor.name}
                            className="w-14 h-14 rounded-2xl object-cover mb-2.5 border border-[#E8E4D5]"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(tutor.name)}&background=174C3C&color=F8F6EF&size=128`;
                            }}
                          />
                          <h4 className="font-serif font-bold text-[#242B27] text-base">{tutor.name}</h4>
                          <p className="text-xs text-[#737D74] line-clamp-1">{tutor.qualification}</p>
                          
                          <button
                            onClick={() => {
                              onClose();
                              onContact(tutor);
                            }}
                            className="mt-3 w-full py-2 px-3 bg-[#174C3C] hover:bg-[#0F3328] text-[#F8F6EF] font-bold rounded-xl text-xs flex items-center justify-center space-x-1 shadow-xs cursor-pointer"
                          >
                            <Send className="w-3 h-3 text-[#E6BD68]" />
                            <span>Send Enquiry</span>
                          </button>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F2EFE5]">
                  
                  {/* Monthly Fee */}
                  <tr>
                    <td className="p-3 font-bold text-[#242B27] bg-[#FDFCF7]">Monthly Fee</td>
                    {comparedTutors.map((tutor) => (
                      <td key={tutor.id} className="p-3">
                        <div className="flex items-center space-x-2">
                          <span className="text-base font-serif font-bold text-[#174C3C]">
                            ₹{tutor.monthlyFee.toLocaleString('en-IN')}
                          </span>
                          <span className="text-xs text-[#737D74]">/mo</span>
                          {tutor.monthlyFee === minFee && comparedTutors.length > 1 && (
                            <span className="text-[10px] bg-[#E8EFE5] text-[#174C3C] font-bold px-2 py-0.5 rounded-full border border-[#A8B9A0]/50 flex items-center space-x-1">
                              <Award className="w-3 h-3 text-[#D87952]" />
                              <span>Lowest Fee</span>
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-[#737D74] mt-0.5">~₹{tutor.sessionFee} / session</p>
                      </td>
                    ))}
                  </tr>

                  {/* Experience */}
                  <tr>
                    <td className="p-3 font-bold text-[#242B27] bg-[#FDFCF7]">Experience</td>
                    {comparedTutors.map((tutor) => (
                      <td key={tutor.id} className="p-3">
                        <div className="flex items-center space-x-1.5">
                          <span className="font-bold text-[#242B27]">{tutor.experienceYears} Years</span>
                          {tutor.experienceYears === maxExp && comparedTutors.length > 1 && (
                            <span className="text-[10px] bg-[#FAF5E8] text-[#7A5813] font-bold px-2 py-0.5 rounded-full border border-[#EADFC7]">
                              Most Experienced
                            </span>
                          )}
                        </div>
                      </td>
                    ))}
                  </tr>

                  {/* Teaching Mode */}
                  <tr>
                    <td className="p-3 font-bold text-[#242B27] bg-[#FDFCF7]">Teaching Mode</td>
                    {comparedTutors.map((tutor) => (
                      <td key={tutor.id} className="p-3">
                        <span className={`inline-block px-2.5 py-1 rounded-lg text-xs font-semibold ${
                          tutor.teachingMode.includes('Home') ? 'bg-[#E8EFE5] text-[#174C3C] border border-[#A8B9A0]/40' : 'bg-[#FAECE5] text-[#D87952] border border-[#D87952]/30'
                        }`}>
                          {tutor.teachingMode}
                        </span>
                      </td>
                    ))}
                  </tr>

                  {/* Locality & City */}
                  <tr>
                    <td className="p-3 font-bold text-[#242B27] bg-[#FDFCF7]">Locality</td>
                    {comparedTutors.map((tutor) => (
                      <td key={tutor.id} className="p-3">
                        <div className="flex items-center space-x-1 text-[#242B27] font-medium">
                          <MapPin className="w-3.5 h-3.5 text-[#D87952]" />
                          <span>{tutor.locality}, {tutor.city}</span>
                        </div>
                      </td>
                    ))}
                  </tr>

                  {/* Subjects Covered */}
                  <tr>
                    <td className="p-3 font-bold text-[#242B27] bg-[#FDFCF7]">Subjects</td>
                    {comparedTutors.map((tutor) => (
                      <td key={tutor.id} className="p-3">
                        <div className="flex flex-wrap gap-1">
                          {tutor.subjects.map((sub, i) => (
                            <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-[#F8F6EF] text-[#174C3C] border border-[#E8E4D5]">
                              {sub}
                            </span>
                          ))}
                        </div>
                      </td>
                    ))}
                  </tr>

                  {/* Classes & Curricula */}
                  <tr>
                    <td className="p-3 font-bold text-[#242B27] bg-[#FDFCF7]">Classes Handled</td>
                    {comparedTutors.map((tutor) => (
                      <td key={tutor.id} className="p-3 text-xs text-[#242B27]">
                        {tutor.classes.join(', ')}
                      </td>
                    ))}
                  </tr>

                  {/* Availability */}
                  <tr>
                    <td className="p-3 font-bold text-[#242B27] bg-[#FDFCF7]">Weekly Schedule</td>
                    {comparedTutors.map((tutor) => (
                      <td key={tutor.id} className="p-3 text-xs text-[#737D74]">
                        <Clock className="w-3.5 h-3.5 inline mr-1 text-[#A8B9A0]" />
                        {tutor.availability}
                      </td>
                    ))}
                  </tr>

                  {/* Languages Spoken */}
                  <tr>
                    <td className="p-3 font-bold text-[#242B27] bg-[#FDFCF7]">Languages</td>
                    {comparedTutors.map((tutor) => (
                      <td key={tutor.id} className="p-3 text-xs text-[#242B27]">
                        {tutor.languages.join(', ')}
                      </td>
                    ))}
                  </tr>

                </tbody>
              </table>
            </div>

            {/* Footer */}
            <div className="p-4 bg-[#F8F6EF] border-t border-[#E8E4D5] flex justify-end">
              <button
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-[#174C3C] hover:bg-[#0F3328] text-[#F8F6EF] font-bold text-xs transition-colors cursor-pointer"
              >
                Done Comparing
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
