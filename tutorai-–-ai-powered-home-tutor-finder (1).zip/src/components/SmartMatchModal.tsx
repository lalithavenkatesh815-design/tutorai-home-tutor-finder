import React, { useState } from 'react';
import { 
  Sparkles, 
  X, 
  CheckCircle2, 
  ArrowRight, 
  Send, 
  MapPin,
  Bot
} from 'lucide-react';
import { ALL_SUBJECTS, ALL_CLASSES, ALL_LOCALITIES } from '../data/tutors';
import { SmartMatchCriteria, MatchResult, Tutor } from '../types/tutor';
import { matchTutorsWithAI } from '../services/geminiService';

interface SmartMatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onViewTutor: (tutor: Tutor) => void;
  onContactTutor: (tutor: Tutor) => void;
}

export const SmartMatchModal: React.FC<SmartMatchModalProps> = ({
  isOpen,
  onClose,
  onViewTutor,
  onContactTutor,
}) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [criteria, setCriteria] = useState<SmartMatchCriteria>({
    studentClass: 'Class 10',
    subject: 'Mathematics',
    locality: 'Koramangala (Bengaluru)',
    budget: 4500,
    teachingMode: 'Hybrid (Home + Online)',
    learningGoals: 'Needs concept clarity for board examinations and regular doubt solving',
    schedulePreference: 'Evening (4 PM - 8 PM)'
  });

  const [loading, setLoading] = useState(false);
  const [matchResults, setMatchResults] = useState<MatchResult[]>([]);
  const [resultSource, setResultSource] = useState<'gemini' | 'rule-fallback'>('rule-fallback');

  if (!isOpen) return null;

  const handleRunMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { results, source } = await matchTutorsWithAI(criteria);
      setMatchResults(results);
      setResultSource(source);
      setStep(2);
    } catch {
      // Handled in service
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setStep(1);
    setMatchResults([]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242B27]/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-[#E8E4D5] overflow-hidden my-6 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header - Forest Green */}
        <div className="bg-[#174C3C] p-6 text-[#F8F6EF] flex items-center justify-between border-b border-[#0F3328]">
          <div className="flex items-center space-x-3.5">
            <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center shadow-xs">
              <Sparkles className="w-6 h-6 text-[#E6BD68]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-serif font-black text-white">AI Smart Tutor Matcher</h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E6BD68]/20 text-[#E6BD68] border border-[#E6BD68]/30">
                  Powered by Gemini
                </span>
              </div>
              <p className="text-xs text-[#A8B9A0]">Intelligent compatibility matching across 40 curated demonstration profiles</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#A8B9A0] hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 bg-white">
          
          {step === 1 ? (
            /* STEP 1: Questionnaire */
            <form onSubmit={handleRunMatch} className="space-y-6">
              
              <div className="bg-[#F8F6EF] p-4 rounded-2xl border border-[#E8E4D5] flex items-start space-x-3 text-xs text-[#242B27]">
                <Bot className="w-5 h-5 text-[#174C3C] flex-shrink-0 mt-0.5" />
                <span className="leading-relaxed">
                  Tell us your child's specific academic goals, grade, and budget. Our AI matches your exact requirements against real demonstration profiles without inventing false claims.
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Student Class */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                    Student Class / Grade
                  </label>
                  <select
                    value={criteria.studentClass}
                    onChange={(e) => setCriteria({ ...criteria, studentClass: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  >
                    {ALL_CLASSES.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

                {/* Primary Subject */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                    Subject Required
                  </label>
                  <select
                    value={criteria.subject}
                    onChange={(e) => setCriteria({ ...criteria, subject: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  >
                    {ALL_SUBJECTS.map(sub => (
                      <option key={sub} value={sub}>{sub}</option>
                    ))}
                  </select>
                </div>

                {/* Locality */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                    Preferred Locality / Area
                  </label>
                  <select
                    value={criteria.locality}
                    onChange={(e) => setCriteria({ ...criteria, locality: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  >
                    {ALL_LOCALITIES.map(loc => (
                      <option key={loc} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>

                {/* Monthly Budget */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-[#737D74]">
                      Monthly Budget (INR)
                    </label>
                    <span className="text-xs font-bold text-[#D87952] bg-[#FAECE5] px-2.5 py-0.5 rounded-md border border-[#D87952]/30">
                      ₹{criteria.budget.toLocaleString('en-IN')}/mo
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1500"
                    max="8000"
                    step="500"
                    value={criteria.budget}
                    onChange={(e) => setCriteria({ ...criteria, budget: parseInt(e.target.value, 10) })}
                    className="w-full h-2 bg-[#E8E4D5] rounded-lg appearance-none cursor-pointer accent-[#D87952]"
                  />
                  <div className="flex justify-between text-[10px] text-[#737D74] mt-1">
                    <span>₹1,500</span>
                    <span>₹4,500</span>
                    <span>₹8,000</span>
                  </div>
                </div>

                {/* Preferred Teaching Mode */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                    Preferred Teaching Mode
                  </label>
                  <select
                    value={criteria.teachingMode}
                    onChange={(e) => setCriteria({ ...criteria, teachingMode: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  >
                    <option value="Any Mode">Any Mode (Home or Online)</option>
                    <option value="Home Visit Only">Home Visit Only (Tutor visits home)</option>
                    <option value="Online Only">Online Only (1-on-1 via pen tablet)</option>
                    <option value="Hybrid (Home + Online)">Hybrid (Mix of Home and Online)</option>
                  </select>
                </div>

                {/* Preferred Schedule */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                    Preferred Time Slot
                  </label>
                  <select
                    value={criteria.schedulePreference}
                    onChange={(e) => setCriteria({ ...criteria, schedulePreference: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                  >
                    <option value="Evening (4 PM - 8 PM)">Evening (4:00 PM – 8:00 PM)</option>
                    <option value="Afternoon (2 PM - 5 PM)">Afternoon (2:00 PM – 5:00 PM)</option>
                    <option value="Weekend Morning">Weekend Mornings (10:00 AM – 1:00 PM)</option>
                    <option value="Flexible">Flexible / Discuss with Tutor</option>
                  </select>
                </div>

              </div>

              {/* Learning Goals and Weak Topics */}
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-[#737D74] block mb-2">
                  Student's Learning Goals & Specific Difficult Topics
                </label>
                <textarea
                  rows={3}
                  value={criteria.learningGoals}
                  onChange={(e) => setCriteria({ ...criteria, learningGoals: e.target.value })}
                  placeholder="e.g. Struggles with algebra word problems and trigonometry derivations. Needs structured weekly homework accountability."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E4D5] text-xs sm:text-sm focus:outline-none focus:border-[#174C3C] bg-[#FDFCF7]"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-8 py-3 rounded-2xl bg-[#174C3C] hover:bg-[#0F3328] text-[#F8F6EF] font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <Sparkles className="w-4 h-4 animate-spin text-[#E6BD68]" />
                      <span>Analyzing Tutor Compatibility...</span>
                    </>
                  ) : (
                    <>
                      <span>Generate Personalized AI Matches</span>
                      <ArrowRight className="w-4 h-4 text-[#E6BD68]" />
                    </>
                  )}
                </button>
              </div>

            </form>
          ) : (
            /* STEP 2: Recommended Match Results */
            <div className="space-y-6">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-[#F8F6EF] rounded-2xl border border-[#E8E4D5]">
                <div>
                  <h3 className="font-serif font-bold text-[#242B27] text-base">Top 3 Tailored Matches</h3>
                  <p className="text-xs text-[#737D74]">
                    Filtered for {criteria.studentClass} • {criteria.subject} • Budget: ₹{criteria.budget.toLocaleString('en-IN')}/mo
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-[#737D74]">
                    Engine: <strong className="text-[#174C3C]">{resultSource === 'gemini' ? 'Gemini 3.8 Flash' : 'Rule-Based Analyzer'}</strong>
                  </span>
                  <button
                    onClick={handleReset}
                    className="px-3 py-1.5 rounded-xl bg-white border border-[#E8E4D5] text-xs font-bold text-[#242B27] hover:bg-[#F8F6EF] transition-colors cursor-pointer"
                  >
                    Adjust Criteria
                  </button>
                </div>
              </div>

              {/* Cards Grid */}
              <div className="space-y-4">
                {matchResults.map((result, idx) => {
                  const tutor = result.tutor;
                  return (
                    <div 
                      key={tutor.id}
                      className="bg-white rounded-3xl border-2 border-[#E8E4D5] hover:border-[#174C3C] p-5 sm:p-6 shadow-xs hover:shadow-md transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-6"
                    >
                      <div className="flex items-start space-x-4 flex-1">
                        <div className="relative">
                          <img
                            src={tutor.avatar}
                            alt={tutor.name}
                            className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-[#E8EFE5] shadow-xs"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(tutor.name)}&background=174C3C&color=F8F6EF&size=128`;
                            }}
                          />
                          <div className="absolute -top-2 -left-2 w-7 h-7 rounded-full bg-[#174C3C] text-[#E6BD68] font-bold text-xs flex items-center justify-center border-2 border-white shadow">
                            #{idx + 1}
                          </div>
                        </div>

                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <h4 className="font-serif font-bold text-[#242B27] text-lg">{tutor.name}</h4>
                            <span className="px-2.5 py-0.5 rounded-full bg-[#E8EFE5] text-[#174C3C] font-bold text-xs border border-[#A8B9A0]/50">
                              {result.matchScore}% Match
                            </span>
                            <span className="text-xs font-semibold px-2 py-0.5 rounded-lg bg-[#FAF5E8] text-[#7A5813] border border-[#EADFC7]">
                              {tutor.teachingMode}
                            </span>
                          </div>

                          <p className="text-xs text-[#174C3C] font-semibold mt-0.5">{tutor.qualification}</p>

                          <div className="flex items-center space-x-3 text-xs text-[#737D74] mt-1">
                            <span className="font-bold text-[#242B27]">{tutor.experienceYears} Yrs Exp</span>
                            <span>•</span>
                            <span className="flex items-center space-x-1 text-[#242B27]">
                              <MapPin className="w-3.5 h-3.5 text-[#D87952]" />
                              <span>{tutor.locality}</span>
                            </span>
                            <span>•</span>
                            <span className="font-serif font-bold text-[#174C3C] text-sm">₹{tutor.monthlyFee.toLocaleString('en-IN')}/mo</span>
                          </div>

                          {/* Reasons for recommendation */}
                          <div className="mt-3 space-y-1">
                            {result.reasons.map((reason, rIdx) => (
                              <div key={rIdx} className="flex items-start space-x-1.5 text-xs text-[#242B27]">
                                <CheckCircle2 className="w-3.5 h-3.5 text-[#174C3C] flex-shrink-0 mt-0.5" />
                                <span>{reason}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex md:flex-col items-center gap-2 w-full md:w-auto flex-shrink-0">
                        <button
                          onClick={() => {
                            onClose();
                            onViewTutor(tutor);
                          }}
                          className="flex-1 md:flex-initial w-full px-4 py-2 rounded-xl bg-[#F8F6EF] hover:bg-[#EDE9DC] text-[#242B27] font-bold text-xs text-center transition-colors cursor-pointer"
                        >
                          View Profile
                        </button>
                        <button
                          onClick={() => {
                            onClose();
                            onContactTutor(tutor);
                          }}
                          className="flex-1 md:flex-initial w-full px-4 py-2 rounded-xl bg-[#174C3C] hover:bg-[#0F3328] text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow-xs transition-all cursor-pointer"
                        >
                          <Send className="w-3 h-3 text-[#E6BD68]" />
                          <span>Send Enquiry</span>
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
