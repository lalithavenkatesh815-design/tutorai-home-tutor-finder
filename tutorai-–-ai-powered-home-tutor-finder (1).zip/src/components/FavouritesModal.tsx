import React from 'react';
import { X, Heart, Star, MapPin, Trash2, Eye } from 'lucide-react';
import { Tutor } from '../types/tutor';

interface FavouritesModalProps {
  isOpen: boolean;
  onClose: () => void;
  favorites: Tutor[];
  onRemoveFavorite: (tutor: Tutor) => void;
  onClearFavorites: () => void;
  onViewProfile: (tutor: Tutor) => void;
  onContact: (tutor: Tutor) => void;
}

export const FavouritesModal: React.FC<FavouritesModalProps> = ({
  isOpen,
  onClose,
  favorites,
  onRemoveFavorite,
  onClearFavorites,
  onViewProfile,
  onContact,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242B27]/70 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div 
        className="relative w-full max-w-2xl bg-[#FFFFFF] rounded-3xl shadow-2xl border border-[#E5E0D0] overflow-hidden my-6 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="bg-[#174C3C] p-6 text-[#F8F6EF] flex items-center justify-between border-b border-[#242B27]/20">
          <div className="flex items-center space-x-3.5">
            <div className="w-11 h-11 rounded-2xl bg-[#D87952]/20 border border-[#D87952]/40 flex items-center justify-center text-[#D87952]">
              <Heart className="w-5 h-5 fill-[#D87952] text-[#D87952]" />
            </div>
            <div>
              <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-[#FFFFFF]/10 text-[#A8B9A0] text-[10px] font-bold uppercase tracking-wider mb-0.5">
                <span>Personal Shortlist</span>
              </div>
              <h2 className="text-xl font-bold font-serif text-[#F8F6EF]">Saved Tutor Profiles</h2>
              <p className="text-xs text-[#A8B9A0]">
                {favorites.length} {favorites.length === 1 ? 'tutor' : 'tutors'} saved for direct evaluation
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {favorites.length > 0 && (
              <button
                onClick={onClearFavorites}
                className="text-xs text-[#E6BD68] hover:text-[#FFFFFF] font-semibold px-2.5 py-1 rounded-lg hover:bg-[#FFFFFF]/10 transition-colors"
              >
                Clear All
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 text-[#A8B9A0] hover:text-[#F8F6EF] rounded-xl hover:bg-[#FFFFFF]/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3 bg-[#FDFCF7]">
          {favorites.length === 0 ? (
            <div className="text-center py-14 space-y-3 text-[#737D74]">
              <div className="w-16 h-16 rounded-full bg-[#E5E0D0]/50 text-[#737D74] mx-auto flex items-center justify-center">
                <Heart className="w-8 h-8 stroke-[1.5]" />
              </div>
              <h3 className="font-serif font-bold text-[#242B27] text-lg">No Saved Tutors Yet</h3>
              <p className="text-xs max-w-sm mx-auto leading-relaxed text-[#737D74]">
                Tap the heart icon on any tutor profile card to bookmark them for easy side-by-side comparison or demo enquiry.
              </p>
            </div>
          ) : (
            favorites.map((tutor) => (
              <div
                key={tutor.id}
                className="p-4 rounded-2xl bg-[#FFFFFF] border border-[#E5E0D0] hover:border-[#174C3C]/40 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm"
              >
                <div className="flex items-start space-x-3.5">
                  <img
                    src={tutor.avatar}
                    alt={tutor.name}
                    className="w-14 h-14 rounded-2xl object-cover border border-[#E5E0D0]"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(tutor.name)}&background=174C3C&color=F8F6EF&size=128`;
                    }}
                  />
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-bold text-[#174C3C] bg-[#174C3C]/10 px-2 py-0.5 rounded-full">
                        {tutor.category}
                      </span>
                      <span className="text-xs font-bold text-[#E6BD68] flex items-center space-x-0.5">
                        <Star className="w-3.5 h-3.5 fill-[#E6BD68]" />
                        <span>{tutor.rating}</span>
                      </span>
                    </div>
                    <h4 className="font-serif font-bold text-[#242B27] text-base mt-0.5">{tutor.name}</h4>
                    <p className="text-xs text-[#737D74]">{tutor.qualification}</p>
                    <div className="flex items-center space-x-2 mt-1 text-xs text-[#737D74]">
                      <span className="font-bold text-[#174C3C]">₹{tutor.monthlyFee.toLocaleString('en-IN')}/mo</span>
                      <span>•</span>
                      <span>{tutor.locality}, {tutor.city}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2 self-end sm:self-center">
                  <button
                    onClick={() => {
                      onClose();
                      onViewProfile(tutor);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-[#FFFFFF] border border-[#E5E0D0] text-[#242B27] hover:bg-[#F8F6EF] text-xs font-bold transition-colors cursor-pointer"
                  >
                    View
                  </button>
                  <button
                    onClick={() => {
                      onClose();
                      onContact(tutor);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#D87952] hover:bg-[#c46944] text-[#FFFFFF] text-xs font-bold shadow-sm transition-colors cursor-pointer"
                  >
                    Enquire
                  </button>
                  <button
                    onClick={() => onRemoveFavorite(tutor)}
                    title="Remove from favorites"
                    className="p-2 text-[#737D74] hover:text-[#D87952] hover:bg-[#E5E0D0]/50 rounded-xl transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
