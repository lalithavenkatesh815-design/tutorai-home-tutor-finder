import React, { useState } from 'react';
import { Calculator, ArrowRight, Info, Check } from 'lucide-react';

interface FeeCalculatorProps {
  onFindTutorsInBudget?: (maxBudget: number) => void;
}

export const FeeCalculator: React.FC<FeeCalculatorProps> = ({ onFindTutorsInBudget }) => {
  const [subjectsCount, setSubjectsCount] = useState<number>(2);
  const [sessionsPerWeek, setSessionsPerWeek] = useState<number>(3);
  const [feePerSession, setFeePerSession] = useState<number>(350);
  const [studentsCount, setStudentsCount] = useState<number>(1);
  const [hasSiblingDiscount, setHasSiblingDiscount] = useState<boolean>(true);

  // Formula: Weekly sessions * fee per session * 4.33
  const baseMonthlyPerStudent = Math.round(sessionsPerWeek * feePerSession * 4.33);
  const totalMonthly = studentsCount === 1 
    ? baseMonthlyPerStudent 
    : Math.round(baseMonthlyPerStudent + (hasSiblingDiscount ? baseMonthlyPerStudent * 0.8 : baseMonthlyPerStudent));

  const totalWeekly = sessionsPerWeek * feePerSession * studentsCount;
  const annualEstimate = totalMonthly * 10; // 10 academic months

  const applyPreset = (preset: 'homework' | 'board' | 'foundation') => {
    if (preset === 'homework') {
      setSubjectsCount(1);
      setSessionsPerWeek(3);
      setFeePerSession(250);
      setStudentsCount(1);
    } else if (preset === 'board') {
      setSubjectsCount(2);
      setSessionsPerWeek(4);
      setFeePerSession(400);
      setStudentsCount(1);
    } else if (preset === 'foundation') {
      setSubjectsCount(3);
      setSessionsPerWeek(5);
      setFeePerSession(550);
      setStudentsCount(1);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-[#E8E4D5] shadow-[0_8px_30px_rgba(23,76,60,0.06)] overflow-hidden">
      
      {/* Header - Deep Forest Green */}
      <div className="bg-[#174C3C] p-6 sm:p-8 text-[#F8F6EF]">
        <div className="max-w-3xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 text-[#E6BD68] border border-white/15 text-xs font-bold mb-3">
            <Calculator className="w-3.5 h-3.5 text-[#E6BD68]" />
            <span>Transparent Tuition Estimator</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-black text-white">Smart Home Tuition Fee Calculator</h2>
          <p className="text-xs sm:text-sm text-[#A8B9A0] mt-2 leading-relaxed">
            Estimate your monthly home tuition investment transparently using Indian tutoring standards (formula: <code className="bg-[#0F3328] px-2 py-0.5 rounded text-[#E6BD68] font-mono">weekly sessions × fee/session × 4.33</code>).
          </p>
        </div>

        {/* Quick Presets */}
        <div className="mt-5 flex flex-wrap gap-2">
          <span className="text-xs font-bold text-[#A8B9A0] self-center mr-1">Quick Scenarios:</span>
          <button
            onClick={() => applyPreset('homework')}
            className="px-3 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white border border-white/15 transition-colors cursor-pointer"
          >
            Regular Homework (3x/wk @ ₹250)
          </button>
          <button
            onClick={() => applyPreset('board')}
            className="px-3 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white border border-white/15 transition-colors cursor-pointer"
          >
            Class 10/12 Board Exam (4x/wk @ ₹400)
          </button>
          <button
            onClick={() => applyPreset('foundation')}
            className="px-3 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white border border-white/15 transition-colors cursor-pointer"
          >
            IIT/NEET Foundation (5x/wk @ ₹550)
          </button>
        </div>
      </div>

      {/* Main Body: Sliders on Left, Live Breakdown on Right */}
      <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 bg-white">
        
        {/* Controls Column (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Number of Subjects */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-bold text-[#242B27]">Number of Subjects</label>
              <span className="text-xs font-bold text-[#174C3C] px-2.5 py-0.5 rounded-lg bg-[#E8EFE5] border border-[#A8B9A0]/40">
                {subjectsCount} {subjectsCount === 1 ? 'Subject' : 'Subjects'}
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="5"
              step="1"
              value={subjectsCount}
              onChange={(e) => setSubjectsCount(parseInt(e.target.value, 10))}
              className="w-full h-2 bg-[#E8E4D5] rounded-lg appearance-none cursor-pointer accent-[#174C3C]"
            />
            <div className="flex justify-between text-[11px] text-[#737D74] mt-1">
              <span>1 (Single Subject)</span>
              <span>3 (Science & Math)</span>
              <span>5 (All Core Subjects)</span>
            </div>
          </div>

          {/* Sessions per Week */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-bold text-[#242B27]">Sessions per Week</label>
              <span className="text-xs font-bold text-[#174C3C] px-2.5 py-0.5 rounded-lg bg-[#E8EFE5] border border-[#A8B9A0]/40">
                {sessionsPerWeek} Days / Week
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="6"
              step="1"
              value={sessionsPerWeek}
              onChange={(e) => setSessionsPerWeek(parseInt(e.target.value, 10))}
              className="w-full h-2 bg-[#E8E4D5] rounded-lg appearance-none cursor-pointer accent-[#174C3C]"
            />
            <div className="flex justify-between text-[11px] text-[#737D74] mt-1">
              <span>1 Session (Weekend)</span>
              <span>3 Sessions (Alt Days)</span>
              <span>6 Sessions (Mon–Sat)</span>
            </div>
          </div>

          {/* Fee per Session in INR */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-bold text-[#242B27]">Approximate Fee per Session (INR)</label>
              <span className="text-xs font-bold text-[#D87952] px-2.5 py-0.5 rounded-lg bg-[#FAECE5] border border-[#D87952]/30">
                ₹{feePerSession} / session (1 hour)
              </span>
            </div>
            <input
              type="range"
              min="150"
              max="1000"
              step="50"
              value={feePerSession}
              onChange={(e) => setFeePerSession(parseInt(e.target.value, 10))}
              className="w-full h-2 bg-[#E8E4D5] rounded-lg appearance-none cursor-pointer accent-[#D87952]"
            />
            <div className="flex justify-between text-[11px] text-[#737D74] mt-1">
              <span>₹150 (Primary School)</span>
              <span>₹350 (Class 10 Board)</span>
              <span>₹1,000 (Senior Faculty)</span>
            </div>
          </div>

          {/* Number of Students */}
          <div className="pt-2 border-t border-[#F2EFE5] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <label className="text-sm font-bold text-[#242B27] block">Number of Students</label>
              <p className="text-xs text-[#737D74]">Are siblings learning together in the same session?</p>
            </div>
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={() => setStudentsCount(1)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  studentsCount === 1
                    ? 'bg-[#174C3C] text-white shadow-xs'
                    : 'bg-[#F8F6EF] text-[#242B27] hover:bg-[#EDE9DC]'
                }`}
              >
                1 Student
              </button>
              <button
                type="button"
                onClick={() => setStudentsCount(2)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  studentsCount === 2
                    ? 'bg-[#174C3C] text-white shadow-xs'
                    : 'bg-[#F8F6EF] text-[#242B27] hover:bg-[#EDE9DC]'
                }`}
              >
                2 Siblings
              </button>
            </div>
          </div>

          {studentsCount === 2 && (
            <div className="p-3.5 bg-[#E8EFE5] rounded-2xl border border-[#A8B9A0]/60 flex items-center justify-between">
              <span className="text-xs font-bold text-[#174C3C]">Apply standard 20% sibling discount on 2nd child?</span>
              <input
                type="checkbox"
                checked={hasSiblingDiscount}
                onChange={(e) => setHasSiblingDiscount(e.target.checked)}
                className="w-4 h-4 accent-[#174C3C] cursor-pointer"
              />
            </div>
          )}

        </div>

        {/* Live Expense Breakdown Card (5 cols) */}
        <div className="lg:col-span-5 bg-[#F8F6EF] text-[#242B27] border border-[#E8E4D5] rounded-3xl p-6 sm:p-7 flex flex-col justify-between shadow-xs">
          <div>
            <div className="flex items-center justify-between border-b border-[#E8E4D5] pb-4">
              <span className="text-xs uppercase font-bold tracking-wider text-[#737D74]">Estimated Budget</span>
              <span className="text-[11px] font-bold text-[#174C3C] bg-[#E8EFE5] px-2.5 py-0.5 rounded-full border border-[#A8B9A0]/50">
                INR Calculation
              </span>
            </div>

            <div className="mt-6">
              <span className="text-xs text-[#737D74] block">Total Monthly Tuition Estimate</span>
              <div className="flex items-baseline space-x-2 mt-1">
                <span className="text-4xl sm:text-5xl font-serif font-black text-[#174C3C]">₹{totalMonthly.toLocaleString('en-IN')}</span>
                <span className="text-xs text-[#737D74]">/ month</span>
              </div>
            </div>

            <div className="mt-6 space-y-3 pt-6 border-t border-[#E8E4D5] text-xs">
              <div className="flex justify-between text-[#737D74]">
                <span>Weekly Expense ({sessionsPerWeek} sessions):</span>
                <span className="font-bold text-[#242B27]">₹{totalWeekly.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-[#737D74]">
                <span>Total Monthly Hours:</span>
                <span className="font-bold text-[#242B27]">~{(sessionsPerWeek * 4.33).toFixed(1)} hrs</span>
              </div>
              <div className="flex justify-between text-[#737D74]">
                <span>Approximate 10-Month Academic Year:</span>
                <span className="font-bold text-[#242B27]">₹{annualEstimate.toLocaleString('en-IN')}</span>
              </div>
              {studentsCount === 2 && hasSiblingDiscount && (
                <div className="flex justify-between text-[#174C3C] font-semibold">
                  <span>Sibling Discount Applied:</span>
                  <span>-20% on 2nd Student</span>
                </div>
              )}
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-[#E8E4D5]">
            <div className="flex items-start space-x-2 text-[11px] text-[#737D74] mb-4">
              <Info className="w-4 h-4 text-[#D87952] flex-shrink-0 mt-0.5" />
              <span>
                Note: Actual fees are determined directly between parents and individual tutors based on travel distance and board requirements.
              </span>
            </div>

            {onFindTutorsInBudget && (
              <button
                onClick={() => onFindTutorsInBudget(totalMonthly)}
                className="w-full py-3 bg-[#174C3C] hover:bg-[#0F3328] text-[#F8F6EF] font-bold rounded-xl text-xs sm:text-sm flex items-center justify-center space-x-2 shadow-md transition-all cursor-pointer"
              >
                <span>Find Tutors Within ₹{totalMonthly.toLocaleString('en-IN')}</span>
                <ArrowRight className="w-4 h-4 text-[#E6BD68]" />
              </button>
            )}
          </div>

        </div>

      </div>

    </div>
  );
};
