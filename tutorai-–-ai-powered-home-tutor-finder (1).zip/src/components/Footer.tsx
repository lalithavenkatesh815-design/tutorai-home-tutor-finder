import React from 'react';
import { GraduationCap, ShieldAlert, Sparkles, Heart, Mail, MapPin, ArrowRight } from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string) => void;
  onOpenChat: () => void;
  onBecomeTutor: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenChat,
  onBecomeTutor,
}) => {
  return (
    <footer className="bg-[#174C3C] text-[#F8F6EF] pt-16 pb-12 border-t border-[#12382c]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Problem Statement Banner (Editorial Style) */}
        <div className="p-7 sm:p-8 rounded-3xl bg-[#FFFFFF] text-[#242B27] shadow-xl border border-[#E5E0D0] mb-14 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="max-w-3xl space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#174C3C]/10 text-[#174C3C] text-[10px] font-bold uppercase tracking-wider">
              <span>Academic Problem Statement</span>
            </div>
            <h4 className="text-xl sm:text-2xl font-serif font-bold text-[#242B27]">
              Solving the Home Tutor Discovery Challenge for Parents
            </h4>
            <p className="text-xs sm:text-sm text-[#737D74] leading-relaxed">
              Parents struggle to discover verified, reliable home tutors nearby with transparent fee structures. TutorAI bridges this challenge through structured subject categories, locality maps, transparent fees, and server-side Gemini AI guidance without registration barriers.
            </p>
          </div>

          <button
            onClick={() => onNavigate('directory')}
            className="px-6 py-3 rounded-xl bg-[#D87952] hover:bg-[#c46944] text-[#FFFFFF] font-bold text-xs sm:text-sm whitespace-nowrap shadow-md transition-all flex items-center space-x-2 cursor-pointer"
          >
            <span>Explore 40+ Tutors</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 4 Column Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-[#FFFFFF]/15">
          
          {/* Brand info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-[#E6BD68] flex items-center justify-center text-[#174C3C] shadow-sm">
                <GraduationCap className="w-6 h-6 stroke-[2.2]" />
              </div>
              <span className="text-2xl font-serif font-bold tracking-tight text-[#F8F6EF]">
                Tutor<span className="text-[#E6BD68]">AI</span>
              </span>
            </div>
            
            <p className="text-xs text-[#A8B9A0] leading-relaxed">
              Find Your Perfect Tutor. Learn Smarter With AI. A modern, database-free Indian edtech discovery platform powered by Google Gemini and OpenStreetMap.
            </p>

            <div className="pt-2 text-[11px] text-[#A8B9A0]/80 space-y-1">
              <p>Architecture: Static Client + Serverless Proxy</p>
              <p>Locality Focus: Karnataka & Metro Indian Cities</p>
              <p>Database: 100% Client LocalStorage (Zero external DB)</p>
            </div>
          </div>

          {/* Quick Platform Links */}
          <div>
            <h5 className="text-xs uppercase font-extrabold tracking-wider text-[#E6BD68] mb-4">Core Modules</h5>
            <ul className="space-y-2.5 text-xs text-[#A8B9A0]">
              <li>
                <button onClick={() => onNavigate('directory')} className="hover:text-[#F8F6EF] transition-colors cursor-pointer text-left">
                  Find Tutors Directory (40 Profiles)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('smart-match')} className="hover:text-[#F8F6EF] transition-colors cursor-pointer text-left">
                  AI Smart Match Diagnostic
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('study-planner')} className="hover:text-[#F8F6EF] transition-colors cursor-pointer text-left">
                  AI Study Routine Timetable
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('calculator')} className="hover:text-[#F8F6EF] transition-colors cursor-pointer text-left">
                  Monthly Tuition Fee Calculator
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('map')} className="hover:text-[#F8F6EF] transition-colors cursor-pointer text-left">
                  OpenStreetMap Locality Explorer
                </button>
              </li>
            </ul>
          </div>

          {/* AI Capabilities & Tools */}
          <div>
            <h5 className="text-xs uppercase font-extrabold tracking-wider text-[#E6BD68] mb-4">Intelligent Features</h5>
            <ul className="space-y-2.5 text-xs text-[#A8B9A0]">
              <li>
                <button onClick={onOpenChat} className="hover:text-[#F8F6EF] transition-colors flex items-center space-x-1.5 cursor-pointer text-left">
                  <Sparkles className="w-3.5 h-3.5 text-[#E6BD68]" />
                  <span>Ask TutorChat AI Assistant</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('directory')} className="hover:text-[#F8F6EF] transition-colors cursor-pointer text-left">
                  Voice Speech Recognition Search
                </button>
              </li>
              <li>
                <button onClick={onOpenChat} className="hover:text-[#F8F6EF] transition-colors cursor-pointer text-left">
                  AI Speech Synthesis Read-Aloud
                </button>
              </li>
              <li>
                <button onClick={onBecomeTutor} className="hover:text-[#F8F6EF] transition-colors cursor-pointer text-left text-[#E6BD68] font-bold">
                  Become a Home Tutor Application
                </button>
              </li>
            </ul>
          </div>

          {/* Academic Project Notice */}
          <div className="space-y-3">
            <h5 className="text-xs uppercase font-extrabold tracking-wider text-[#E6BD68] flex items-center space-x-1.5">
              <ShieldAlert className="w-4 h-4 text-[#D87952]" />
              <span>Demonstration Notice</span>
            </h5>
            <p className="text-xs text-[#A8B9A0] leading-relaxed bg-[#FFFFFF]/5 p-4 rounded-2xl border border-[#FFFFFF]/10">
              All educator profiles, contact numbers, and reviews displayed on this platform are sample demonstration records created for academic showcase purposes. No actual financial transactions or payment cards are processed.
            </p>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#A8B9A0] gap-4">
          <p>© {new Date().getFullYear()} TutorAI Home Tutor Finder. Designed for parents & home educators across India.</p>
          <div className="flex items-center space-x-4">
            <span className="text-[#E6BD68] font-semibold">● Rule Fallback Active</span>
            <span className="text-[#A8B9A0] font-semibold">● Zero Login Required</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
