import React, { useEffect, useRef, useState } from 'react';
import { MapPin, Navigation, ExternalLink, Star, Briefcase, Send, Info, Eye } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import { DEMO_TUTORS, ALL_LOCALITIES } from '../data/tutors';
import { Tutor } from '../types/tutor';

interface MapExplorerProps {
  onSelectTutor: (tutor: Tutor) => void;
  onContactTutor: (tutor: Tutor) => void;
  preSelectedTutor?: Tutor | null;
}

export const MapExplorer: React.FC<MapExplorerProps> = ({
  onSelectTutor,
  onContactTutor,
  preSelectedTutor,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<{ [id: string]: any }>({});
  
  const [selectedLocality, setSelectedLocality] = useState<string>('All');
  const [activeTutor, setActiveTutor] = useState<Tutor | null>(preSelectedTutor || DEMO_TUTORS[0]);
  const [mapLoadError, setMapLoadError] = useState(false);

  // Filter tutors based on locality filter
  const displayedTutors = selectedLocality === 'All'
    ? DEMO_TUTORS
    : DEMO_TUTORS.filter(t => t.locality.toLowerCase().includes(selectedLocality.toLowerCase().split(' ')[0]) || t.city.toLowerCase().includes(selectedLocality.toLowerCase()));

  // Initialize Leaflet Map safely
  useEffect(() => {
    let isMounted = true;

    async function initMap() {
      if (!mapContainerRef.current) return;

      try {
        const leafletModule: any = await import('leaflet');
        const L = leafletModule.default || leafletModule;

        if (!isMounted || !mapContainerRef.current) return;

        // Clean up previous instance or container ID if already present
        if (mapInstanceRef.current) {
          mapInstanceRef.current.remove();
          mapInstanceRef.current = null;
        }
        if ((mapContainerRef.current as any)._leaflet_id) {
          (mapContainerRef.current as any)._leaflet_id = null;
        }

        // Center on Vijayapura, Dharwad, or preselected tutor coordinates
        const initialCoords = preSelectedTutor?.coordinates || [15.4589, 75.0078];
        const initialZoom = preSelectedTutor ? 13 : 8;

        const map = L.map(mapContainerRef.current, {
          center: initialCoords,
          zoom: initialZoom,
          scrollWheelZoom: false,
        });

        if (!isMounted) {
          map.remove();
          return;
        }

        // OpenStreetMap standard tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
          maxZoom: 18,
        }).addTo(map);

        mapInstanceRef.current = map;

        // Custom Pin Icon in Deep Forest Green with Golden Cap
        const customIcon = L.divIcon({
          className: 'custom-tutor-pin',
          html: `<div style="background-color: #174C3C; color: #E6BD68; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(23,76,60,0.35); border: 2.5px solid #F8F6EF; cursor: pointer;">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
                </div>`,
          iconSize: [34, 34],
          iconAnchor: [17, 34],
          popupAnchor: [0, -34],
        });

        markersRef.current = {};
        DEMO_TUTORS.forEach((tutor) => {
          const marker = L.marker(tutor.coordinates, { icon: customIcon }).addTo(map);
          marker.on('click', () => {
            setActiveTutor(tutor);
          });
          markersRef.current[tutor.id] = marker;
        });

        if (preSelectedTutor) {
          setActiveTutor(preSelectedTutor);
          map.setView(preSelectedTutor.coordinates, 13);
        }
      } catch (err) {
        console.warn('Leaflet map notice:', err);
        if (isMounted) setMapLoadError(true);
      }
    }

    initMap();

    return () => {
      isMounted = false;
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
      if (mapContainerRef.current && (mapContainerRef.current as any)._leaflet_id) {
        (mapContainerRef.current as any)._leaflet_id = null;
      }
    };
  }, [preSelectedTutor]);

  useEffect(() => {
    if (activeTutor && mapInstanceRef.current) {
      try {
        mapInstanceRef.current.flyTo(activeTutor.coordinates, 13, { duration: 1 });
      } catch {
        // ignore
      }
    }
  }, [activeTutor]);

  return (
    <div className="bg-white rounded-3xl border border-[#E8E4D5] shadow-[0_8px_30px_rgba(23,76,60,0.06)] overflow-hidden">
      
      {/* Header - Forest Green */}
      <div className="bg-[#174C3C] p-6 sm:p-8 text-[#F8F6EF]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 text-[#E6BD68] border border-white/15 text-xs font-bold mb-3">
              <MapPin className="w-3.5 h-3.5 text-[#D87952]" />
              <span>OpenStreetMap Locality Explorer</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-black text-white">Explore Home Tutors by Locality</h2>
            <p className="text-xs sm:text-sm text-[#A8B9A0] mt-1 max-w-2xl">
              Pinpoint demonstration tutor hubs across Vijayapura, Mysuru, Hubballi, Dharwad, Bengaluru, and other major cities.
            </p>
          </div>

          <div className="bg-white/10 p-3.5 rounded-2xl border border-white/15 text-xs text-[#F8F6EF] max-w-xs">
            <span className="font-bold text-[#E6BD68] block mb-0.5">Privacy First</span>
            No private residential addresses are shown. Markers reflect general neighborhood teaching hubs.
          </div>
        </div>

        {/* Locality Quick Selector Pills */}
        <div className="mt-6 flex items-center space-x-2 overflow-x-auto pb-1 no-scrollbar">
          <button
            onClick={() => setSelectedLocality('All')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              selectedLocality === 'All'
                ? 'bg-[#E6BD68] text-[#174C3C] shadow-xs'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            All Localities ({DEMO_TUTORS.length})
          </button>
          {ALL_LOCALITIES.map((loc) => {
            const shortName = loc.split(' (')[0];
            const isSel = selectedLocality === shortName;
            return (
              <button
                key={loc}
                onClick={() => setSelectedLocality(shortName)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  isSel
                    ? 'bg-[#E6BD68] text-[#174C3C] shadow-xs'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                {loc}
              </button>
            );
          })}
        </div>
      </div>

      {/* Map Layout: Left Map (7 cols), Right Active Tutor Focus (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[500px]">
        
        {/* Map View or Fallback Cards */}
        <div className="lg:col-span-7 relative min-h-[360px] lg:min-h-[520px] bg-[#F8F6EF] border-r border-[#E8E4D5]">
          {!mapLoadError ? (
            <div ref={mapContainerRef} className="w-full h-full min-h-[380px] lg:min-h-[520px] z-10" />
          ) : (
            <div className="p-8 h-full flex flex-col justify-center items-center text-center bg-[#F8F6EF]">
              <Navigation className="w-12 h-12 text-[#174C3C] mb-3 animate-pulse" />
              <h3 className="text-lg font-serif font-bold text-[#242B27]">Locality Card View</h3>
              <p className="text-xs text-[#737D74] max-w-sm mt-1">
                OpenStreetMap tiles are currently rendered in direct card mode. Explore tutor localities and open any area directly in OpenStreetMap.
              </p>
              <div className="mt-4 flex flex-wrap gap-2 justify-center max-w-md">
                {displayedTutors.map(t => (
                  <button
                    key={t.id}
                    onClick={() => setActiveTutor(t)}
                    className="px-3 py-1.5 bg-white border border-[#E8E4D5] rounded-xl text-xs font-bold text-[#242B27] hover:border-[#174C3C]"
                  >
                    {t.name} ({t.locality})
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Floating Instructions Pill */}
          <div className="absolute top-4 left-4 z-20 bg-[#174C3C]/95 text-white text-[11px] font-medium px-3.5 py-1.5 rounded-xl shadow-md border border-[#A8B9A0]/40 backdrop-blur-xs pointer-events-none flex items-center space-x-1.5">
            <Info className="w-3.5 h-3.5 text-[#E6BD68]" />
            <span>Click any marker to inspect neighborhood tutor details</span>
          </div>
        </div>

        {/* Selected Tutor Spotlight Column */}
        <div className="lg:col-span-5 p-6 sm:p-7 flex flex-col justify-between bg-[#FDFCF7]">
          {activeTutor ? (
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-[#E8E4D5]">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#737D74]">
                  Locality Spotlight
                </span>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#E8EFE5] text-[#174C3C] border border-[#A8B9A0]/50">
                  {activeTutor.teachingMode}
                </span>
              </div>

              {/* Tutor Mini Card */}
              <div className="mt-5 flex items-start space-x-4">
                <img
                  src={activeTutor.avatar}
                  alt={activeTutor.name}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-[#E8EFE5] shadow-xs"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(activeTutor.name)}&background=174C3C&color=F8F6EF&size=128`;
                  }}
                />
                <div>
                  <h3 className="font-serif font-bold text-lg text-[#242B27]">{activeTutor.name}</h3>
                  <p className="text-xs text-[#737D74] font-medium">{activeTutor.qualification}</p>
                  <div className="flex items-center space-x-2 mt-1.5 text-xs">
                    <span className="flex items-center text-[#242B27] font-bold space-x-1">
                      <Star className="w-3.5 h-3.5 fill-[#E6BD68] text-[#E6BD68]" />
                      <span>{activeTutor.rating}</span>
                    </span>
                    <span className="text-[#A8B9A0]">•</span>
                    <span className="font-bold text-[#174C3C]">{activeTutor.experienceYears} Years Exp</span>
                  </div>
                </div>
              </div>

              {/* Area Info Box */}
              <div className="mt-5 p-4 bg-white rounded-2xl border border-[#E8E4D5] shadow-xs space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#737D74] flex items-center space-x-1.5">
                    <MapPin className="w-4 h-4 text-[#D87952]" />
                    <span>Serving Locality:</span>
                  </span>
                  <span className="font-bold text-[#242B27]">{activeTutor.locality}, {activeTutor.city}</span>
                </div>
                <div className="flex items-center justify-between text-[#737D74]">
                  <span>Coordinates:</span>
                  <span className="font-mono text-[11px] text-[#242B27]">{activeTutor.coordinates[0].toFixed(4)}, {activeTutor.coordinates[1].toFixed(4)}</span>
                </div>
                <div className="flex items-center justify-between text-[#737D74]">
                  <span>Availability:</span>
                  <span className="font-medium text-[#242B27]">{activeTutor.availability}</span>
                </div>
              </div>

              {/* Subjects & Bio */}
              <div className="mt-4">
                <span className="text-xs font-bold text-[#737D74] block mb-1.5">Subjects Covered:</span>
                <div className="flex flex-wrap gap-1.5">
                  {activeTutor.subjects.map((sub, i) => (
                    <span key={i} className="text-xs font-semibold px-2 py-0.5 rounded-lg bg-[#E8EFE5] text-[#174C3C] border border-[#A8B9A0]/40">
                      {sub}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-4 text-xs text-[#737D74] bg-white p-3.5 rounded-2xl border border-[#E8E4D5] line-clamp-3 leading-relaxed">
                {activeTutor.bio}
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-[#737D74] text-xs">
              Select a tutor on the map to explore their locality coverage.
            </div>
          )}

          {/* Action Buttons */}
          {activeTutor && (
            <div className="mt-6 pt-4 border-t border-[#E8E4D5] space-y-2">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-[#737D74]">Monthly Tuition Fee</span>
                <span className="text-xl font-serif font-bold text-[#174C3C]">₹{activeTutor.monthlyFee.toLocaleString('en-IN')}/mo</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <a
                  href={`https://www.openstreetmap.org/search?query=${encodeURIComponent(`${activeTutor.locality}, ${activeTutor.city}, India`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-2.5 px-3 rounded-xl bg-white hover:bg-[#F8F6EF] text-[#242B27] font-bold text-xs border border-[#E8E4D5] flex items-center justify-center space-x-1 transition-colors cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-[#737D74]" />
                  <span>Open in OSM</span>
                </a>
                <button
                  onClick={() => onSelectTutor(activeTutor)}
                  className="py-2.5 px-3 rounded-xl bg-[#F8F6EF] hover:bg-[#EDE9DC] text-[#174C3C] font-bold text-xs border border-[#E8E4D5] flex items-center justify-center space-x-1 transition-colors cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Full Profile</span>
                </button>
              </div>

              <button
                onClick={() => onContactTutor(activeTutor)}
                className="w-full py-2.5 px-3 rounded-xl bg-[#174C3C] hover:bg-[#0F3328] text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow-sm transition-all cursor-pointer"
              >
                <Send className="w-3.5 h-3.5 text-[#E6BD68]" />
                <span>Send Contact Enquiry to {activeTutor.name}</span>
              </button>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
